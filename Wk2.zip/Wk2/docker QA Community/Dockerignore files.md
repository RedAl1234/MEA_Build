## Overview

**Dockerignore** is a file that can be placed at the root of the context, called `.dockerignore`. It is a list of files and/or directories that we want Docker to ignore during the image building process.

## The .dockerignore file

During the Docker image building process, a core step is adding files from a source/context into the image. However, it can be the case that we do not need to add everything into the image.

For instance, some files in the context may that contain credentials and aren’t needed in the image. Copying them into the image may create a potential security risk.

Another example would be when there are large files in the context that aren’t going to be used. Adding them into the image would be a waste of time and cause the image size to be larger.

The `.dockerignore` file allows us to explicity specify the files or directories we wish to exclude from the build process, and thus we do not need to explicitly specify the ones we want to include.

## Usage

All entries will need to be put in a file called `.dockerignore` at the root of the context.

You can usually ignore the files that you need to by either providing the file itself or by using wildcards.

Here's an example:

```
# this is a dockerignore file
# comments can be made with conventional '#'

# ignore a sensitive file:
secrets/passwords

# ignore all markdown files:
*.md

# ignore any text files in a sub directory:
*/*.txt

# all markdown files have been ignored,
# but make an exception for the README.md:
!README.md
```

## Tutorial

In this tutorial, we will be looking at how to utilise a _.dockerignore_ file.

We can use a **Dockerfile** to test how the ignore file is behaving and see which files are not being sent to the Docker daemon.

**Create a new folder**

For this tutorial, create a new directory called `ignore_exercise`.

```
mkdir ignore_exercise
cd ignore_exercise
```

**Create Dockerfile**

First, let's create the **Dockerfile** we will use to build the example image.

```
touch Dockerfile
```

Place the following contents into the _Dockerfile_:

```
# build from the latest alpine image
# alpine is a very lightweight distribution of Linux
FROM alpine:latest

# copy everything from the context to the container
COPY . /context

# display everything that has been copied to the container
RUN ls -al /context
```

**Create project files**

Next, let's create example files within the context.

Create a directory called `docs` and files named `app.py`, `my-notes.md` and `README.md`.

```
mkdir docs
touch app.py my-notes.md README.md
```

While rather simple, we now have a typical content structure for a project. Consisting of an application, internal documentation and a README.

**Create .dockerignore file**

We do not want to copy any internal documentation, so we will use the `.dockerignore` file to exclude them.

So let's create the **.dockerignore** file.

```
touch .dockerignore
```

Place the following contents into the _.dockerignore_ file:

```
# ignore the docs folder
docs

# ignore all markdown files
*.md

# in this case, we can make an exception for the README
!README.md
```

**Build the image**

Now we're ready to build the image

```
docker build -t my-image:latest .
```

You should see a similar output, which shows the contents of `context` directory within the image:

```
drwxr-xr-x    2 root     root          4096 Sep  7 00:59 .
drwxr-xr-x    1 root     root          4096 Sep  7 00:59 ..
-rwxr-xr-x    1 root     root           138 Sep  7 00:58 .dockerignore
-rwxr-xr-x    1 root     root           265 Sep  7 00:58 Dockerfile
-rwxr-xr-x    1 root     root             0 Sep  7 00:57 README.md
-rwxr-xr-x    1 root     root             0 Sep  7 00:57 app.py
Removing intermediate container 11efe999df76
 ---> c324763036ad
Successfully built c324763036ad
Successfully tagged my-image:latest
```

Notice, as we did not put ".dockerignore" in the `.dockerignore` file, it got copied over as well.

Similarly, in the _.dockerignore_ file, it was set that the _README.md_ will be excluded from the ignore list so it was copied over despite specifying that all `.md` files to be ignored.

This shows how the `COPY . /context` typically copies all the contents of the current directory into the image's `/context` directory. However, the _.dockerignore_ file has allowed us to omit files we do not need.

**Remove the image**

Remove the image:

```
docker rmi my-image alpine
```