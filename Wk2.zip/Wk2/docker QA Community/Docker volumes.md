## Overview

Containers are designed to be spun up and ripped down quickly and easily, as a result, they do not persist data automatically. Volumes are a way of persisting data created and used by a container. In this module we will introduce the concept of volumes.

By the end of this module you should be understand:

-   What a Docker volume is.
-   When and why to use a volume.
-   How to implement and manage volumes.

## Volumes

Consider a scenario where we have a database for a web application hosted in a container. Any data entries in the database will be stored inside the container. That means that in the event that the database container is lost, data stored in it are also lost. This could be catastrophic to our web applications, and also prevents us from easily migrating our containers across environments

We solve this by implementing a volume so that data are stored _outside_ the container.

### Benefits

Volumes are the preferred method of persiting data created in a container. There are a few benefits of using volumes over solutions such as bind-mounts.

-   Unlike bind-mounts, volumes are managed by Docker and do not rely on the host's file system.
-   Volumes can be used by multiple containers, enabling them to share data between them.
-   Volumes can be managed using the Docker CLI.
-   Using volume drivers, volumes can be stored on remote hosts

## Managing Volumes

The Docker CLI provides us with a handy command `docker volume` that allows us to create, view, inspect and delete volumes.

Command | Description
---|---
`docker volume create [NEW_VOLUME_NAME]` | Creates a volume.
`docker volume ls` | Lists the volumes stored locally.
`docker volume rm [VOLUME_NAME]` | Deletes an existing volume.
`docker volume inspect [VOLUME_NAME]` | Returns a JSON with metadata about the volume

Docker stores volumes on the file system at /var/lib/docker/volumes as read-only files. It is not recommended for non-Docker processes to edit these as they are designed to be managed by Docker.

## Mounting Volumes

There are two different flags for the `docker run` command that we can use to mount volumes to a container:

### -v or --volume

```
# docker run --volume [VOLUME_NAME]:[MOUNT_POINT] [IMAGE]
docker run --volume my-volume:/usr/share/nginx/html nginx
```

### --mount

When using the `--mount` flag, we must assign the `type` key to `volume`.

```
# docker run --mount type=volume,source=[VOLUME_NAME],target=[MOUNT_POINT] [CONTAINER_NAME]
docker run --mount source=my-volume,destination=/usr/share/nginx/html nginx
```

`[MOUNT_POINT]` is the directory in the container to mount to the volume

If Docker can't find the name of the volume in the volume list, it will create one for you.

The main difference between the two flags is that `--volume` combines the options together while `--mount` separates them and is more explicit. In addition, if you wanted to use volume drivers, you must use the `--mount` flag.

For inexperienced users, it is recommended to use the `--mount` flag for easier readability.

## Volume Drivers

Whilst we won't be getting hands on with volume drivers here, they are definitely worth knowing about for future reference.

When you do a listing for all the existing volumes, you might have noticed a driver column called local.

This basically means that the volume is stored on the host machine.

You may at some point want to develop a solution where the volume can be stored on a remote host or in a cloud storage solution perhaps.

Plugins will allow you run different drivers to attach volumes to remote places like NFS servers or cloud storage.

## Tutorial

In this tutorial we will go through the creation and management of volumes in Docker.

We will use NGINX as an example to:

-   Persist data after a container is destroyed
-   Share a volume across multiple containers

**Create a new directory**

First let's create a directory for the tutorial called `docker_volumes`

```
mkdir docker_volumes
cd docker_volumes
```

**Creating a volume**

Next, we will create a volume. We will call this volume `webpage` as we will use it to store the custom webpage we want our NGINX containers to serve

```
docker volume create webpage
```

**Create an NGINX Container**

Now we're ready to create our NGINX container with our volume mounted to it. We will mount the volume to `/usr/share/nginx/html`, where NGINX obtains the webpage

```
docker run -d -p 80:80 --name nginx --mount type=volume,source=webpage,target=/usr/share/nginx/html nginx
```

**Create a Webpage**

Currently, NGINX is still using the default home page. Let's change it by executing commands inside the container using the `docker exec` command.

First we will need to install a text editor such as `vim` or `nano` inside the container. Since the NGINX docker image is built on Debian, we can use apt to install the editor.

```
docker exec -it nginx apt update
docker exec -it nginx apt install -y nano
```

Now we have nano installed, open the index.html file with the nano text editor

```
docker exec -it nginx nano /usr/share/nginx/html/index.html
```

Place the following into the file (to paste, use **SHIFT + INSERT** to maintain formatting):

```
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>NGINX</title>
</head>
<body>
       <h3>index.html file stored in a Docker Volume</h3>
</body>
</html>
```

**Destroy and recreate the container**

Stop the container

```
docker stop nginx
```

Remove the container

```
docker rm nginx
```

**Recreate the container**

Recreate the container using the same volume we created

```
docker run -d -p 80:80 --name nginx --volume webpage:/usr/share/nginx/html nginx
```

Either navigate to `localhost:80` in the browser or run the command `curl localhost:80`, and it should return the custom webpage we created. Our custom webpage has persisted!

**Start Another NGINX Container**

To demonstrate how multiple containers can use the same volume, let's create an identical container and publish a different port, port `81`

```
docker run -d -p 81:80 --name nginx2 --volume webpage:/usr/share/nginx/html nginx
```

Using `curl localhost:81`, we can again see the custom web page we created.

**Make a Change to the Webpage**

Now we're going to repeat the steps we did to edit the webpage in the first container to demonstrate the changes being made across both containers.

Install nano

```
docker exec -it nginx2 apt update
docker exec -it nginx2 apt install -y nano
```

Edit `index.html`

```
docker exec -it nginx2 nano /usr/share/nginx/html/index.html
```

Place the following into the file:

```
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>NGINX</title>
</head>
<body>
       <h3>Updated file shown on both containers</h3>
</body>
</html>
```

Like before, use `curl` on both `localhost:80` and `localhost:81`. The changes should be reflected!

**Cleanup**

Stop the containers:

```
docker stop nginx nginx2
```

Remove containers:

```
docker rm nginx nginx2
```

Remove the NGINX image:

```
docker rmi nginx
```

Remove volume:

```
docker volume rm webpage
```

## Exercises

-   Run a MySQL container and add some data to it. Persist the data with a volume. Destroy the container and run up another with the volume mounted to it. Check to see if the data has been persisted.
-   Persist the database in your trio task