## Overview

There are a range of **instructions** that we can set in a Dockerfile to build an image as needed. They include file operations, setting metadata, using commands and more. In this module we will cover the instructions and their uses.

By the end of this module you should be able to create your own custom Docker image.

## Instructions

Instructions in a Dockerfile are the commands that Docker will execute at each step in the image building process. They execute in the order they are written in and follow the format:

```
INSTRUCTION arguments
```

### List of instructions

Instruction | Description
---|---
FROM | Define the base image.
RUN | Execute a command on an intermediate container.
CMD | Define the main process of the container OR define default variables for `ENTRYPOINT`.
ENTRYPOINT | Define the main process for the container to run on start-up.
LABEL | Set metadata for the image.
EXPOSE | Selects the port that the container listens on.
ENV | Set an environment variable.
COPY | Copy files into image.
ADD | Copy files into image (source can be URL).
WORKDIR | Sets the working directory for `RUN`, `CMD`, `ENTRYPOINT`, `COPY` and `ADD` instructions.
ARG | Defines variables for use during build-time.
VOLUME | Creates a mount point with the specified name to save data externally.

**Example Dockerfile**

```
# Start from NGINX image
FROM nginx:latest
# Add our own NGINX webpage
COPY index.html /usr/share/nginx/html/
```

### FROM

Every Dockerfile must start with a `FROM` instruction. This defines the base image on top of which we will be adding new layers to create our own.

**Usage:**

```
# Example
# Start from a Java 8 environment:
FROM java:8
# Rest of instructions follow
```

### RUN

Used to run commands on intermediate containers during build-time. The results of the command executed are saved on top of the current image in a new layer. Typically we use `RUN` for configuring environments and installing dependencies.

We can either point it to an executable (exec form) or execute a shell command (shell form).

**Usage:**

```
# Shell form: executes a command in the default shell
# RUN <command>
RUN apt-get install python3
```

```
# Exec form: runs an executable 
# RUN ["executable", "parameter", ...]
RUN ["apt-get", "install", "python3"]
```

### CMD

Used for providing default arguments to the `ENTRYPOINT` instruction at runtime or point to an executable to run on the container.

**Usage:**

```
# CMD for arguments to ENTRYPOINT
# Example:
CMD ["param1","param2"]

# CMD for a process
# CMD ["executable", "paramater", ...]
# Example:
CMD ["python", "app.py"]
```

There a three things important to keep in mind when using `CMD`:

-   Only one `CMD` instruction can be used in a Dockerfile. If more than one are included then the last one is used.
-   If `CMD` and `ENTRYPOINT` are both used in the same Dockerfile, then the paramters of `CMD` will be appended to the paramters of `ENTRYPOINT`.
-   The CMD parameters can be overridden at runtime by appending them to the end of the docker run command:
    
    ```
      docker run [IMAGE] [NEW_PARAMETERS]
    ```
    

### ENTRYPOINT

Used to configure images so that containers can be run as executables. This works similarly to using `CMD` and points to an executable, but cannot be overriden.

**Usage:**

```
# ENTRYPOINT ["executable", "parameter1", "parameter2"]
ENTRYPOINT ["python", "app.py"]
```

### ADD

Add files to the image from a specified source. Sources can be directories, URL or contents of a _.tar_ file.

**Usage:**

```
# ADD [SOURCE] [TARGET]

# Add a local file such as an application, relative to the context
ADD ./app.py /opt/application/app.py

# Add an entire folder
ADD . /opt/application/

# Add a remote file from a URL
ADD https://remote-server/file.txt /remote-file.txt

# Add a tar file (relative to the context) and extract the contents to a folder
ADD ./application.tar.gz /opt/application
```

### COPY

Similar to `ADD`, except it does not work with URLs and _.tar_ files.

This is the preferred method of copying files (unless the source is an URL or _.tar_ file) into an image as it is more descriptive.

**Usage:**

```
# COPY [SOURCE] [TARGET]

# Add a local file such as an application, relative to the context
COPY ./app.py /opt/application/app.py

# Add an entire folder
COPY . /opt/application/
```

### EXPOSE

`EXPOSE` informs Docker of the port that the container is listening on. It does not publish a port, but rather used as a form of documentation in between the image builder and image user. This way future users of the image know the appropriate port mapping for the container without digging through the application's code.

**Usage:**

```
# EXPOSE [PORT_NUMBER]
EXPOSE 8080
```

### LABEL

Used for adding metadata such as version or description to the image, as a key-value pair.

This can be useful for use with other tools or just for the users' benefit.

**Usage:**

```
# LABEL key=value
LABEL version="1.1"

We can view the labels for a locally stored image using the `docker inspect` command.
```

### ARG

`ARG` allows us to add variables for use at build-time. This is useful for image flexibility and customization.

For example, say you needed to build two versions for the same application, one that runs using Python 2.7 and another that uses 3.6.8. Rather than building two different Dockerfiles, it would be useful to include a `version` argument to make the Dockerfile pull the appropriate base image layer.

Variables included in the Dockerfile can be passed into the `docker build` command using the `--build-arg` flag. A default value can be specified in the Dockerfile. If no default is defined and no value is specified via the `build` command then an error will be thrown.

**Usage:**

```
# Declare a variable with no default value
# ARG [VARIABLE]
# Example:
ARG app_port

# Provide a default
# ARG [VARIABLE]=[VALUE]
ARG app_port=5000
```

### VOLUME

This instruction creates mount points in the containers. This is used to persist data outside of a container, such as logs or database contents.

We can provide more than one volume, separated by spaces.

**Usage:**

```
# VOLUME ["/data"]
VOLUME /mydata
```

Anything saved in `/mydata` can be found on the host machine in `/var/lib/docker/volumes/[VOLUME_ID]/_data.`. The `VOLUME_ID` can be found under `Mounts` by running `docker inspect` on the container.

### USER

Set the user that the instructions following will execute with.

This does not create a user, so any user to be used must be created prior to this instruction.

**Usage:**

```
# USER [USER]
USER jenkins
```

### WORKDIR

Sets the current working directory for the instructions. By default, it is `/`.

This is useful for installing content in specific directories.

**Usage:**

```
# WORKDIR [PATH_TO_DIRECTORY]
WORKDIR /opt/application
```

## Tutorial

For this tutorial, we will create an image for a simple Flask app to be ran in a container.

First, create a directory called `myapp` with a file named `app.py`

```
mkdir myapp
cd myapp
touch app.py
```

In `app.py`, enter the following code:

```
from flask import Flask
app = Flask(__name__)

@app.route('/home')
@app.route('/')
def home():
    return "Hello world!"

if __name__ == '__main__':
    app.run(port=5000, host='0.0.0.0', debug=True)
```

Now we have our simple hello world Flask app, let's create the Dockerfile to build an image.

In `myapp`, create a file called `Dockerfile`

```
touch Dockerfile
```

In Dockerfile:

```
# Python base image.
FROM python:3.7
# Create and set the work directory inside the image named 'app'
WORKDIR /app
# Execute a pip install command using the list 'requirements.txt'
RUN pip install Flask
# Copy the app file into the image working directory
COPY app.py .
# State the listening port for the container. 
# The app's code does not actually specify the port, so it would be useful to include here.
EXPOSE 5000
# Run 'python app.py' on container start-up. This is the main process.
ENTRYPOINT ["python", "app.py"]
```

Now build the image:

```
# Make sure Dockerfile and app.py are in the same directory, then run with build command
docker build -t myapp .
```

Next, run a container from the image:

```
# Map the appropriate ports
docker run -d -p 5000:5000 --name myapp myapp
```

Now navigate to `[IP_ADDRESS]:5000` to check.

### Teardown

```
# stop container
docker stop myapp
# remove container
docker rm myapp
# remove image
docker rmi myapp
```