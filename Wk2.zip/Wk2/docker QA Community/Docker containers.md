## Overview

**Containers** are _lightweight virtual environments_ that are used to package up code with its necessary dependencies.

Providing our applications with their own _environment_ allows them to be recreated across any machine with _Docker_ on it.

The Docker CLI provides us with the necessary tools to deploy and manage containers.

By the end of this module you should be able to:

-   Run a container from a pre-made image
-   Perform container management operations (start, stop, delete, rename and execute commands).

## Use Case

Consider a CI/CD pipeline for an application. As new code is integrated, it will be migrated across multiple environments, such as development, testing and production environments.

It's highly likely that these environments will differ in their configurations, potentially causing the application to behave erratically.

For example, a developer may have a specific software dependency installed on their development environment, as well as environment variables assigned that the application utilises. If these specific dependencies aren't replicated across the pipeline, the application will not run correctly.

Containerising the application with its dependencies allows us to migrate the environment along with the application, meaning it will perform the exact same way on any machine running Docker.

## Containers

Docker containers have several properties that provide us with useful information about them.

Property | Description
---|---
Container ID | The **unique identifier** for the container.
Image | The **Docker image** used for the container
Command | The main process running inside the container.
Created | The amount of time since the container was created.
Status | Whether the container is running or not, and how long.
Ports | The _exposed_ and _published_ ports of the container.
Names | The name of the container.

## Starting up a container

### docker run

This is the command to start up Docker containers. Docker first searches locally for an image with a matching name, then if not found, it will search Dockerhub.

```
# docker run [OPTIONS] [IMAGE]:[TAG]
# Example:
# Starts a nginx container named nginx, with the container's port 80 mapped to the machine's port 80
docker run -d -p 80:80 --name nginx nginx
```

This is a list of some commonly used options.

Option | Format | Description
---|---|---
`--detached` or `-d` | `docker run -d` | Runs the container in detached mode. The container logs are not outputed to the terminal
`--publish` or `-p` | `docker run -p [HOST PORT]:[CONTAINER PORT]` | Publishes a port. Maps a port inside of the container to a port on the host so that it is accessible from the host's IP address.
`--name` | `docker run --name [NAME]` | Names the container. If no name is set, the container is given a randomly generated name.
`--env` or `-e` | `docker run -e [VARIABLE_NAME]=[VARIABLE_VALUE]` | Sets an environment variable inside the container

Find more options in the Docker documentation [here](https://docs.docker.com/engine/reference/commandline/run/).

## Container information

### docker ps

This returns a table of containers. There are a few options useful for manipulating the output. By default `docker ps` returns the current running containers.

Option | Description
---|---
`--all` or `-a` | Returns all containers in a table.
`--filter` or `-f` | Filter output based on a condition provided.
`--quiet` or `-q` | Returns only the container IDs

Example output:

```
user@ubuntu:~/$ docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                 NAMES
5d1ab0732ee6        mysql               "docker-entrypoint.s…"   2 seconds ago       Up 1 second         3306/tcp, 33060/tcp   mysqlcontainer
```

```
# Example
# To return the container IDs of all containers both running and stopped (useful for performing operations on multiple containers):
docker ps -qa
```

### docker logs

This returns the logs of a container

```
# docker logs [CONTAINER_NAME]
# Example:
docker logs jenkins
```

## Executing commands in container

### docker exec

The `docker exec` command executes commands inside a container. This is useful for debugging

```
# Example, creates a text file inside the container
docker exec mycontainer touch myfile.txt
```

Option | Description
---|---
`--detach` or `-d` | Runs the command in the background, no console output
`--env` or `-e` | Set an environment variable
`--interactive` or `-i` | Keeps the interactive shell open for the container. Useful for executing multiple commands or debugging.
`--tty` or `-t` | Allocates pseudo-TTY. This commonly used to enter an interactive shell without passing in a command first.

### Interactive shell in a container

```
# docker exec -it [CONTAINER_NAME] [SHELL INTERPRETER]
# Example:
docker exec -it jenkins bash
```

## Start, stop, rename and remove existing containers

### docker start

Starts a stopped container

```
# docker start [CONTAINER_NAME]
# Example:
docker start mysql_container
```

### docker stop

Stops a running container.

```
# docker stop [CONTAINER_NAME]
# Example:
docker stop mysql_container
```

Option | Description
---|---
`--time` or `-t` | Waits an amount of time in seconds before stopping the container

Any data written in the container while running will persist in the stopped container.

### docker rm

Delete a container

Option | Description
---|---
`--force` or `-f` | Forces removal
`--volumes` or `-v` | Removes volumes associated with the container

Once a container is deleted, any data written during its runtime is also deleted.

## docker rename

```
# docker rename [CONTAINER_NAME] [NEW_NAME]
# Example:
docker rename mysql_container app_db
```

## Tutorial

In this tutorial we will go through the process of setting up a Jenkins instance inside a container.

Checklist:

-   Spin up a container using the official Jenkins image.
-   Map port the machine's port 8080 to the container port 8080
-   Retreive the initial administrator password from the container

### Start the container

It is important to remember to map the container port to the machine's port. In this case, Jenkins is configured to port 8080. So we use the `-p` flag map the ports to eachother.

```
# -d for detached mode so we can still use the terminal
# -p maps the machine's port 8080 to the container's port 8080
# --name names the container so that we are not using a random name
docker run -d -p 8080:8080 --name jenkins_container jenkins/jenkins
```

Now we can check if the container has started properly:

```
docker ps
```

You should see a similar output to the following:

```
CONTAINER ID        IMAGE               COMMAND                  CREATED              STATUS              PORTS                               NAMES
0b7629c00daa        jenkins             "/bin/tini -- /usr/l…"   About a minute ago   Up About a minute   0.0.0.0:8080->8080/tcp, 50000/tcp   jenkins_container
```

### Fetch information from the container

Next, we need to fetch the initial admin password for Jenkins. This will be in the directory `var/jenkins_home/secrets/initialAdminPassword`. We can do this using the `docker exec` command:

```
# execute a cat command in the container to display the password in the terminal
docker exec jenkins_container cat var/jenkins_home/secrets/initialAdminPassword
```

The initial admin password should be displayed on the next line and look similar to the following: `24ec81450f374babb4790c50c3da9284`. Copy this password to your clipboard.

Now you have the initial admin password, copy your machine's public IP address and navigate to it in your browser on a new tab (for example: `34.156.24.89:8080`). Make sure you have allowed incoming connections on port 8080!

You will be prompted to provide the initial admin password that you retrieved previously. Copy it in and follow the installation instructions to install the plugins.

### Tear down

To stop and delete the container:

```
# Stop the container
docker stop jenkins_container
# Deletes the container
docker rm jenkins_container
```