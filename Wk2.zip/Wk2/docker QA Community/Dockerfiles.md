## Overview

A Dockerfile is a set of instructions executed in a step by step fashion to build Docker images. This is a text based document that contains all the necessary commands that would be used on command line to create a container image.

In this module we will cover how Dockerfiles are used.

## Dockerfiles

When building an image for Docker using the `docker build` command, the Dockerfile is where the instructions come from. A `Dockerfile` is created as just that, with no file extension. We just need read and write permissions and a text editor.

### Context

The context is the directory on the local disk the Dockerfile works with. This must be the same location as the Dockerfile unless the `-f` flag is used (see below).

**Example:**

```
FROM python:3.7
WORKDIR /app
RUN pip install Flask
COPY app.py .
EXPOSE 5000
ENTRYPOINT ["python", "app.py"]
```

### Instructions

Each instruction in a Dockerfile creates an intermediate image that is saved (the layers of the image). For example: if there are four instructions in a Dockerfile and your build fails on the fourth, reattempting the build will restart the build process from step 4.

### docker build

**Usage**:

```
# docker build [CONTEXT]
docker build .
```

There are a couple of options available when building an image.

Option | Usage | Description
---|---|---
`-f` | `docker build -f [PATH_TO_DOCKERFILE] [CONTEXT]` | Execute a Dockerfile from a different directory.
`-t` | `docker build -t [USER]/[IMAGE]:[TAG]` | Tag (name) the image being created.

## Tutorial

This exercise will get you to take the _NGINX Docker Image_ and change the default _index.html_ file that is served.  
These changes will be packed into your own _Docker Image_ that you can run and view the changes for yourself.

Please complete the tasks in the order they appear, otherwise they will not work.  
Additionally, please use a bash terminal.

**Create a new directory _dockerfile_exercises_**

In order to create a new folder with the name `dockerfile_exercises` execute the following command:

```
mkdir dockerfile_exercises
```

After creating the directory, change your current directory to the new one by executing:

```
cd dockerfile_exercises
```

**Make a Dockerfile**

Set your terminals working directory to the newly created `dockerfile_exercises`

Then execute the following command to create a new file:

```
touch Dockerfile
```

To make sure file is there, run the following command:

```
ls
```

Place the following contents within the `Dockerfile`:

```
FROM nginx:latest
RUN printf "My Custom NGINX Image\n" > /usr/share/nginx/html/index.html
```

This can be done either on your IDE, or directly from command line with Vim/Nano.

**Build the image from Dockerfile**

Make sure your terminals working directory is set to `dockerfile_exercises`

We'll give the new image name `ournginx`, and the command to build from _Dockerfile_ and give it a suitable name is:

```
docker build -t ournginx .
```

**Run _ournginx_ image on port 80**

The command to run the image and map the port 80 is:

```
docker run -d -p 80:80 --name nginx ournginx
```

**Test the image is running correctly**

In order to test the image is running correctly, navigate your browser to `localhost:80` if you're using docker on your machine.

You should see the following:

![[custom_nginx_image.png]]

If you're using a VM in the cloud, execute the following command:

```
curl localhost:80
```

You should see the following response:

```
$ curl localhost:80
My Custom NGINX Image
```

**Stop and remove the container**

To stop the container execute:

```
docker stop nginx
```

To remove container execute:

```
docker rm nginx
```

**Remove the _ournginx_ image**

To remove image execute:

```
docker rmi ournginx
```