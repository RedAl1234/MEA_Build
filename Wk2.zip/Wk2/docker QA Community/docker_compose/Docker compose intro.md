## Overview

Compose is a tool for Docker that allows you to define and run multiple Docker containers with a single command. It does this through a single configuration file where we can specify the deployment completely.

It is an excellent tool for defining and creating collections of containers and is particularly handy for spinning up microservice applications

By the end of this module you should:

-   Understand what Docker Compose is
-   Why Docker Compose is used
-   Have a high level idea of how it works

## Configuring Microservice Applications

Consider a 4-part microserviced application that consists of a reverse proxy, a frontend, a backend and a persistent database, each in their own container.

In order for this application to work it needs:

-   Four containers, each with their own image and environment variables set
-   A volume to persist the data in the database
-   A bind mount to overwrite the `nginx.conf` file, allowing us to define its behaviour as a reverse proxy
-   Relevant ports published
-   A network to allow our services to communicate with one another

This would be a relatively large task considering it is a simple microservice application.

One option is to use Docker CLI commands to complete this. However it would take a lot longer and there would be room for human error. We could try to put these commands in to a script, but this very quickly becomes a complex and time-consuming process as your container deployments get more involved.

This is where **Docker Compose** comes in. It allows us to streamline this process through the use of configuration files.

## Docker Compose

Docker Compose makes use of configuration files that allow us to declare what Docker resources we want rather than manually creating them ourselves.

It does this using YAML files - a highly readable data format which is essentially a list of key/value pairs. This file should be named `docker-compose.yaml` or `docker-compose.yml`.

A good way to think of this yaml file is like a writing shopping list - when you write a shopping list, you simply specify the list of items you need from the shop, but not the specifics of how and where to get it.

Once you have written the file, you simply need to enter the command `docker-compose up -d` and all your containers will be created and connected to a bridge network for you with the exact configuration you specified.

### Benefits

-   **Build multiple images/containers with one command** - this is significantly quicker than running several commands for each individual Docker component
-   **Easy to read and edit** - when you want to make changes to your deployment, you need only edit the configuration file and rerun the `docker-compose up` command
-   **Automatically puts your containers into a network** - this makes Compose ideal for deploying microservice architected applications as one entity
-   **Containers are deployed as services** - _services_ allow you create replicas of your containers to introduce redundancy to your containerised application

## Installation

Compose is a seperate tool from Docker, however it does come with Windows and MacOS Docker installations. If you are using Linux then you will need to install it using the commands provided in this section.

```
# make sure jq & curl is installed
sudo apt update
sudo apt install -y curl jq
# set which version to download (latest)
version=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | jq -r '.tag_name')
# download to /usr/local/bin/docker-compose
sudo curl -L "https://github.com/docker/compose/releases/download/${version}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
# make the file executable
sudo chmod +x /usr/local/bin/docker-compose
```

You can check that compose is installed and which version it is by using the `--version` option:

```
docker-compose --version
```

## Tutorial

In this tutorial, we will create a simple Docker Compose configuration which creates an NGINX container and scales the application by making multiple replicas of it.

First, ensure Docker (and Docker Compose if using Linux) is installed.

### Docker Compose Configuration File

Docker Compose is configured using YAML files, here we will configure one to create an NGINX container.  
The configuration shown below will create an NGINX container and publish port `80` to a random high port such as `35000`.

Create a folder for this tutorial called `docker-compose-nginx-tutorial` and change to that directory:

```
mkdir docker-compose-nginx-tutorial && cd $_
```

Now create a file called `docker-compose.yaml` and enter the following:

```
version: "3.8"
services:
 nginx:
   image: nginx:alpine
   ports:
   - target: 80
     protocol: tcp
```

#### Run Your Configuration

You should now be able to run your first configuration using a `docker-compose` command:

```
docker-compose up -d 
```

#### View the Running Containers Using Compose

The containers that are running can now be viewed:

```
docker-compose ps
```

The output should be something like this:

```
    Name             Command          State           Ports
-------------------------------------------------------------------
test_nginx_1   nginx -g daemon off;   Up      0.0.0.0:32768->80/tcp
```

#### Access the Application

We can see that under the **Ports** column the high port that the container has been published on is listed.  
Try connect to the container in a browser or by using a `curl` command using that high port.

For this example we could use:

```
curl localhost:32768
```

Creating a response like this:

```
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
<style>
    body {
        width: 35em;
        margin: 0 auto;
        font-family: Tahoma, Verdana, Arial, sans-serif;
    }
</style>
</head>
<body>
<h1>Welcome to nginx!</h1>
<p>If you see this page, the nginx web server is successfully installed and
working. Further configuration is required.</p>

<p>For online documentation and support please refer to
<a href="http://nginx.org/">nginx.org</a>.<br/>
Commercial support is available at
<a href="http://nginx.com/">nginx.com</a>.</p>

<p><em>Thank you for using nginx.</em></p>
</body>
</html>
```

#### Scale Your Application

Compose will allow you to scale your application to an amount that you specify.  
You will be able to scale to different amounts depending on the machine that you are using and the resources that are being used by each of the containers.

In this instance we should be fine scaling to `3` NGINX containers:

```
docker-compose up -d --scale nginx=3
```

Now when you view the running containers there should be 3 instances of NGINX running:

```
docker-compose ps
```

```
    Name             Command          State           Ports
-------------------------------------------------------------------
test_nginx_1   nginx -g daemon off;   Up      0.0.0.0:32768->80/tcp
test_nginx_2   nginx -g daemon off;   Up      0.0.0.0:32769->80/tcp
test_nginx_3   nginx -g daemon off;   Up      0.0.0.0:32770->80/tc
```

#### Clean Up

We can now stop and remove all the containers and images used by running this command:

```
docker-compose down --rmi all
```