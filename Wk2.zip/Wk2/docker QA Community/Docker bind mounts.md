## Overview

Bind mounts are a basic way to share files from a folder between the host machine and a container.

They are best suited for when you have one file or one directory that you need to share from your host machine's file system to the container.

By the end of this module, you should understand:

-   Why we use bind mounts
-   When a bind mount is most appropriate
-   How to use a bind mount

## Bind mounts

Bind mounts are a way to mount files from the host computer into a container. You select a **source** (the directory on the host machine) and a **target** (the directory in the container).

Once mounted, the **source** and **target** become coupled such that any data that exist in the **source** are available in the **target**. In addition, if the container makes a change to the **target** file/directory, it will be reflected in in the **source** on the host machine.

### Use case

Consider NGINX, an application that can function as a static web server, a reverse proxy or a load balancer. Its functionality is configured in a file named `nginx.conf`.

Without a mount, to configure a new NGINX container we would have to either:

-   Create a new image using the NGINX image as a base, and add our NGINX configuration (using a `Dockerfile`).
-   Configure `nginx.conf` by using the `docker exec` command to execute commands in the container.

We can eliminate those steps by using a bind mount. We point the container to `nginx.conf` at run-time so that it is ready immediately.

However, there are two important points to keep in mind:

-   The bind mount relies on the file structure of the host computer. So it would be inappropriate to use a bind mount on a machine whose structure is subject to change. In that case, a **volume** or a new image would be more appropriate.
-   This introduces a separation between data and the application. To transfer the complete environment, we would have to send the image and the data in the mount.

### Command

You can perform a bind mount using the `--mount` flag when running the `docker run` command. It has several options which are passed through as key-value pairs separated by commas:

Option | Description
---|---
`type` | The type of mount. Options are `bind` and `volume`.
`source` | The directory on the host machine to mount into the container. If it does not exist then an error is thrown.
`target`, `dst` or `destination` | The directory to mount inside the container. If it does not exist then an error is thrown
`readonly` | Configure the bind-mount to have read-only access.

```
# NGINX example
# This bind-mounts a config file in the current working directory to the nginx directory in the container.
docker run -d -p 80:80 --mount type=bind,source=$(pwd)/nginx.conf,target=/etc/nginx/nginx.conf nginx
```

## Tutorial

In this tutorial, we will create our own `nginx.conf` file and mount it into an NGINX container.

First, create a directory for this exercise and in it create the file `nginx.conf`

```
mkdir bind_mounts_exercise
touch bind_mounts_exercise/nginx.conf
```

Change to the new directory

```
cd bind_mounts_exercise
```

In 'nginx.conf' enter the following and save it

```
events {}
http {
   server {
       listen 80;
       location / {
           return 200 "NGINX";
       }
   }
}
```

Now we're ready to run our container with the config file mounted.

Run the NGINX container, mapping port `80` and override the existing NGINX configuration file with the one we created.

```
# Our current directory is where we have saved nginx.conf
# NGINX looks in /etc/nginx/ for the config file

docker run -d -p 80:80 --name nginx --mount type=bind,source=$(pwd)/nginx.conf,target=/etc/nginx/nginx.conf nginx
```

Check it works by using the `curl` command

```
curl localhost:80
```

If we were successful we should observe the response "NGINX" as we specified in the config file

```
$ curl localhost:80
NGINX
```

**Teardown**

```
# Stop the container
docker stop nginx 
```

```
# Delete the container
docker rm nginx
```

```
# Delete the image
docker rmi nginx
```

## Exercises

## Duo Task

-   Clone down [this repository](https://gitlab.com/qacdevops/duo-task)
-   Containerise the Flask application by writing its Dockerfile  
    container and the Flask app together
-   Run `curl localhost` or navigate to your machine's network location in your browser

You should see that NGINX is redirecting you to the Flask application running on port 5000.

Remember that your containers will have to be on the same network.

## Trio Task

-   Clone down [this repository](https://gitlab.com/qacdevops/trio-task)
-   Containerise the Flask application in the `flask-app` directory
-   Bind mount the nginx.conf file onto the NGINX container and run the NGINX container and the Flask app together
-   Use a bind mount to mount the SQL dump file `CreateTable.sql` in the directory `db` onto the MySQL 5.7 container (details on where it should be mounted can be found in the Dockerfile)
-   Run `curl localhost` or navigate to your machine's network location in your browser

Remember that your containers will have to be on the same network.