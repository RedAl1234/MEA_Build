## Overview

Docker images are the files used to create containers. They are an isolated `snapshot` of an environment and are typically used to package applications.

In this module we will cover how images operate in Docker and how to use them.

By the end of this module:

-   You will understand the structure of a docker image
-   Be able to perform operations on images using the Docker CLI

## Images

Images are read-only files and exist in a layered structure. They are the heart of containerization technology and are what enables the replicability of environments used in containers.

Say we wanted to create a container of an environment or application on a foreign machine. We can eliminate the need for creating the environment in the container manually by providing an image. This way the container can be spun up instantly.

### Image layers

Since images are read-only, to customize them we must add new layers and thus create a new image.

Consider a scenario where we have a website written in Python that we want to containerize. Instead of going through the process of building the environment image from scratch, we use a previously-made Python image as a base layer and add a new layer containing our website and dependencies.

![[docker_image_layer.png]]

Doing so has the benefits of:

-   Saving space. If multiple images on the disk use the same layers, those layers will be saved on the disk once.
-   Saving time. It eliminates the need for repeating installation or configuration steps for each image.

### Registry

Images are typically stored in remote registries so they are more accessible. There are a few options out there for remote registries, and it also possible to host your own.

Docker has an official registry called **Docker Hub**. It is the default registry used for searching and pulling images when no host is otherwise specified in the image's name.

You can log in to registry using the `docker login` command

```
# docker login [SERVER]
# If no server is specified, then it points to Dockerhub by default.
# Example, logging into dockerhub:
docker login
```

This will prompt the user to log in to Dockerhub.

### Image properties

The full reference to an application's image follows the format: `[HOST]/[AUTHOR]/[APPLICATION]:[TAG]`.

-   `[HOST]` is the remote registry where the image is stored. It defaults to Dockerhub.
-   `[AUTHOR]` is the uploader of the image.
-   `[APPLICATION]` is the name of the application being containerised.
-   `[TAG]` is the version of the application. If no tag is specified, it defaults to `latest`.

The Docker CLI assigns a few properties to images

```
# Example list of images on disk
user@ubuntu:~/workspace$ docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
jenkins             latest              cd14cecfdb3a        2 years ago         696MB
```

Property

Description

Repository

The application. This is the name of the repository in the remote registry (typically Docker Hub) where this image is stored.

Tag

This property is used for versioning. You can reference or tag images using the format `[IMAGE]:[TAG]`

Image ID

This is a unique identifier for the image. This is a reliable way of referencing images.

Created

When the image was created.

Size

Size of image on disk.

## Docker image commands

Docker offers a selection of commands useful for handling images.

Command

Usage

Description

docker search

docker search [IMAGE]:[TAG]

Search for images

docker pull

docker pull [IMAGE]:[TAG]

Download an image

docker push

docker push [USERNAME]/[IMAGE]:[TAG]

Uploads an image to registry (must be logged in)

docker tag

docker tag [OLD_IMAGE]:[OLD_TAG] [USERNAME]/[NEW_IMAGE]:[NEW_TAG]

Tag an image or rename it

docker rmi

docker rmi [IMAGE]/[TAG]

Delete an image from local disk

## Tutorial

In this tutorial, we will register for Docker and then exercise the commands outlined previously.

First, register an account with Docker [here](https://hub.docker.com/)

Once created, authenticate the Docker CLI to Dockerhub with the `login` command.

```
docker login
```

Next, let's download the official Java image.

```
docker search java
```

The search command returns a table of images relevant to the search term with their description and whether they are an official image.

```
NAME                                     DESCRIPTION                                     STARS               OFFICIAL            AUTOMATED
node                                     Node.js is a JavaScript-based platform for s…   9149                [OK]                
tomcat                                   Apache Tomcat is an open source implementati…   2814                [OK]                
openjdk                                  OpenJDK is an open-source implementation of …   2393                [OK]                
java                                     Java is a concurrent, class-based, and objec…   1976                [OK]                
ghost                                    Ghost is a free and open source blogging pla…   1240                [OK]                
couchdb                                  CouchDB is a database that uses JSON for doc…   364                 [OK]                
jetty                                    Jetty provides a Web server and javax.servle…   343                 [OK]                
groovy                                   Apache Groovy is a multi-faceted language fo…   100                 [OK]                
```

We see the official `java` image on line 4. Use the `docker pull` command to download the `java` image.

```
docker pull java
```

```
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
java                latest              d23bdf5b1b1b        3 years ago         643MB
```

**Rename the Java 8 Docker image so that it is prefixed with your _Docker hub_ name**

Replace `<your_docker_username>` with your Docker username and run the following command:

```
docker tag java <your_docker_username>/java:8
```

Now, when we run `docker images`, we can see two images. We have created a new image with a different name. Now we can push the newly tagged image to our repository by tagging it in the format [USERNAME]/[IMAGE]:[TAG].

```
docker push <your_docker_username>/java:8
```

Navigate to [Dockerhub](https://hub.docker.com/), and you should see a new repository.

Now that the image has been uploaded, we can delete the images we have locally and free up space.

**Delete the _java_ image**

```
docker rmi java
```

The output displays the different layers being deleted. The last three lines:

```
Deleted: sha256:dbf7b16cf5d32dfec3058391a92361a09745421deb2491545964f8ba99b37fc2
Deleted: sha256:4cbc0ad7007fe8c2dfcf2cdc82fdb04f35070f0e2a04d5fa35093977a3cc1693
Deleted: sha256:a2ae92ffcd29f7ededa0320f4a4fd709a723beae9a4e681696874932db7aee2c
```

Repeat for the renamed image

```
docker rmi <your_docker_username>/java:8
```

Now, when we run `docker images` we should see an empty table.