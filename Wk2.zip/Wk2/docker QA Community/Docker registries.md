## Overview

This module introduces the concepts of registries. In Docker, a **registry** is an application that stores images in a remote location.

Registries are accessible remotely, allowing instances of Docker to download images from any location.

When you run a container with an image that you didn’t build, NGINX for instance, the image will be downloaded from a _registry_ first.

The default registry that Docker images will be pulled down from is _docker.io_, also known as _Docker Hub_, but we can also create our own server-side registries.

By the end of this module you will know:

-   what a registry is
-   the benefits/use cases for using a server-side registry
-   how to create a registry
-   how to push an image to a registry that you have created

## Storing and Pulling Images

When you specify an image to run a container from, Docker will first check if the image is available on the host machine. If it isn't, it will search for it in a registry.

### Naming Images for Registries

The naming convention for images is:

```
[HOST]/[AUTHOR]/[APPLICATION]:[TAG]
```

The `[HOST]` section of the image name defines the location of the registry.

Leaving this section blank defaults the registry location to _docker.io_, also known as Docker Hub. So when you run `docker pull nginx:latest`, the full name for that image would be `docker.io/nginx:latest`.

![[dockerhub_registry.png]]

Docker Hub is publicly accessible, enabling a vast community of Docker developers to create and upload images that you can easily build your own from.

However, there are situations when you don't want your images to be publicly accessible. You may be developing software for an organisation that is either proprietry or not ready for deployment.

In these situations, you should create your own registry.

## Creating Your Own Registry

![[docker_private_registry.png]]

To create your own registry, you simply run a container based on the official `registry` image like so:

```
docker run -d -p 5000:5000 --name registry registry
```

The registry application listens on port `5000`.

To push an image to a server-side registry, you need to specify the location of that registry in your image name when you tag it, including the port number.

```
docker build -t [REGISTRY_LOCATION:REGISTRY_PORT]/[AUTHOR]/[APPLICATION]:[TAG]
docker push [REGISTRY_LOCATION:REGISTRY_PORT]/AUTHOR/[APPLICATION]:[TAG]
```

For example: if you wanted to push a containerised Flask application image to a registry called `my-registry`, you would enter the following commands:

```
# run the registry container
docker run -d -p 5000:5000 --name my-registry registry
# build the image, following the appropriate naming format
docker build -t my-registry:5000/my-username/flask-application:latest
# push the image to the registry
docker push my-registry:5000/my-username/flask-application:latest
```

You can then pull that image down from another host machine with:

```
docker pull my-registry:5000/my-username/flask-application:latest
```

### Benefits

There are a number of benefits to setting up a server-side registry for your Docker images over using Docker Hub:

-   **Privacy** - If your application is proprietry or just not ready for public consumption, storing your images in a server-side registry container allows it to be accessible only by those who have access to the host machine
-   **Speed** - Having a server-side registry allows images to be stored and retrieved quickly by machines on the same network, rather than having to download them via the internet
-   **Webhooks** - Registries have the ability to execute webhooks to trigger deployments when an image has been successfully uploaded to it

## Accessing a Registry Remotely

By default, to make a registry accessible to external hosts it requires a secure connection. This is done using a transport layer security (TLS) certificate, which must be issued by a certificate authority (CA). Instructions on how to use a TLS certificate to connect to a registry can be found [here](https://docs.docker.com/registry/deploying/#run-an-externally-accessible-registry).

If you are unable to obtain a TLS certificate from a CA, it is possible to create an _insecure registry_ which will allow insecure connections over HTTP. **This should only be used for testing purposes as it exposes your registry to man-in-the-middle attacks**.

To configure a registry to be insecure, you have to edit/create a file called `daemon.json` at the location `/etc/docker/daemon.json` on the _remote machine_. It should have the following contents:

```
{
    "insecure-registries" : ["my-registry-location:5000"]
}
```

You will then have to restart the Docker Engine for the changes to take effect:

```
sudo service docker restart
```

## Tutorial

This exercise will take you through creating your own insecure registry that you can push and pull images to from a remote location.

**Prerequisites**

-   2 VMs in your cloud provider of choice, both on the same virtual network and with the following configuration:
    -   Running Ubuntu 18.04 LTS
    -   Docker installed
    -   Port `5000` open on both machines, such that they can both communicate with each other on that port
-   One VM should be called `registry-vm`, the other should be called `external-vm`

**Create the Registry**

On the `registry-vm`, create the Registry and publish it to port `5000` with the following command:

```
docker run -d -p 5000:5000 --name registry registry
```

**Define an Insecure Registry**

On the `external-vm` machine, edit/create the file `daemon.json` located at `/etc/docker/daemon.json` with the following command:

```
sudo vim /etc/docker/daemon.json
```

And enter the following into the file:

```
{
    "insecure-registries" : ["registry-vm:5000"]
}
```

Restart the Docker Engine with the following command:

```
sudo service docker restart
```

**Push an Image to the Registry from an External Host**

To upload an image to the Registry, we need to tag it with the appropriate name.

On `external-vm`, pull down an NGINX image:

```
docker pull nginx:latest
```

We now need to re-tag the image to specify the location of our registry.

Because the registry is running on the machine named `registry-vm`, we need to re-tag the image to be `registry-vm:5000/my/nginx`.

```
docker tag nginx:latest registry-vm:5000/my/nginx
```

Use the `docker push` command to push the image to the _Registry_ that you have created.

```
docker push registry-vm:5000/my/nginx
```

**Remove the Local Images**

Delete the NGINX images, both yours (`registry-vm:5000/my/nginx`) and the official `nginx` image, with the following command:

```
docker rmi nginx:latest registry-vm:5000/my/nginx
```

Check that the images have been removed from your local machine:

```
docker images
```

**Pull the Image from the Registry**

Now we can run a `docker pull` command to prove that the image has been stored in the registry that we deployed.

Pull our image with:

```
docker pull registry-vm:5000/my/nginx
```

Check that the image has been pulled by executing:

```
docker images
```

You should see the following:

```
REPOSITORY                        TAG                 IMAGE ID            CREATED             SIZE
registry-vm:5000/my/nginx         latest              4bb46517cac3        2 weeks ago         133MB
```

**Clean up**

Stop registry container:

```
docker stop registry
```

Remove registry container:

```
docker rm registry
```

Remove images:

```
docker rmi registry localhost:5000/my/nginx
```

## Exercises

Start Jenkins on a VM and create a freestyle job that will:

-   build an image (or re-tag an existing image, if you prefer)
-   push the image to a registry hosted on a separate VM

Remember to define the insecure registry domain with the Jenkins machine's `/etc/docker/daemon.json` file.