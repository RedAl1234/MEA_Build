## Overview

This module introduces the concept of **networks** in Docker.

For containers to communicate with one another, they need to be placed on the same network. There are a number of different network types that have different use cases.

Networks are therefore necessary for deploying applications with a **microservice architecture**, where the functionality of the application is distributed across multiple containers rather than contained in one **monolithic** application.

By the end of this module, you should know:

-   Why we use networks for Docker containers
-   The different types of Docker networks
-   The main features of **bridge networks**
-   How to create and manage a bridge network
-   How to connect containers to a network

## Networking

When you run a container with the `docker run` command, it is assigned to a network called `default`. It is also assigned an IP address which allows it to be communicated with directly.

Publishing a port with `-p 80:80` will expose the container on port `80` on the host machine, making the container contactable on port `80` via the host machine's network namespace (i.e. its IP address or DNS name).

We can then connect to that container quite easily over the host machine's private (e.g. a private cloud virtual network) or public (e.g. the internet) network.

This is fine for **monolithic** applications, where all our app's functionality is located in the one container. It becomes problematic when the functionality is spread across multiple containers in a **microservice** architecture.

![[docker_client_service.png]]

Consider a web application that consists of the following:

-   a frontend server that communicates directly with users over the internet to serve them HTML pages
-   a backend server that handles the app's internal logic
    -   the frontend communicates with the backend via API calls
-   a database client that persists user information - it only communicates with the backend container

If each container is assigned an indeterminate IP address by the Docker Engine, how can we hard-code the address locations for our containers?

Thankfully, Docker provides other types of networking solutions that allow us to circumvent this problem.

## Network Types

There are four types of network drivers, each designed for different networking purposes.

### Bridge Networks

![[docker_bridge_network.png]]

Bridge networks are for connecting multiple containers on a single host. The default network Docker provides is a bridge network, which allows containers to be accessed via a private IP address.

However, you can also create user-defined bridge networks which allow you to assign DNS names to your containers. This also allows you to create multiple, self-contained networks.

This is the main way we create networks in Docker, so there is a whole section dedicated to bridge networks in this module.

### Overlay Networks

![[docker_overlay_networks.png]]

Overlay networks allow for network connectivity across multiple host machines or _nodes_. This allows you to scale up your applications across multiple host machines while allowing them to easily communicate with one another.

They are primarily employed by Docker Swarm - Docker's container orchestration tool - but can be used for standalone containers as well.

### Host Networks

![[docker_host_networks.png]]

Host networks are used to connect a container directly to the host's networking namespace, rather than assigning the container an IP address.

This means that when you `docker run` a container on a host network, it will share the same IP address and DNS name as the host machine.

Rather than explicitly publishing a port from a container to the host, the application(s) running on the container applications that listen on a port will be made available from the host on that same port.

It is useful for optimising performance: because the container and the host machine share the same networking namespace, there is no network address translation (NAT) required for traffic directed to the container.

Docker creates a host network by default. Host networks are currently only available on Linux.

### Macvlan Networks

Some legacy tools used for network monitoring can only interface with physical networks, while Docker networks are entirely virtual.

Macvlan networks simulate these physical networks by assigning containers MAC addresses, allowing these monitoring tools to interface with your Docker networks.

## Bridge Networks

As mentioned above, bridge networks allow containers to communicate with one another on the same host machine.

There are two kinds of bridge network: default and user-defined.

### Default

The default network will assign an IP address to containers, which is unhelpful for allowing our applications to talk to one another as we can't easily anticipate what that IP will be.

You can add the `--link [CONTAINER_NAME]` flag to your `docker run` command to allow your applications to use the container's name as a network location.

**However, this is considered a legacy approach to bridge networking and is likely to be removed from Docker entirely in the future. Avoid this approach.**

### User-Defined

![[user_defined_bridge_network.png]]

When you want to connect your containers to one another, you should instead use _user-defined bridge networks_. User-defined bridge networks provide the following benefits over the default network:

**Automatic DNS Resolution** - When a container is connected to a user-defined bridge network, its IP address is assigned a DNS name based on the container's name. This allows you to refer to the location of a container in your application code with the container's name.

For example: Say you have a container running called `nginx` and another called `application`. The `application` container has a server listening on port `8080`. The `nginx` container would be able to connect to the server on the `application` container at the location `http://application:8080`

**Network Isolation** - Containers on the same host can be isolated from one another by putting them on separate networks. When two containers are on the same user-defined bridge network, all ports are open to each other and they can communicate freely.

**Easily Connect and Disconnect Containers** - Containers can be easily connected to and disconnected from a bridge network without having to stop the containers.

## Managing networks

The following commands will allow you to manage your Docker networks:

Command | Description
---|---
`docker network create [NETWORK]` | Creates a new user-defined bridge network
`docker network create --driver [NETWORK TYPE] [NETWORK]` | Allows you to create different types of networks
`docker network ls` | Lists available networks on the host machine
`docker network connect [NETWORK] [CONTAINER]` | Connects a container to a network
`docker network disconnect [NETWORK] [CONTAINER]` | Disconnects a container from a network
`docker network rm [NETWORK]` | Deletes a network

You can attach a container to a network when you run it with the `--network` flag, like so:

```
docker run --network [NETWORK] [IMAGE]
```

## Tutorial

This tutorial shows you how to create a bridge network and connect a containerised Python HTTP server and an NGINX container to a network.

NGINX will run as a reverse proxy, redirecting traffic on port `80` to the Python container that is published to port `9000`. The bridge network will allow this connection to take place.

#### Prerequisites

-   A Virtual Machine
    -   Running Ubuntu 18.04
    -   Docker installed
    -   HTTP traffic allowed

#### Setup

Create a new directory called `docker_networking_tutorial` and change to this directory:

```
mkdir docker_networking_tutorial && cd $_
```

#### Create a New Bridge Network

We are doing to create a bridge network to allow our application and NGINX container to connect to one another.

```
docker network create my-network
```

#### Create an Application Container

We are going to run a simple Python-based HTTP server container that is based on the image `bobcrutchley/python-http-server:latest`. We're going to give the container the name `server` and we connect it to our new network with the `--network` flag.

```
docker run -d --network my-network --name server bobcrutchley/python-http-server:latest
```

#### Create an NGINX Container

Run the following command to create an NGINX container with custom configuration and connect it to our network:

```
docker run -d --network my-network -p 80:80 --name nginx lukebenson1/docker-networking-nginx:latest
```

NGINX is a popular web server tool.  
It has many uses, but we'll be using it as a reverse proxy.  
Below is the configuration used by the NGINX container we just created:

```
events {}
http {
    server {
        listen 80;
        location / {
            proxy_pass http://server:9000;
        }
    }
}
```

Without needing to understand NGINX a great deal we can see that `proxy_pass` is referring to the Python server container by its name `server`, not an IP address.

The Python server we are using listens for traffic on port `9000`, so we also need to include this in the proxy pass.

This name `server` will be resolved to the current IP address of the `server` container.

#### Access the Application

You can now access your application one of two ways.

You can use the command `curl localhost` on your command line interface. You should see the following output:

```
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Python: Simple HTTP Server</title>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
  </head>
  <body>
    <h3>Python: Simple HTTP Server</h3>
    <div>
        <div id="info"></div>
    </div>
      <script>
        $.getJSON("info.json", function (info) {
            let host_name = `<p>hostname: ${info.host_name}</p>`
            let version = `<p>version: ${info.version}</p>`
            $('#info').html(host_name + version)
        });
      </script>
  </body>
</html>
```

Or you can navigate to your VM's external IP address via your browser. You should see something like this:

![[docker_python_simple_http_server.png]]

When you connect to your application, traffic is going through NGINX first, it is then routed to your deployed application even though they are in separate containers.

This made possible because both the containers are on the same bridge network.

#### Clean Up

Stop the containers by executing:

```
docker rm -f server nginx
```

Remove images by executing:

```
docker rmi lukebenson1/docker-networking-nginx:latest bobcrutchley/python-http-server:latest
```

## Exercises

### Duo Task

This exercise gets you to containerise a basic Flask application and use NGINX as a reverse proxy.

You should currently be able to:

-   Containerise the Flask application in [this repository](https://gitlab.com/qacdevops/duo-task)
    -   You will have to write a Dockerfile to build the image - a Dockerfile template has been provided for you
-   Create a network and connect the Flask app container to it.

You can try to:

-   Create an NGINX container to and connect it to the network:
    -   You will need to either bind mount the `nginx.conf` file to `/etc/nginx/nginx.conf` on the container, or create a custom NGINX image which copys the file there instead.

Navigate to your application either through your browser or on the command line with `curl localhost`

### Trio Task

This exercise gets you to run a Flask application container, a MySQL container and an NGINX container in a network.

You should currently be able to:

-   Containerise the MySQL database and the Flask application in [this repository](https://gitlab.com/qacdevops/trio-task)
    -   You will have to write the Dockerfile to build the images - a Dockerfile template has been provided for both images
    -   Look up the [MySQL 5.7 image documentation on Docker Hub](https://hub.docker.com/_/mysql) to learn how to configure the database
-   Create a network and connect the Flask application container, database container

You can try to:

-   Create an NGINX container to and connect it to the network:
    -   You will need to either bind mount the `nginx.conf` file to `/etc/nginx/nginx.conf` on the container, or create a custom NGINX image which copys the file there instead.

Navigate to your application either through your browser or on the command line with `curl localhost`