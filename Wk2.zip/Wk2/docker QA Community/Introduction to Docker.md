## Overview

Docker is an open-source containerization tool, useful for developers and system administrators. It offers a solution for differing system environments and provides the ability to keep environments consistent. .

For example, it is often the case that the developers' system environment might differ from production or testing. They may have different versions of operating system, different versions of tools, or many other discrepancies. This creates friction between these stages of development.

Docker solves this problem by providing a replicable container that contains the application's code and everything else it needs to run (dependencies, configurations). Docker being system agnostic means it can be used on most of the major OS, and gives a source of flexibility. Containers can be run from any system (Windows, Linux or MacOS). The only requirement is that Docker is installed.

## Containers

A container is a package containing binaries, libraries, dependencies and application code. It runs a Docker process on the host and is isolated from the host machine's environment, allowing it to be much more lightweight and secure, whilst retaining all of its functionalities.

### Containers vs Virtual Machines

While containers share some similarities with virtual machines, there are differences that cause containers to be a much more suitable solution hosting applications.

![[containers_vs_vms.png]]

Containers and virtual machines are both methods of _virtualisation_, but they have a number of key differences. The diagram above illustrates the structural differences between the two.

### Virtual Machines

-   Emulate the an entire computer to support a full operating system
-   Require a hypervisor to allocate and reserve compute resources (CPU, RAM, storage, etc.) - these resources cannot be shared between VMs
-   Require a lot of resources to run

Due to their nature, virtual machines are extremely versatile but require far more resources. This makes them slow to start up. In a project environment, efficiency and effectiveness are key.

### Containers

-   Run on the same kernel (the operating system's core process) as its host machine, meaning it has direct access to the compute resources it needs to use (i.e. no need for a hypervisor)
-   Resources are shared between containers
-   Require far fewer resources to run
-   Are typically designed to perform one task only

Unlike virtual machines, containers are extremely lightweight, making them very quick to start up. They are less versatile than virtual machines in their abilities, but are perfectly suited when you only need to perform one task (e.g. host a web application).

### Docker in action

Docker is used widely in Dev-Ops, for its lightweight and rapid deployment. When projects are spread amongst a team, the convenience of having an application that can be used on multiple platforms in use of environment standardisation, speeds up the cumbersome task of ensuring all members can get access to it. From the standpoint of a project lead, any method that can cut down menial tasks and add efficiency to a project is a major plus. Time is of the essence after all.

The flexibility that containerisation offers both on-premise and in the cloud (or a hybrid of both) is a huge advantage. Docker containers abstract at the OS level rather than at application level, meaning that Docker is intentionally designed to work on any operating system on any platform. This especially helps in the cloud due to the rising issue of interoperability, which Docker tackles with its platform-agnostic containers. This is then paired with the portability Docker offers with its ability to bundle dependencies within the container - altogether resulting in a technology and its containers being highly flexible!

Docker is not limited to a single use of deployment and is used in workflows such as during development. It helps set up the environment and save time for new developers to start projects in their preferred programming language. Docker is used in different stages and gives developers a chance to try new technologies. It integrates the CI/CD methodologies, and allows collaboration between the team members to share docker images.

Docker can be helpful in times of disaster recovery, and we all know it happens without warning. The lost data can be retrieved at a later point if there any serious issues. For example, if there is a hardware failure, data can be replicated from Docker onto new hardware quickly to keep workflow continuous.

There are also security elements to Docker that VMs and bare-metal don't provide without scrutinous effort.

-   The Docker image or Dockerfile, are transparent and easily readable to understand what potential security risks could be present.
    
-   As a micro-service, you can link certain security problems to specific locations, thus making it easier to find and resolve vulnerabilities.
    
-   With containers, you only need to secure the host, the Docker daemon (which is much smaller than a virtual operating system) and the application running inside the container. For this reason, containers give you a smaller attack surface to protect.
    
-   Docker also makes for easy updates, pulling latest versions of images and applying patches in quick response to known vulnerabilities. This can be done with minimal disruption to end users.
    

## Installation

### Linux

To install Docker on Linux, we can use an official script from `https://get.docker.com`. Either save it as a bash script and execute it or use the command:

```
sudo apt-get update
sudo apt install curl -y
curl https://get.docker.com | sudo bash
```

The script installs Docker and creates a Docker user group with access to the commands. This means that Docker can be only be used with sudo admin privileges or if the current user is in the Docker user group.

To add the current user to the group:

```
sudo usermod -aG docker $(whoami)
```

Note: for changes to apply, restart the current terminal.

### Windows and MacOS

Install Docker Desktop from [here](https://www.docker.com/products/docker-desktop)

Note: For Windows, ensure you enable HyperV for Windows.

## Tutorial

### Run a container

First, ensure that Docker is installed and your current user is in the Docker group.

Now, give _Docker_ a go by running a **hello world container** using the `docker run` command:

```
# --rm flag removes the container when it exits or when the daemon exits, whichever happens first
docker run --rm hello-world
```

You will see _Docker_ download the image and run it.  
The script in the _hello-world container_ will create an output which describes what just happened, creating an output something like this:

```
Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which it to your terminal.

To try something more ambitious, you can run an Ubuntu container with:
 $ docker run -it ubuntu bash

Share images, automate workflows, and more with a free Docker ID:
 https://hub.docker.com/

For more examples and ideas, visit:
 https://docs.docker.com/get-started/
```