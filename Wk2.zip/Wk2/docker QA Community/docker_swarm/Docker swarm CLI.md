## Overview

To deploy our applications using container orchestration, we need to know how to create and manage a Swarm cluster.

We also need to understand how Swarm uses **services** to easily manage multiple replicas of our containers such that they can be deployed across multiple machines.

We can use the CLI for managing all aspects of Swarm including nodes and services.

By the end of this module you should know:

-   How to initialise a Swarm
-   How to create and manage nodes in a Swarm
-   How to create and manage services in a Swarm

## Node Management

Below are commands that are used for managing nodes in a Swarm

Command & Usage | Options | Description
---|---|---
`docker swarm init` | | Initialise the Swarm on the current machine. This machine will become the Swarm's first manager node.
`docker node ls` | | The current nodes in a Swarm can be listed using this command.
`docker swarm join-token worker/manager` | | To add a node to a Swarm cluster, it needs a join token. There are two types of join tokens: worker and manager. The token you use when adding the node will affect what type of node it will be. This command will generate the token for the relevant node type.
`docker swarm join --token [JOIN_TOKEN] [SWARM_MANAGER_IP]:2377` | | Run on a node that you want to join a Swarm. You need to retrieve the join token from the initial manager node first. Swarm nodes communicate on port 2377.
`docker swarm leave` | | When you run this command on a worker, that worker leaves the swarm.
 | | `--force , -f` | Force this node to leave the swarm, ignoring warnings.
`docker node update --availability drain [NODE_NAME]` | | Removing a node from a Swarm requires us to "drain" the node first. This re-jigs the containers across the cluster so they are balanced across all nodes in the Swarm other than this one, "draining" it of its containers.
`docker node rm [NODE_NAME]` | | Remove a node from the Swarm from the manager once it has been shut down.
 | | `--force, -f` | In the case that the node is compromised or unresponsive, the `-f` flag will force the node to leave the Swarm.

## Services

**What are services?**

Services are collections of containers that are all based off the same image. Using a service, we can manage multiple instances of the same containers.

The replicas in a service can then be spread across multiple nodes in a Swarm for high availability and redundancy.

To deploy a container in a Swarm, you need use a service.

Microservice architecture consists of multiple services working together. Examples of services might include an HTTP server, a database, or any other type of executable program that you wish to run in a distributed environment.

### Create

Here are commands needed to create a service:

Command & Usage | Options | Description
---|---|---
`docker service create [OPTIONS] [IMAGE_NAME]` | | Create a service based off an image. The image must be available on the node the container is going to be started on or from a remote registry, the latter being the preferred option.
 | | `--replicas [NUMBER]` | Specifies the number of container replicas in a service
 | | `--publish [NUMBER]` | This publishes a specified port of your choice. e.g. `80:80`

A full list of options for creating a service can be found [here](https://docs.docker.com/engine/reference/commandline/service_create/).

### Publishing Ports and Updating Services

Ports can be published like usual in Docker Swarm however there are some slightly different behavioural traits in Swarm due to how the routing mesh works.

When you publish service in Swarm it is then accessible from the private IP and port of any node in the cluster.

There is a load balancer on every node that distributes traffic across all replica containers.  
Published services cannot be accessed on the loopback interface (localhost).

Here are commands that are used to publish ports and update services:

Command & Usage | Options | Description
---|---|---
`docker service update [OPTIONS] [SERVICE_NAME]` | | Update a running service
 | | `--image [NEW_IMAGE_NAME]` | Update the service containers to run a new image
 | | `--publish-add [HOST_PORT:CONTAINER_PORT]` | Update the published ports
 | | `--replicas [NUMBER]` | Update the number of replicas.

### General Service Management

Command & Usage | Description
---|---
`docker service ls` | List all services in the Swarm.
`docker service rm [SERVICE_NAME]` | Delete a service and its associated containers.
`docker service logs [SERVICE_NAME]` | Show the logs for containers in the named service.
`docker service ps [SERVICE_NAME]` | Lists all containers in the named service.

## Tutorial

### Pre-requisites

-   3 x Ubuntu VM's running version 18.04 LTS (Spun up with your choice of cloud provider).
-   Docker installed on all VM's
-   Port 80 open on your Manager VM

### Create Cluster

Put together a cluster with 3 nodes, one manager and 2 workers.

1.  On the machine you have chosen to be the Swarm Manager run the following command:
    
    ```
    docker swarm init
    ```
    

This will initialise the Swarm `Manager` and Docker will output a `Join Token`. Note this down as you will need this command to add workers to your Swarm.

2.  Log on to the Virtual Machine's that will be worker node's in the Swarm, run the join command that was generated earlier, the command should be similiar to the command below:

```
docker swarm join --token SWMTKN-1-14601cadnn15hf45gjqql23jta4vk4kxh8uy6zyn8vo0fxzu5z-31kwu4qd6up8ktez4kj62ppvr 192.168.61.1:2357
```

If you can’t obtain the join command anymore, run the join-token command below on the Swarm Manager VM:

```
docker swarm join-token worker
```

3.  Log on to your second VM that will also be a worker node, run the same join-token command to join the Swarm as a worker.

Now you have 3 nodes in the Swarm! To check if the Swarm has been configured properly run the following command:

```
docker node ls
```

### Create a Service

Create a service that uses the `bobcrutchley/python-http-server:latest` image and is named `python-http-server`. Run the following command on your manager node to do this:

```
docker service create --name python-http-server bobcrutchley/python-http-server:latest
```

### Update the Service

Update the service so that there are `10` replicas and the port `9000` (inside the container) has been published to `80` (outside the container). Run the following Command to update the service:

```
docker service update --replicas 10 --publish-add 80:9000  python-http-server
```

The port numbers in the command above `80:9000` represent the Published Port which is `80` and the Container Port `9000`.

### Access the Service

Use the curl CLI tool to view the `info.json` file served by the application, this file shows the name of the host that it is running on.

Run the following command:

```
 curl http://[YOUR_PRIVATE_IP]/info.json
```

You can substitute the private IP address here with the private IP address of your manager node. Curl the file multiple times, what do you notice about the output?

### Remove the Worker Nodes

Update the amount of replicas to 2. Run the command Below on the manager VM to do this:

```
 docker service update --replicas 2 python-http-server
```

Drain both of the worker nodes and remove them. Run the command below and replace the [NODE_NAME] with your own.

```
docker node update --availability drain [NODE_NAME]
```

You can get the node names by running `docker node ls`

## Clean up

1.  Remove Service (Run on Swarm Manager):
    
    ```
    docker service rm python-http-server
    ```
    
2.  On each worker node run the command below to shut it down:
    
    ```
    docker swarm leave
    ```
    
3.  Now remove the nodes using the command below on the Swarm Manager:
    
    ```
    docker node rm [YOUR NODE NAME]
    ```
    
4.  Shutdown and remove all VM resources on your cloud provider platform to avoid unexpected charges and fees.
    

## Exercises

For both of these exercises you may need to create a certain type of network, that allows connections across multiple hosts.

### Duo Task

Clone down [this repository](https://gitlab.com/qacdevops/duo-task).

Write a Dockerfile for this Flask application and deploy it as a service with 10 replicas in a Swarm with 1 manager and 2 workers.

Run a reverse proxy NGINX service to redirect HTTP traffic on port `80` to the Flask application (the configuration has been written for you in the `nginx.conf` file.

### Trio Task

Clone down [this repository](https://gitlab.com/qacdevops/trio-task).

Create and deploy these applications as services in a Swarm with 2 managers and 2 workers.

Hint: You will need to configure the app to communicate correctley if you haven't already, this will include:

-   Changing the DB password in app.py
-   Making sure the service names match connection requests in app.py and the nginx.conf.
-   Configure Dockerfiles for both the flask-app and DB.