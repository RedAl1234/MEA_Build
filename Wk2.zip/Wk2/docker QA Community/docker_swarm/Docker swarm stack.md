## Overview

**Stacks** allow us to deploy multiple services in a Swarm at once from a single configuration file. They make use of the same configuration format as Docker Compose and can therefore use the same `docker-compose.yaml` files.

Stacks also allow use to easily perform rolling updates across multiple services, i.e. an update that _rolls out_ gradually to replace outdated containers with updated versions, resulting in minimal to zero downtime.

By the end of this module you should understand:

-   What a Stack is and why we use them
-   How to create a Stack
-   How to perform a rolling update with `docker stack deploy`

## Managing and Updating Services

Services are collections of containers that are all based on the same image. In a production environment, we would run our containerised applications as Swarm services to provide redundancy and high availability.

Microservice applications are built from a collection of separate services that communicate with one another. Each service is designed to have a dedicated function or small set of functions, with information being sent between each microservice.

We could deploy and update an application made up of microservices in our Swarms using `docker service` commands, but this soon becomes cumbersome and lengthy.

## Stacks

Stacks are collections of services in Docker Swarm. They allow us to easily deploy, manage and perform rolling updates across multiple services with only a configuration file and a single command, making them ideal for deploying microservice applications.

### Deploying and Updating

The command to deploy a Stack is:

```
docker stack deploy --compose-file [COMPOSE_FILENAME] [STACK_NAME]
```

This command will create the Stack based on the configuration set out in the Compose file.

To update a Stack, you merely need to edit your Compose file accordingly and run the command again. Stack will check the file for any differences between the current running Stack and the new configuration and will update the Stack accordingly.

To update the application, you can simply specify a new image to base your services off of. Stack will pull the new image to the Swarm nodes and begin replacing each container within each service with the new version.

The update is _rolled out_ gradually across each container, such that the outdated versions are swapped out one-by-one with the new versions.

This means users of the application will experience little to no downtime as while the application is being updated. Both the old and new versions will be accessible until the new version has been fully rolled out across the Swarm.

### Commands

Here is a list of relevant Stack commands:

Command | Description
---|---
`docker stack deploy --compose-file [COMPOSE_FILENAME] [STACK_NAME]` | Creates or updates a Stack based on the configuration set out in the `.yaml` file you specify (typically `docker-compose.yaml`)
`docker stack services [STACK_NAME]` | Lists the services within a Stack
`docker stack rm [STACK_NAME]` | Deletes a Stack
`docker stack ls` | Lists all stacks
`docker stack ps [STACK_NAME]` | Lists all containers in the named stack

### Configuration File

Stacks are configured using YAML files and use the same syntax as Docker Compose. As a result, `docker-compose.yaml` files can be used for both Compose and Stack.

However, some instructions that Compose can use is deprecated with Stack:

-   `build` - Stack cannot build images, instead the Compose tool or just Docker is best used for this purpose
-   `container-name` - one of the main reasons for using an orchestration tool is to horizontally scale your workload (i.e. make replicas of your containers), this isn't possible when containers have a fixed name

There isn't anything stopping you from still including these keywords in the file so that they can be still used for Compose commands - they are simply ignored by Stack.

### Pulling Images

Stack needs to pull its images from a registry, be that Docker Hub (docker.io) or a private local registry. This is because, as a part of Docker Swarm, it will run its containers across multiple nodes in the cluster. It therefore needs a central location to pull its images from.

You should therefore build your images using Compose or with Docker commands and push them to your registry of choice before attempting to run `docker stack deploy`.

## Tutorial

This tutorial first shows you how to create a two-service Stack within a Swarm cluster. It then shows you how to use Stack to perform a rolling update.

### Prerequisites

-   1 VM spun up with your cloud provider of choice
    -   Running Ubuntu LTS 18.04
    -   Has at least 2GB of RAM (if the VM become unresponsive after running your Stack, you may need 4GB of RAM)
    -   Docker and Docker Compose installed
    -   Network traffic allowed on port `5000`

### Application Architecture

The application we are going to deploy is a simple two-service Python server, comprised of a user-facing frontend and a backend that receives API calls from the frontend.

The backend will serve the frontend the backend container's hostname and a random letter. The frontend will then display this information, along with the frontend's hostname, to the user via an HTML page like so:

### Creating the Swarm

First thing we need to do is initialise a Swarm. For this tutorial we don't need to set up a whole cluster, so we are just going to create a Manager node (you are more than welcome to add Worker nodes to the Swarm if you so wish).

Initialise the Swarm with the following command:

```
docker swarm init
```

### Creating the Stack

The images for our application have already been built and are available from Docker Hub. They have been tagged `htrvolker/stack-tutorial-frontend:blue` and `htrvolker/stack-tutorial-backend:letters`.

The first thing we have to do to create our stack is create our configuration file with the following command:

```
touch docker-compose.yaml
```

Using the text editor of your choice, copy the following configuration into our new `docker-compose.yaml`:

```
version: '3.7'
services:
  frontend:
    image: htrvolker/stack-tutorial-frontend:blue
    deploy:
      replicas: 3
    ports:
    - published: 5000
      target: 5000
  backend:
    image: htrvolker/stack-tutorial-backend:letters
    deploy:
      replicas: 3
    ports:
    - published: 5001
      target: 5001
```

Take some time to read through the configuration file above. There are a few things to note:

-   The application requires our services to be named `frontend` and `backend`, as these are the network namespaces the services make HTTP requests to
-   We are deploying 3 replicas of each container for both services (but feel free to experiment with how many replicas you can get to run on this machine at once!)
-   The `frontend` has to be published on port `5000` while the `backend` has to be published on port `5001`

Now, simply run the following command to deploy your Stack:

```
docker stack deploy --compose-file docker-compose.yaml stack-tutorial
```

Check to see if your Stack has been deployed correctly:

```
docker stack services stack-tutorial
```

You should see an output similar to this, where the `REPLICAS` column should read `3/3` for each service:

```
ID                  NAME                      MODE                REPLICAS            IMAGE                                      PORTS
2m5w9431hrko        stack-tutorial_frontend   replicated          3/3                 htrvolker/stack-tutorial-frontend:blue     *:5000->5000/tcp
jnpwlv6m0syy        stack-tutorial_backend    replicated          3/3                 htrvolker/stack-tutorial-backend:letters   *:5001->5001/tcp
```

In your browser, navigate to your VM's public IP address on port `5000` (if you get a Connection Refused error, check your VM's firewall rules). You should see a basic HTML page with a garish blue background.

Refresh the page repeatedly. You should see that the codes change each time you refresh. These are the hostnames that have been defined within each container as an environment variable, which the Python application reads and displays to the user. It also shows a random letter.

This illustrates how there are multiple instances of our containers running and that our frontend containers are communicating with the containers backend service.

### Perform a Rolling Update

Now we are going to update the services with a new version of the application. This time the frontend will serve a _green_ background and show a random number between 0 and 9999.

First, we must edit our configuration file to pull down our new images. With your text editor of choice, edit `docker-compose.yaml` to pull down `htrvolker/stack-tutorial-frontend:green` for the frontend and `htrvolker/stack-tutorial-backend:numbers` for the backend, like so:

```
version: '3.7'
services:
  frontend:
    image: htrvolker/stack-tutorial-frontend:green
    deploy:
      replicas: 3
    ports:
    - published: 5000
      target: 5000
  backend:
    image: htrvolker/stack-tutorial-backend:numbers
    deploy:
      replicas: 3
    ports:
    - published: 5001
      target: 5001
```

Finally, update the services by running `docker stack deploy` again:

```
docker stack deploy --compose-file docker-compose.yaml stack-tutorial
```

Refresh the page on your browser repeatedly. It will take some time, but eventually you should notice the background change from blue to green occasionally, signifying that you've made a request to the new version of the application.

For a while, the page will flip between the blue and green versions as you refresh, as well as whether the backend provides either a random letter or number. This is because the containers are gradually updated over time, so that there is no service downtime for the user.

Eventually the page will settle on the newly updated green version of the application and only serve random numbers.

## Exercises

### Trio Task

Deploy this [Trio Task](https://gitlab.com/qacdevops/trio-task) as a three-service Stack across a Swarm with 1 Manager and 2 Workers. Create 4 replicas for the Flask application.

Stretch Goal: Set up an NGINX load balancer on a separate VM to load balance incoming traffic between the Swarm nodes.

Stretch Goal: Set up a volume that persists the data in the MySQL container.