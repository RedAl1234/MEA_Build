## Overview

Orchestration is the **automated configuration, management, and co-ordination of computer systems, applications, and services**.

Orchestrating the scheduling and integration of automated tasks between complex distributed systems and services, whether _on-premises_ or in the _cloud_, streamlines and simplifies interconnected workloads, repeatable processes, and operations.

With modern IT teams now **responsible for managing hundreds to thousands of applications and servers**, manual administration simply can’t scale at the rate needed; this is why using an orchestration tool has become so important.

## Swarm

Docker swarm is _Docker’s own container orchestration_.

It uses the standard Docker API and networking, making it easy to drop into an environment where you’re already working with the Docker containers.

Swarm is especially useful for people who are **trying to get comfortable with an orchestrated environment**, or those who need to adhere to a **simple deployment** technique.

## Kubernetes

Kubernetes is an open-source platform, _created by Google_, for container deployment operations, scaling up and down, and automation across a cluster.

This **production-ready**, **enterprise-grade**, **self-healing** (auto-scaling, auto-replication, auto-restart, auto-placement) platform is **modular**, and so it can be utilised for any architecture deployment.

## Comparison

Though both the open-source orchestration platforms provide _much of the same functionalities_, there are **some fundamental differences** between how these two operate:

### Application definition

**Kubernetes**: An application can be deployed in Kubernetes utilising a combination of _services_ (or microservices), _deployments_, and _pods_.

**Docker Swarm**: The application can be deployed as _services_ (or micro-services) in a _swarm cluster_ in Docker Swarm. YAML files can be utilised to identify multiple containers. Docker-compose can also be used to install the application.

### Networking

**Kubernetes**: The networking model is a _flat (overlay) network_, allowing all pods to interact with one another, and the network policies specify how the pods interact with each other.

**Docker Swarm**: The Node joining a swarm cluster generates both an _overlay network for services that span every host in the docker swarm_ and a _host-only docker bridge network for containers_.

### Scalability

**Kubernetes**: For distributed systems, Kubernetes is more of an _all-in-one framework_. It is a complex system because it provides _strong guarantees about the cluster state_ and has a unified set of APIs. This **can slow down container scaling and deployment**.

**Docker Swarm**: Docker Swarm, when compared to Kubernetes, can **deploy containers much faster** and this allows faster reaction times to scale on demand.

### High Availability

**Kubernetes**: All the pods in kubernetes are distributed among nodes and this offers high availability, by _default_, by tolerating the failure of an application. Kubernetes will detect unhealthy pods and get rid of them (replacing them with healthy pods).

**Docker Swarm**: As the services can be replicated in Swarm nodes, Docker Swarm also offers high availability (although health checks need further configuration). The Swarm manager nodes in Docker Swarm are responsible for the entire cluster and handle the worker nodes’ resources.

### Container Setup

**Kubernetes**: Kubernetes _utilises its own YAML, API, and client definitions_, and each of these differ from that of standard docker equivalents. Therefore, you **can't utilise Docker-compose, or the Docker CLI, to define containers**. While switching platforms, YAML definitions and commands need to be rewritten.

**Docker Swarm**: The Docker Swarm API doesn’t entirely encompass all of Docker’s commands, but _offers much of the familiar functionality from Docker_. However, if an operation won't work with the Docker API, it is unlikely that you'll be able to get it to easily work with Swarm.

### Load Balancing

**Kubernetes**: Pods are exposed via services, which can be used as a load balancer within the cluster. Generally, an ingress is utilised for load balancing.

**Docker Swarm**: Swarm consists of a DNS element that can be used for distributing incoming requests to a service name. Services can be assigned automatically or can run on ports specified by the user.

## Conclusion

**Kubernetes supports higher demands with more complexity**, while **Docker Swarm offers a simple solution that is quick to get started with**.

_Docker Swarm_ has been quite _popular among developers who prefer fast deployments and simplicity_. Simultaneously, _Kubernetes_ is used in _production environments_ by various high profile internet firms running popular services.

Both Kubernetes and Docker Swarm can run many of the same services, but may need slightly different approaches **depending on what you want to do** with them.