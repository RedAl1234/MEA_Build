## Overview

Swarm is a _container orchestration tool_ built into Docker that allows us to run a network of containers across multiple host machines, also known as **nodes**.

Nodes are grouped together in **clusters** of **managers** and **workers**. Manager nodes manage the Swarm while worker nodes merely host containers.

Containers in a Swarm are run as **services** - collections of containers based on the same image, and are therefore all replicas of each other. Replicating our containers provides redundancy and high availability to our applications.

Swarm comes bundled with Docker so you do not need to install any other software.

In this module you will learn:

-   Why use Docker Swarm.
-   What does Swarm do.
-   How to create a Swarm.

## Container Orchestration

Using Docker CLI and Compose allows us to containerise our applications and deploy them on a machine with ease.

Once we start deploying in an actual production environment where we're potentially serving hundreds, thousands or millions of users, using the CLI or Compose just isn't a feasible option anymore. We're going to need a solution that can work at a much **bigger scale**.

In order to deploy and manage our containers at scale, we need to use a container orchestration tool.

### Benefits

There are a number of benefits to hosting our containerised applications using an orchestration tool:

-   **Easily scale up/down containers** - orchestration gives us control of how many instances of a container are running, allowing us to easily increase the scale of our operation, for example if our user base increases
-   **Replicate containers for increased redundancy and improved resiliency** - if one instance of your container dies, there will be others to take its place
-   **Deploy containers across multiple machines (nodes)** - this allows us to make use of more compute resources and improve system resiliency
-   **Load balancing between containers** - incoming network traffic is balanced across nodes, meaning computational load is spread evenly across nodes
-   **Dynamically re-allocate containers across nodes** - if a node dies, containers on that node will be reallocated to the remaining nodes automatically
-   **Rolling updates can be done without stopping or restarting any containers** - this means that updates can be implemented without requiring any downtime for the end user

## Docker Swarm

Docker Swarm is Docker's in-built container orchestration tool. Because it's built-in there are no extra installation requirements.

Swarm contains a number of different components: clusters, manager nodes, worker nodes and a network mesh for ingress traffic.

### Swarm Clusters

A swarm is a group of containers running across a group of machine. We refer to this group of machines as a **cluster**.

Nodes within a cluster communicate with one another to balance the containers within the swarm across the cluster, making maximum use of all the compute resources available while ensuring no node is being overworked.

Nodes in the cluster are either **manager** nodes or **worker** nodes. When a cluster is initialised on a node, it becomes the cluster's first manager. It can then produce a join token to allow more manager or worker nodes to join the cluster over a secure connection.

### Manager Nodes

This node is where we can execute commands for managing the Swarm, including the nodes inside it.

You may have more than one Manager node in a cluster.

### Worker Nodes

The worker's job is to just run containers, complying with the manager nodes requests.

Containers for deployed services will be automatically provisioned evenly across worker nodes.

When new worker nodes are added, deployed services must be updated or recreated to take advantage of the new nodes.

### Ingress

The routing mesh in Docker Swarm allows for services to be load balanced by default.

When you access a published service on any node, your request first goes through a load balancer.

This means that even if you made a request to a node that has no replicas of the service you want, your request would still be successfully redirected to a replica of the right service on another node using the internal swarm load balancer.

The routing mesh requires the following ports to be open between all nodes in the swarm:

-   Port `7946` with protocol `UDP`
-   Port `7946` with protocol `TCP`
-   Port `4789` with protocol `UDP`

> Note: Some cloud providers have all ports allowed for private connections, others you will need to allow these ports manually.

## Tutorial

In this exercise we will be initialising Swarm, with one manager and one worker node.

### Simple Swarm Setup

#### Prerequisites

-   You will need two machines, ideally on the same network or subnet, which can connect to each other.
-   Both the machines must have Docker installed on them.
-   If you are using a cloud service, call one `swarm-master` and the other `swarm-worker`

#### Initilising the Swarm

We need to create our first node in the Swarm which will serve as a Manager node.  
On the first machine you have, run the follow command:

```
docker swarm init
```

#### Adding a Worker Node

At this point the cluster is now setup and you may start creating services, however we will add a worker node first.

Upon initilising the Swarm, Docker would have likely prompted you with a command that allows you to join a worker node to the swarm.  
Once you have obtained the join command, you can simply run it on the second machine that you have.

The command will look similar to the one below, however the token and IP address will be different for yours, be sure to use the _private_ address of the VM.

Log on to the **worker** node and run the join command similiar to below:

```
# docker swarm join --token [TOKEN] [IP_ADDRESS]:[PORT]
docker swarm join --token SWMTKN-1-4y5lnvp7h7l7pt2qusvykiyk8p0hn0yywq3gk47ogau8pl64f9-15hstsq0lahr72cz6dppex0i6 swarm-master:2377
```

Also take a moment here to notice which port the workers are connecting from; `2377`.  
This will be important to allow on locked down networks.

##### Retrieving the Join Command

If you can’t obtain the join command anymore, you can use the `join-token` command while on the **master** node to get it back:

```
docker swarm join-token worker
```

#### Create Your First Swarm Service

When managing Swarm services, ensure that you are first on the manager node.  
Here we will create a simple NGINX service and use the curl CLI tool to access it.

```
# docker service create --name [NAME] --publish [HOST_PORT]:[CONTAINER_PORT] [IMAGE]:[TAG]
docker service create --name nginx --publish 80:80 nginx:latest
```

Once you have created the service, it will be accessible on the private IP address of the machine, not the loopback interface (localhost).  
To access the NGINX service for this example, the curl command below can be used, the NGINX service will be available from both the worker and master node:

```
# curl http://[PRIVATE_IP_ADDRESS]
curl http://swarm-master
curl http://swarm-worker
```

#### Delete Your First Swarm Service

Let's remove the service that we created:

```
docker service rm nginx
```