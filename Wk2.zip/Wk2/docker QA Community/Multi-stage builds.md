## Overview

Multi-stage builds allow you to separate the build stages of your images into different containers.

This is beneficial for keeping your image and container sizes down, as build tools and source code can be used to compile code in temporary intermediate containers and then deleted once you no longer need them.

The final image then only needs to contain the appropriate runtime and the executable files that were compiled in the build stage.

They are most commonly used for compiled languages, such as Java. Interpreted languages like Python do not have much use for multi-stage builds.

By the end of this module, you should know:

-   Why we use multi-stage builds
-   How to create a Dockerfile that uses a multi-stage build

## Source Code and Build Tools

Many applications are written using a compiling language. A compiling language requires the source code to be built (or compiled) before it can be run.

A file is generated as a result of a build stage (known as a _build artefact_) and we execute this to run our application. For example, compiling a Java application will generate a `.jar` file.

The environment in which we perform our build stage can impact how the code is compiled, based on how that environment is configured and which dependencies are installed.

To keep our build environments consistent, it is beneficial to perform the build stage in a _container_ based on a build tool image. For example, if your application is written in Java, you may want to compile it in a container based on a Maven image. You can then set the `.jar` file as your entrypoint.

Once it has been compiled, the source code and build tool are not required for execution of the application.

As a result, they just take up extra space on the container while the application is being run, meaning your container uses more resources (i.e. memory) than required and their deployment times are slowed down.

We could build the app before containerising it, but this would negate the benefit of using a container as our build stage.

## Multi-stage Builds

Multi-stage builds allow us to split our build and execution stages into two (or more) separate containers: one with the build tool installed, the other with the application's runtime installed.

The steps are:

1.  Perform the compiling in the build tool image
2.  Copy the build artefact from the build stage into the runtime image
3.  Delete everything associated with the build stage

This has the benefit of:

-   Keeping our build environments consistent
-   Keeping our application's image and container size down
-   Speeds up deployment of containers

## Dockerfile Syntax

Below is an example Dockerfile that make use of a multi-stage build:

```
FROM maven:latest AS build-stage
COPY . /build
WORKDIR /build
RUN mvn clean package

FROM java:8 AS runtime
WORKDIR /opt/hello-world
COPY --from=build-stage /build/target/hello-world-1.0.0.jar app.jar
ENTRYPOINT ["/usr/bin/java", "-jar", "app.jar"]
```

Let's break it down.

```
FROM maven:latest AS build-stage
```

First we define the build stage and the image it is built from (in this case, Maven). The `AS` keyword is used to define a name for this stage. This is useful for reference later in the Dockerfile.

Each stage is also assigned an integer that increments from `0` which can be used to reference a given stage. You can use this convention in lieu of assigning explicit names. Our build stage can therefore also be referred to using `0`.

```
COPY . /build
WORKDIR /build
RUN mvn clean package
```

Next we copy our source code from our build context into our image into a directory called `/build`. The current working directory is then changed to `/build` and the build tool _Maven_ is run, compiling our application.

```
FROM java:8 AS runtime
```

We then define our runtime container within which we will actually execute our application. We are using Java 8 as our runtime engine, so we build this stage from the `java:8` image.

This stage has been assigned the name `runtime`. Though this isn't strictly necessary as it is not referenced later in the file, it is handy for readability.

```
WORKDIR /opt/hello-world
COPY --from=build-stage /build/target/hello-world-1.0.0.jar app.jar
```

After changing the working directory, we copy the build artefact (our `app.jar` file) into our `runtime` image. Note the `--from=` flag in the `COPY` command - this is where we reference our build stage called `build-stage`, specifying that we are copying the files from that environment.

```
COPY --from=0 /build/target/hello-world-1.0.0.jar app.jar
```

We could alternatively refer to this stage with its index - as it's the first stage, we would use `--from=0`.

```
ENTRYPOINT ["/usr/bin/java", "-jar", "app.jar"]
```

Finally the `app.jar` file is specified as our container's entrypoint.

## Tutorial

This tutorial takes you through how to use a multi-stage build to build a simple Spring Boot server written in Java and run it in a separate container.

### Clone the Application

Clone the application's repository to your machine and change into the directory with the following command:

```
git clone https://gitlab.com/qacdevops/multi-stage-build-exercise.git && cd multi-stage-build-exercise
```

The file structure of this repository looks like this:

```
.
├── pom.xml
└── src
    └── main
        ├── java
        │   └── com
        │       └── example
        │           └── helloworld
        │               └── HelloWorldApplication.java
        └── resources
            └── static
                └── index.html
```

### Create the Dockerfile

Next, we need to create our Dockerfile. Make sure you're in the root directory of your repository and run the command:

```
touch Dockerfile
```

Open the file in Vim (or your text editor of choice).

Paste the following into the Dockerfile:

```
# build from the Maven image
# which has a maven environment configured already
FROM maven:latest

# copy our application in
COPY . /build

# change the working directory to where we are building
# the application
WORKDIR /build

# use maven to build the application
RUN mvn clean package

# create a new build stage from the Java image
# which has java installed already
FROM java:8

# change the working directory to where the application
# is going to be installed
WORKDIR /opt/hello-world

# copy the JAR file that was created in the previous
# build stage to the application folder in this build stage
COPY --from=0 /build/target/hello-world-1.0.0.jar app.jar

# create an entrypoint to run the application
ENTRYPOINT ["/usr/bin/java", "-jar", "app.jar"]
```

### Build the Image

Create the image by executing:

```
docker build -t spring-hello-world .
```

### Run the Container

Start the container by executing:

```
docker run -d -p 8080:8080 --name spring-app spring-hello-world
```

Run `curl localhost:8080` to view the output from the webserver. It should look like this:

```
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Java Spring Boot Server</title>
</head>
<body>
    Hello from Docker
</body>
</html>
```

### Clean Up

Stop the container:

```
docker stop spring-app
```

Remove container:

```
docker rm spring-app
```

Remove the images (enter `y` when prompted):

```
docker system prune -a
```