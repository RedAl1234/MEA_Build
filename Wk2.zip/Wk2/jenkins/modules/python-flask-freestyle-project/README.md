# Python Flask Freestyle Project

<!--TOC_START-->
## Contents
- [Overview](#overview)
- [Tutorial](#tutorial)
	- [Prerequisites](#prerequisites)
		- [Virtual Machine](#virtual-machine)
		- [Jenkins User](#jenkins-user)
		- [Pythonadm User](#pythonadm-user)
		- [APT Packages](#apt-packages)
		- [Jenkins](#jenkins)
		- [Database](#database)
	- [Set Up Jenkins](#set-up-jenkins)
	- [Simple Flask Application](#simple-flask-application)
	- [Jenkins Job](#jenkins-job)
		- [Source Control Management](#source-control-management)
		- [Parameters](#parameters)
		- [Build](#build)
	- [Access the Flask Application](#access-the-flask-application)
- [Exercises](#exercises)
	- [Try this on Another Project](#try-this-on-another-project)
	- [Secrets](#secrets)

<!--TOC_END-->
## Overview
This module covers a basic deployment of a Python Flask server with Jenkins, using a systemd service and a Freestyle Project.

Included in this module folder is a Python Server that uses the Flask framework.

The sample project included for this also has a systemd service configuration included, for running the application as the `pythonadm` user.

Please note that, because of systemd, *this example will not work inside a docker container*.

## Tutorial

This tutorial assumes that you have knowledge in the following areas:
- Python/Flask
- Databases
- Linux

### Prerequisites
There are a few prerequisites for this module, so make sure the requirements have been configured on your machine by completing the steps below.

#### Virtual Machine

Spin up a virtual machine in your cloud provider of choice with the following configuration:
- Ubuntu LTS 18.06
- Recommended 2GB of RAM
- Network connections allowed on ports `22`, `5000` and `8080`

Connect to this VM via SSH. The following commands in this tutorial should be run on this VM via this SSH connection.

#### Jenkins User
The `jenkins` user is the user that is going to be running the Jenkins web application, including any scripts started from Jenkins as well.

On your newly created VM, run the following command to create the Jenkins user:

```bash
sudo useradd -m -s /bin/bash jenkins
```

Don't worry if you get an error stating that the Jenkins user already exists.

Because the `jenkins` user is going to have to install things like service scripts, Jenkins will need to be able to run some commands as `sudo`.

Open up the sudoers file by running `sudo visudo` and add this to the bottom of the file:

```text
jenkins     ALL=(ALL:ALL) NOPASSWD:ALL
```

Write your changes by entering `Ctrl+O` and hitting `Enter`, then close the file using `Ctrl+X`.

This configuration will allow the `jenkins` user to run *any* commands with `sudo`, which isn't ideal but will be fine for this example.

#### Pythonadm User
This `pythonadm` (Python Admin) user will be the user that *runs* your Flask application.

Its important to have a separate user to run your applications because this particular user will have very limited privileges, so if the application were to be compromised, the attackers would not gain elevated permissions on the machine.

The user can be created with this command, very similar to the command that creates the `jenkins` user:

```bash
sudo useradd -m -s /bin/bash pythonadm
```

#### APT Packages
Various packages from APT will be required:

| Package | Reason |
|---------|--------|
|`openjdk-11-jre`|Java 11 Runtime, Jenkins runs on Java 11 as of release 2.357.|
|`python3`|Flask applications use Python of course, Python 3 is currently the supported version.|
|`python3-venv`|It is good practice to run Python applications with a virtual environment.|
|`git`|Git will be required to download Flask applications from source code repositories. These will likely be hosted on GitHub or GitLab.|

Install these packages using this command:

```bash
sudo apt update
sudo apt install -y openjdk-8-jre python3 python3-venv git
```

#### Jenkins

Jenkins will need to be installed and running for this tutorial.

If you have already got Jenkins running and configured then feel free to skip this step.

Download the Jenkins WAR file to the Jenkins home directory with the following command:

```bash
sudo su - jenkins -c "curl -L https://updates.jenkins-ci.org/latest/jenkins.war --output jenkins.war"
```

This **W**eb application **Ar**chive (WAR) file contains the Jenkins web application, which can be executed using Java.

A systemd service script can be used to control this application. The command below will create this script in `/etc/systemd/system/jenkins.service`:

```ini
sudo tee /etc/systemd/system/jenkins.service << EOF > /dev/null
[Unit]
Description=Jenkins Server
[Service]
User=jenkins
WorkingDirectory=/home/jenkins
ExecStart=/usr/bin/java -jar /home/jenkins/jenkins.war
[Install]
WantedBy=multi-user.target
EOF
```

Now the script has been installed, run the following to run it:

```bash
# reload changes to the service scripts
sudo systemctl daemon-reload
# start the jenkins service
sudo systemctl start jenkins
```

Enter this command to make sure this was successful:

```bash
sudo systemctl status jenkins
```

You should see an output log similar to the following that states that the `jenkins` service is active and running:

```bash
● jenkins.service - Jenkins Server
   Loaded: loaded (/etc/systemd/system/jenkins.service; disabled; vendor preset: enabled)
   Active: active (running) since Mon 2020-09-28 10:03:32 UTC; 40min ago
```

#### Database

You will need to create a MySQL 5.7 database for the Flask application to connect to. This tutorial assumes you know how to do this – if you are unsure, check the *Databases* topic for a tutorial on how to achieve this.

It doesn't matter how you create this database, as long as it is accessible by your Jenkins virtual machine. 

You will need the following information from the database:
- Username
- Password
- Host (Public IP address for example)
- Database Name

### Set Up Jenkins

On your browser, connect to your Jenkins VM via its public IP address on port `8080`.

You will be prompted to enter the Jenkins Initial Admin Password. This can be retrieved by entering the following command on your VM's command line:

```bash
sudo cat /home/jenkins/.jenkins/secrets/initialAdminPassword
```

Proceed through the standard setup process to create an admin user and install the recommended plugins.

### Simple Flask Application

To facilitate this tutorial a Flask application will be needed. 

The example being used for this tutorial can be found here: https://gitlab.com/qacdevops/flask-example

This is a very simple application that allows the user to register for an account and create blog posts.

### Jenkins Job

Using the Jenkins instance installed on your machine, create a Freestyle Project called `flask-app`.

![freestyle-job](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/000.png)

Click on the `Configure` button on the left-hand side of the Job page.

![configure](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/001.png)

#### Source Control Management

Configure the *Source Control Management* section to be set up with the Git repository for the *Simple Flask Application*:
- Select the the *Git* option
- Set the *Repository URL* to `https://gitlab.com/qacdevops/flask-example`

![scm-section](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/002.png)

#### Parameters

This particular application will sometimes need to have the tables in the database recreated. There is a script, `create.py` included in the example project provided which does this.

Because this should be optional, a parameter can be made to stop this happening every time the application is deployed.

Under the *General* section, check the *This project is parameterised* option and add a *Boolean Parameter*.

Set the *Name* to be `RECREATE_TABLES` and the *Description* to be *Drop and create all tables.*:

![Jenkins Parameter](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/003.png)

#### Build

We now need to define the build steps for this job. For this we are going to create a Shell script to be executed every time the job is run.

In the *Build* section, click on `Add build step` and select `Execute shell` from the drop-down options.

![build-step](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/004.png)

You will see the following text box:

![execute-shell](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/005.png)

The Shell script has been provided below. Take time to read through the comments in the script, they should give you a decent understanding as to what the script is doing on the various steps.

```bash
# ==================================
# CHANGE THESE VALUES

SECRET_KEY='YOUR_SECRET_KEY'
MYSQL_USER='YOUR_MYSQL_USER'
MYSQL_PASSWORD='YOUR_MYSQL_PASSWORD'
MYSQL_HOST='YOUR_MYSQL_HOST'
MYSQL_DATABASE='YOUR_MYSQL_DATABASE'
# ==================================

# install pip dependencies
python3 -m venv venv
. venv/bin/activate
pip install -r requirements.txt

# remove the old project files
sudo rm -rf /opt/flask-app
# copy new project files into the installation directory
sudo mkdir /opt/flask-app
sudo cp -r . /opt/flask-app
# make sure that the files are owned by pythonadm because that is the user running this application
sudo chown -R pythonadm:pythonadm /opt/flask-app

# configure the service script
# the service script has templated values, the sed command here is replacing them for the actual values which are defined at the start of this script
# once the values have been replace, the file is being saved to /etc/systemd/system/flask-app.service
sed -e "s/{{SECRET_KEY}}/${SECRET_KEY}/g" \
    -e "s/{{MYSQL_USER}}/${MYSQL_USER}/g" \
    -e "s/{{MYSQL_PASSWORD}}/${MYSQL_PASSWORD}/g" \
    -e "s/{{MYSQL_HOST}}/${MYSQL_HOST}/g" \
    -e "s/{{MYSQL_DATABASE}}/${MYSQL_DATABASE}/g" \
    flask-app.service \
    | sudo tee /etc/systemd/system/flask-app.service

# when a change is made to a service unit (which the command above just did), these changes must be reload
sudo systemctl daemon-reload

# recreate the tables in the database if opted for
if ${RECREATE_TABLES}; then 
    # set the database uri so that the create script understands how to connect to the database 
    # this is using the values set at the top of the script
    export DATABASE_URI="mysql+pymysql://${MYSQL_USER}:${MYSQL_PASSWORD}@${MYSQL_HOST}/${MYSQL_DATABASE}"
    python create.py
fi

# make sure that the new flask application is running, also stopping the current running flask application
sudo systemctl restart flask-app
```

Copy and paste this script into the build step. You will need to replace the values of the environment variables in the first section for the application to run correctly:

- `SECRET_KEY` can be any value - it is a secret key attached to the web application's forms used to protect against CSRF attacks
- `MYSQL_USER` needs to be the user created when the database was created - this should most likely be "root"
- `MYSQL_PASSWORD` needs to be the password your database is expecting for the user
- `MYSQL_HOST` needs to be the URL location for your database, most likely the database's public IP address (you may also need to specify the port it's connecting to as well, most likely `3306`)
- `MYSQL_DATABASE` needs to be the name of the database created in your MySQL instance

Finally, hit the `Save` button at the bottom of the screen.

### Access the Flask Application

Hit the `Build Now` button of your Job's page to run the build script.

![build-now](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/006.png)

The Flask application should now be running on port `5000`, check this in a browser or with the `curl` command.

If you are having trouble accessing the application, then try running `sudo systemctl status flask-app` on the terminal to see errors if the application has failed to start.

## Exercises

### Try this on Another Project
Use another Python Flask application and deploy it as a systemd service using the tutorial above.

If you don't have a Flask app available to you then feel free to use this provided example: https://github.com/qac-devops/python-flask-example

### Secrets
At the moment, important information about the MySQL database connection is in the job, which will also be shown in the logs.

Change this so that those variables are stored in the Jenkins Credentials Plugin.
