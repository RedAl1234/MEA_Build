# Selenium Freestyle project

<!--TOC_START-->
## Contents
- [Overview](#overview)
- [System requirements](#system-requirements)
	- [VM networking](#vm-networking)
	- [VM hardware](#vm-hardware)
	- [Operating system](#operating-system)
	- [VCS](#vcs)
	- [Project build tool](#project-build-tool)
	- [Compile](#compile)
	- [Run](#run)
	- [Browser](#browser)
	- [CI server](#ci-server)
- [Tutorial](#tutorial)
- [Exercises](#exercises)

<!--TOC_END-->
## Overview

Automated tests like Selenium play a big role in the testing world as it allows the testing of applications front end to be automated. 
With the emergence of DevOps one of the tasks that should be taken over by the CI server is running the selenium tests compared to the developer doing it manually.

This module will cover things like:
* System requirements
* How to set up a Freestyle job on Jenkins for working with selenium

**Note**: This module will be using a simple Java application that will contain a simple Selenium test. 
In the case of you having a custom project, additional configurations may be required.

## System requirements

A virtual machine in the cloud with the following requirements should be used.

### VM networking

Ensure that the SSH port 22 is accessible to you. 
Additionally, port 8080 should be open as well for Jenkins access. 

### VM hardware

It is recommended to have at least 2 vCPUs and 4GB of RAM.

### Operating system

This module uses the Ubuntu 20.04 LTS operating system. 
Although it should work on previous versions of Ubuntu as well, but additional configurations may be required.

### VCS

Git used for pulling the example project. 

### Project build tool

Maven is the build tool for this example project Java application.

### Compile

JRE version 11 is required to compile the project.

### Run

JDK version 11 is required to compile the project.

### Browser

Google Chrome is the browser used for the automated tests execution. Ensure the browser version is 83.

### CI server

The CI server is Jenkins.

## Tutorial

This tutorial will take you through the steps required to run selenium tests on jenkins freestyle project.

SSH into the VM.

Install the required software from system requirements.

If you aren't sure how to accomplish it you can use the following commands to do it.

<details>

<summary>Show commands</summary>

Instead of executing the commands manually one by one, it's easier to create one script that will do it all.

Execute the following command to create a new script file:

```shell script
sudo nano install-requirements.sh
```

Paste the following commands into the script:

```shell script
#!/bin/bash
if type apt > /dev/null; then
    pkg_mgr=apt
    if [ $(uname -v) == *Debian* ]; then
      java="default-jre"
    else
      java="openjdk-11-jre"
    fi
elif type yum /dev/null; then
    pkg_mgr=yum
    java="java"
fi
echo "updating and installing dependencies"
sudo ${pkg_mgr} update
sudo ${pkg_mgr} install -y ${java} wget git > /dev/null
echo "installing jre"
sudo apt install default-jre -y
echo "installing maven"
sudo apt install maven -y
echo "installing git"
sudo apt install git -y
echo "installing chrome"
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo apt install xdg-utils libxss1 libgtk-3-0 libgbm1 libappindicator3-1 fonts-liberation -y
sudo dpkg -i google-chrome-stable_current_amd64.deb
sudo apt --fix-broken install
rm google-chrome-stable_current_amd64.deb
echo "configuring jenkins user"
sudo useradd -m -s /bin/bash jenkins
echo "downloading latest jenkins WAR"
sudo su - jenkins -c "curl -L https://updates.jenkins-ci.org/latest/jenkins.war --output jenkins.war"
echo "setting up jenkins service"
sudo tee /etc/systemd/system/jenkins.service << EOF > /dev/null
[Unit]
Description=Jenkins Server

[Service]
User=jenkins
WorkingDirectory=/home/jenkins
ExecStart=/usr/bin/java -jar /home/jenkins/jenkins.war

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable jenkins
sudo systemctl restart jenkins
sudo su - jenkins << EOF
until [ -f .jenkins/secrets/initialAdminPassword ]; do
    sleep 1
    echo "waiting for initial admin password"
done
until [[ -n "\$(cat  .jenkins/secrets/initialAdminPassword)" ]]; do
    sleep 1
    echo "waiting for initial admin password"
done
echo "chrome version is: "
google-chrome-stable --version
echo "initial admin password: \$(cat .jenkins/secrets/initialAdminPassword)"
EOF
```

Save the file and exit.

Add execute permission for the script file by executing the following command:

```shell script
sudo chmod +x install-requirements.sh
```

Execute the script by running the following command:

```shell script
./install-requirements.sh
```

</details>

Go to Jenkins, set up your admin user and install the suggested plugins.

Create a new Freestyle project, for the name set it to *selenium-ci*.

Once in the project menu, specify the url for the example project as:
 
```
https://github.com/tvaidotas/selenium-java-ci.git
```
 
Use *master* branch and set up the polling at every minute.

Make Jenkins delete the workspace before build starts.

Add a *Build step* to *Execute shell* and paste the following commands:

```shell script
chown jenkins:jenkins /home/jenkins/.jenkins/workspace/selenium-ci/chromedriver
chmod +x /home/jenkins/.jenkins/workspace/selenium-ci/chromedriver
mvn test
```

Click on *Build now* and it should trigger the job. 
Hopefully it will succeed.

## Exercises

There is no exercise for this module.
