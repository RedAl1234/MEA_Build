# Jenkins Introduction and Installation

## Overview
Jenkins is a self-contained, open-source automation server used to automate a variety of tasks related to building, testing, delivering, and deploying software.

Jenkins can be installed through native system packages, container tools such as Docker, or simply ran standalone by a machine with the Java Runtime Environment (JRE) installed.

This module will discuss the purpose of Jenkins, as well as walk through how to install and set up a Jenkins instance through the graphical web interface.

## What is the need for Jenkins?
As mentioned earlier, Jenkins is known as an **automation server** (also referred to as a CI or build server). These tools are a centralised, stable environment for building distributed development projects.

These automation servers tend to be linked to a Version Control System, such as Git. The server can be built to check for updates, or *poll*, the VCS repository and perform project builds automatically. 

Git is one example of a tool that can link with Jenkins, but in reality, there are dozens of CI, DevOps, testing, analysis and documentation tools that can integrate with it. 

As an open-source tool, Jenkins has a strong community-driven set of resources alongside core developer support. Because of this, Jenkins is one of the most popular automation servers in the industry and is used in thousands of projects around the world.

## Tutorial

### Installing Jenkins

#### Docker (Any Platform)
To install Jenkins through Docker, you will, of course, need Docker installed! With Docker, you can use the following command to install Jenkins:

```bash
docker run -d -p 8080:8080 --name jenkins jenkins/jenkins:lts-alpine
```

#### Windows
An installer can be downloaded and run to get Jenkins running on Windows here: https://jenkins.io/download/

#### Linux
To install Jenkins on Linux, put the below script in a file on the machine you wish to install Jenkins on and execute it:

```bash
#!/bin/bash
if type apt > /dev/null; then
    pkg_mgr=apt
    if [ $(uname -v) == *Debian* ]; then
      java="default-jre"
    else
      java="openjdk-11-jre"
    fi
elif type yum /dev/null; then
    pkg_mgr=yum
    java="java"
fi
echo "updating and installing dependencies"
sudo ${pkg_mgr} update
sudo ${pkg_mgr} install -y ${java} wget git > /dev/null
echo "configuring jenkins user"
sudo useradd -m -s /bin/bash jenkins
echo "downloading latest jenkins WAR"
sudo su - jenkins -c "curl -L https://updates.jenkins-ci.org/latest/jenkins.war --output jenkins.war"
echo "setting up jenkins service"
sudo tee /etc/systemd/system/jenkins.service << EOF > /dev/null
[Unit]
Description=Jenkins Server

[Service]
User=jenkins
WorkingDirectory=/home/jenkins
ExecStart=/usr/bin/java -jar /home/jenkins/jenkins.war

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable jenkins
sudo systemctl restart jenkins
sudo su - jenkins << EOF
until [ -f .jenkins/secrets/initialAdminPassword ]; do
	sleep 1
	echo "waiting for initial admin password"
done
until [[ -n "\$(cat  .jenkins/secrets/initialAdminPassword)" ]]; do
	sleep 1
	echo "waiting for initial admin password"
done
echo "initial admin password: \$(cat .jenkins/secrets/initialAdminPassword)"
EOF
```

*Please note, if you are using the below script, you will need `sudo` access on the machine you execute it on. Sudo will give you administrative access to your Linux machine, which in turn will allow you to install Jenkins.*

### Unlocking Jenkins
To begin the setup process for Jenkins, you will need to go to `port 8080` on your machine.

Jenkins setup requires an initial admin password to *unlock* the setup and installation. This is a simple verification process Jenkins includes to ensure an administrator is installing the tool.

The initial admin password is stored on the file system of the machine that Jenkins is running on. The page states where this file is located - you just need to copy the contents of it into the text field and click `Continue`.

![Jenkins Initial Admin Password](https://qacommunity.blob.core.windows.net/images/jenkins-installation-wizard-000.PNG)

```bash
cat /var/jenkins_home/secrets/initialAdminPassword
```

### Customize Jenkins
Jenkins is highly configurable due to the amount of plugins that you can install.

This is fantastic, but if you are new to Jenkins, you might not have much of an idea about what plugins you would want!

Fortunately, the setup gives you the option to install suggested plugins - select this option:

![Customize Jenkins](https://qacommunity.blob.core.windows.net/images/jenkins-installation-wizard-001.PNG)

Jenkins will then begin to install its suggested plugins. For this part, there isn't much to do but wait! 

If plugins are failing to install, make sure that you have the latest version on Jenkins installed.

![Plugin Installation](https://qacommunity.blob.core.windows.net/images/jenkins-installation-wizard-002.PNG)

### Create the First Admin User
You will then be presented with a form to create the first admin user.

You can either fill in the form to have your details saved into the first admin account, or *continue as admin*.

If you pick the second option, the admin user account name is `admin` and the password will remain initial admin password that you entered.

Be careful not to enter actual passwords and information here, especially if you are connected to a Jenkins instance over the internet with no TLS or SSL configured (HTTPS secure connection).

![Create First Admin User](https://qacommunity.blob.core.windows.net/images/jenkins-installation-wizard-003.PNG)

### Instance Configuration
All you will need to for this step is to select `Save and Finish`.

![Instance Configuration](https://qacommunity.blob.core.windows.net/images/jenkins-installation-wizard-004.PNG)

### Dashboard
Now that you have Jenkins set up and installed, you will be presented with the Jenkins dashboard on your screen:

![Dashboard](https://qacommunity.blob.core.windows.net/images/jenkins-installation-wizard-005.PNG)

#### Dashboard Links

|Link|Description|
|----|-----------|
|New Item| This is for creating new **jobs** in Jenkins. Jobs are essentially scripts that can be triggered.|
|People| The users that are registered to this instance of Jenkins.|
|Build History|A graph displaying the jobs that have been executed over time with this instance of Jenkins.|
|Manage Jenkins|This is where to go for setting up plugins and other administrative settings for Jenkins.|
|My Views|You can customise which jobs are listed on the dashboard and how they are presented.|
|Credentials|In the Jenkins jobs you create, you may need to authenticate with external services that you use, such as GitHub. Credentials for these external services can be stored securely here, and accessed by jobs and plugins when they need them.
|Lockable Resources|This plugin allows for the definition of lockable resources that can be used by builds, such as printers, phones, and computers. If a build requires a resource that is already locked, it will wait for the resource to be free. You can define a lock-priority globally or on a per-job basis.|

**Congratulations, you have installed the Jenkins instance on a machine!**

## Exercises
There are no exercises for this module.
