# Builds

## Overview
A Jenkins **build** is the result of a project execution (job) in Jenkins.

Builds for projects can be seen on the `Build History` section of the project dashboard:

![Build History](https://qacommunity.blob.core.windows.net/images/jenkins-builds-1.png)

Builds are named by the order that they were executed. The first build of the project executed will be called `#1`, the second build will be called `#2`, etc.

## Build Status
The status of the build can have a few different values:
- `SUCCESS`: **The build succeeded**! If all the build steps complete successfully, this will be the build status.
- `FAILURE`: The build failed. If any of the steps exit with a *non-zero status* (if they throw an error), then the build status will change to failed.
- `ABORTED`: The build aborted before it finished. This exit status is more uncommon; it must be set either by yourself or plugins that are being used in the project.

## Build Steps
Build steps are the different actions you configure - essentially, what your job is going to do. 

Depending on your situation, this could accomplish many different tasks:
  - **Java**: If you have a Java project that you want to automate builds for, you may be running commands or using plugins for running Maven, Gradle or Ant.
  - **Docker**: Docker images can be built for your project.
  - **NodeJS**: Installing dependencies for your Node application before packaging it up for deployment at a later date.
  - **Any Other Platforms**: With the combination of shell scripting and plugins that are available for Jenkins, the sky truly is the limit with what you can automate in a Jenkins build.

We can add build steps by selecting the `Add build step` drop-down button and  selecting the type of build step that we would like to use:

![Jenkins Build Step](https://qacommunity.blob.core.windows.net/images/jenkins-builds-001.PNG)

The type of build steps that are available will depend on the Jenkins' Plugins that you have installed.
For the example shown above, we can see that some plugins must be installed for Gradle, Maven and GitHub.

Most of the time you can get what you need out of a build step from shell scripting.
It's preferable to separate your shell scripts into different build steps, to keep you project more maintainable.

For example you could have separate build steps for compiling, testing and deployment.

## Console Output
The console output is one of the main areas you will be checking for information and debugging purposes of a build.

This section includes the output for any shell scripts and plugins that have been executed in the build step for a project.

The console output can be navigated to quickly by selecting the blue or red bulb on the build history.

Here is a very simple console output example:

![Console Output](https://qacommunity.blob.core.windows.net/images/jenkins-builds-2.png)

## Post-build Actions
**Post-build actions** are plugins that can be ran after you execute all the build steps.

You can add a post-build action by selecting the `Add post-build action` drop-down button and then selecting a post-build action from the list.
Theses actions can be set to run, or not run, depending on the success of the build steps.

Even if the build failed, you can still run post-build actions as an immediate response to the build failing. For example, you may want to send an email notification on a build failure.

If the build succeeds, you might want to store the built application files as an artifact for access later on.

### Artifacts
**Build artifacts** are immutable files that are created as result of the build.

You have complete control over which files you would like to store as an artifact. This can be configured in the `Post-build Actions` section of the project configuration.

The example below will archive any files and store them as artifacts for the project:

![Archive Artifacts](https://qacommunity.blob.core.windows.net/images/jenkins-builds-003.PNG)

#### Accessing Artifacts
Once the job has executed, the artifacts are then available on the job dashboard:

![Build Artifacts](https://qacommunity.blob.core.windows.net/images/jenkins-builds-004.PNG)

## Tutorial
This tutorial will guide you through creating some builds here, focusing on build step configuration, statuses and storing artifacts.

### Create a Job
First, we will need a new Jenkins job to work on. Create a new job and name it whatever you like!

### Add a Build Step
Let's add a build step that we know will succeed. Select the `Add build step` button and add an `Execute shell` build step.

Add the following script into the `Command` field:
```bash
#!/bin/bash
echo "Hello from the Jenkins job named: ${JOB_NAME}"
```

### Run the Job
Save the job and then build it. You should then have one successful build in your history for that job.

Once you navigate to the console output, you should see an output like this:

![Jenkins Build Output](https://qacommunity.blob.core.windows.net/images/jenkins-builds-3.png)

### Make the Build Fail
Now that the last build succeeded, let's see what a failed build looks like!

To do this, we will make the script we added to the command box *"fail"*.

Jenkins will treat any script or application exiting with a non-zero status as a failure. So, to create a failed build, add `exit 1` to the script box, which will make the script exit with a code of `1`:

```bash
#!/bin/bash
echo "Hello from the Jenkins job named: ${JOB_NAME}"
exit 1
```
![Jenkins Failed Build Output](https://qacommunity.blob.core.windows.net/images/jenkins-builds-4.png)

### Abort a build

You can remove the `exit 1` from the build step to fix it.

Next, uyou are going to make the build run for 10 minutes, which will give you plenty of time to abort it.

Here is the code that should be in your script box now:

```bash
#!/bin/bash
echo "Hello from the Jenkins job named: ${JOB_NAME}"
sleep 600
```

Click `Save` and `Build Now` to begin the build.

To abort the build, click the red `x` on the in-progress build.

*Note: While the build is in progress, it will have the status of the previous build, but with a spinning icon.*

![Jenkins Running Build](https://qacommunity.blob.core.windows.net/images/jenkins-builds-5.png)

This will result in an `aborted` build, the console output will look like this:

![Jenkins Aborted Build Output](https://qacommunity.blob.core.windows.net/images/jenkins-builds-6.png)


### Fix the Build and Create Artifacts 

Removing the `sleep 600` from the build step will ensure the build doesn't take 10 minutes to complete!

Next, change the script to create several files, and then put them in a zip archive called `archive.zip`:

```bash
#!/bin/bash
echo "Hello from the Jenkins job named: ${JOB_NAME}"
touch 1.txt 2.txt 3.txt 4.txt 5.txt
zip archive.zip *.txt
```

A `Post-build Action` must be configured to archive the zip files. Configure a simple post-build action to archive the created `.zip` file - refer to the [Artifacts](#artifacts) section for guidance on how to configure this!

### Finish Up
Finish up by running the job. You should see artifacts on the project dashboard! 

If this isn't present, try refreshing the page.

## Exercises
There are no exercises for this module.
