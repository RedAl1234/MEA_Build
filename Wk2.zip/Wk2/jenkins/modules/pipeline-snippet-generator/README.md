# Pipeline Snippet Generator

<!--TOC_START-->

<!--TOC_END-->
## Overview

Jenkins Pipeline Snippet Generator is a very useful piece of "Dynamic Documentation".
Jenkins, and it's associated plugins, all register their methods with the Snippet Generator as templates which you can use to build code snippets for your Pipelines in a kind of What You See Is What You Get kind of environment.

As it is dynamic it is constantly being updated when you add new plugins or make changes to existing Pipelines.

It is most commonly used as a reference source for when you can't quite remember the syntax of various commands or their parameters, but is equally good for exploring the capabilities of your Jenkins server and finding new methods provided by plugins.

Your particular Pipeline Snippet Generator can be found:

`${YOUR_JENKINS_URL}/pipeline-syntax`

Or you can access a Project Specific one via the `Pipeline Syntax` link below the `Pipeline > Script` input when creating/editing a Pipeline.

![Pipeline Syntax](https://imgur.com/M37TXuC.jpg)

This will take you to a form where you can explore the various methods at your disposal:

![Pipeline Snippet Generator](https://imgur.com/gHQOUDH.jpg)

Here we can use the `Sample Step` drop down select to change the underlying form template and generate various snippets.

For instance, by selecting `dir: Change current directory` you are given a `Path` input box which you can provide with something like `$JENKINS_HOME/jobs/$JOB_NAME/builds/$BUILD_NUMBER/archive` which would generate:

```bash
dir('$JENKINS_HOME/jobs/$JOB_NAME/builds/$BUILD_NUMBER/archive') {
    // some block
}
```

`// some block` is a comment where you would put whatever steps you want to run within the specified directory.

Notice, however, that this isn't: 

`cd $JENKINS_HOME/jobs/$JOB_NAME/builds/$BUILD_NUMBER/archive`

It's important to remember that these are Jenkins Methods (i.e. you are instructing Jenkins directly to change dir) and not Shell Commands. 

There is a way, however, to specify a Jenkins Method that runs Shell Commands using the `sh: Shell Script` or `script: Run arbitrary Pipeline script` methods.

## Tutorial

There is no tutorial for this module.

## Exercises

There are no exercises for this module.

