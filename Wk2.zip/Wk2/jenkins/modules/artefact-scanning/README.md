# Artefact Scanning

<!--TOC_START-->
## Contents
- [Overview](#overview)
- [Artefacts](#artefacts)
	- [Compiled Code](#compiled-code)
	- [Dependencies](#dependencies)
- [OWASP Dependency-Check](#owasp-dependencycheck)
- [Tutorial](#tutorial)
	- [Prerequisites](#prerequisites)
	- [Plugin](#plugin)
	- [Build Stage](#build-stage)
	- [Scan Stage](#scan-stage)
	- [Report Stage](#report-stage)
- [Exercises](#exercises)

<!--TOC_END-->
## Overview

In this module, we will look at artefacts in software development and more specifically scanning them for security vulnerabilities.
 

## Artefacts
 
What is an artefact? The term is very broad in its definition, but it means anything that has been made as a result of developing software. This could refer to documentation, risk assessment, architecture diagrams etc., but also could mean compiled code and dependencies.
 
We are going to be referring to compiled code and dependencies for this module.
 
Let's look at the two different types of artefacts.
 

### Compiled Code
 
If the artefact in question is compiled code, then we need to scan these files for vulnerabilities to avoid errors when deploying the app.

The entire code base will have been compressed into this one file; as a result, there is a high potential for things to go wrong. It is therefore important to check that the file is secure and tested correctly.
 

### Dependencies
 
If we are talking about dependencies then we need to look no further than the name, our app depends on these artefacts so it is important they aren't vulnerable in any way.
 

## OWASP Dependency-Check
 
OWASP Dependency-Check is an open-source tool that will scan compiled code or dependencies and find any security risks and present them to you.
 
The security advice it provides will be put in a report and given a CVE (Common Vulnerability and Exposure) entry to help you find a solution.
 
It works with many different languages, some being in an experimental stage.

You can use the tool directly in the command-line but we will be using the Jenkins Plugin.
 

## Tutorial
 
In this tutorial, we are going to scan a .jar file using OWASP Dependency-Check
 

### Prerequisites
 
For this tutorial, you will need a virtual machine with Jenkins installed and an admin user configured.
 
You will also need to install JDK and Maven
 
```bash
sudo apt update
sudo apt install maven default-jdk -y
```
 

### Plugin
 
Go to `Manage Jenkins` and `Manage Plugins`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/001.png)](https://gyazo.com/9970746496ab678eab06681e378773ea)
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/003.png)](https://gyazo.com/40d5e580e5ad26bfa49071bc827ab008)
 
Click `Available` and type `OWASP Dependency-Check`
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/005.png)](https://gyazo.com/78fef822989178995ff76bbb61a33b97)
 
Tick the correct plugin and click `Install without restart`.
 
Then, wait for the plugin to install.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/007.png)](https://gyazo.com/92cdbb5a5ea79f93eab1fcce21835308)
 
Now go to `Manage Jenkins` and `Global Tool Configuration`
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/009.png)](https://gyazo.com/9970746496ab678eab06681e378773ea)
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/011.png)](https://gyazo.com/0edafc056c7960bee1a376ce5030b5a6)
 
Scroll down to `Dependency-Check` click `Dependency-Check Installations` and give the installation a name. Then click `Save`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/013.png)](https://gyazo.com/69a789013fe67ec0bf049e4252fd23fe)
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/015.png)](https://gyazo.com/49551ad0a66e93adc83b227d2ada7d71)
 

### Build Stage
 
Now we have installed the OWASP Dependency-Check plugin we will create the job.
 
Go to `New Item` give the job a name and select freestyle.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/017.png)](https://gyazo.com/e04d334838a16fae00d701998fc69da1)
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/019.png)](https://gyazo.com/9c62195dbbc1f61361e2bccb515b5b8f)
 
Now in the job configuration, under `Source Code Management`, select `Git` and type in this URL.
 
[https://gitlab.com/qacdevops/multi-stage-build-exercise.git](https://gitlab.com/qacdevops/multi-stage-build-exercise.git)
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/021.png)](https://gyazo.com/6a094a751842b6b173095ed8720611d5)
 
And in the branch section type `*/artifact-scanning`.
 
Now, click `Add build step` and select `Execute Shell`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/023.png)](https://gyazo.com/8e2ce623965e309a42886d8ce341d33c)
 
And for this stage simply type,
 
```bash
mvn clean package
```
 
This will use the Maven build tool to compile the Java codebase into a .jar file. Feel free to hit `Build now` to see if the build is successful.
 

### Scan Stage
 
Now we are going to scan the .jar file for security vulnerabilities.
 
In the job configuration, click `Add build step`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/025.png)](https://gyazo.com/8e2ce623965e309a42886d8ce341d33c)
 
And select `Invoke Dependency-Check`, this is going to use the plugin we installed earlier.
 
Select the `Dependency-Check Installation` we configured before.
 
In the arguments section, enter the following
 
```bash
--project [NAME OF YOUR JENKINS JOB]
--scan target/*.jar
--format XML
```
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/027.png)](https://gyazo.com/0bfdc57cb89cd036f021a1dcc96deede)
 
Then click `Save`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/029.png)](https://gyazo.com/49551ad0a66e93adc83b227d2ada7d71)
 
Now your Jenkins job is going to use OWASP Dependency-Check to scan your .jar file for any vulnerabilities.
 

### Report Stage
 
The last thing to do is to tell Jenkins what to do with the report that the Dependency-Check creates.
 
Click `Add post-build action`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/031.png)](https://gyazo.com/e22a0bea780e5880090c4a5813e69d73)
 
And select `Publish Dependency-Check results`.
 
You can leave the `XML Report` section blank as the default is fine for what we need.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/033.png)](https://gyazo.com/182f80b3d54565951e9e6c060a5e6fd2)
 
Then click `Build Now` and let the job run and succeed.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/035.png)](https://gyazo.com/c10a88b6756a2a9800e7e658ab02a8cf)
 
Once the job is complete, refresh the page.
 
Now you should see a Dependency-Check Trend graph in the status section of the job.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/037.png)](https://gyazo.com/379a16f3367210424c63c2c2259d0675)
 
And if you go to the individual job you should see the Dependency-Check section.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/039.png)](https://gyazo.com/4c4c33d7dc7af2edf742e1d49970af7b)
 
Here you can see all the security risks the Dependency-Check found along with the CVE number and the severity of the risk.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/artefact-scanning/041.png)](https://gyazo.com/47f4e4312a1d4932d6c9c2c8c31d5f3f)
 

## Exercises
 
Change the `Post Build` step and add a `Risk Gate Threshold` to only allow 1 critical risk.
Then rerun the job to see the outcome.
