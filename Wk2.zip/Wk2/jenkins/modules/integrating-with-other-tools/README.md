# Integrating with Other Tools

<!--TOC_START-->
## Contents
- [Overview](#overview)
- [Support and Plugins](#support-and-plugins)
- [Tutorial](#tutorial)
- [Exercises](#exercises)

<!--TOC_END-->
## Overview

Jenkins has the capability to **integrate with lots of other tools** with relative ease, which makes it very powerful.

It does this through the use of **built-in support**, and also **plugins**.

Examples of Jenkins integrating with other tools would be:

- Integrating with a **messaging system** (Microsoft Teams, Slack, etc) to automatically notify certain people when builds succeed/fail.
- Integrating with a **Docker image repository** (DockerHub, Azure Container Registry, etc) to automate the tagging and pushing of newly built images.
- Integrating with **Git** (or another VCS) and a **Version Control Provider** (GitHub, GitLab, etc) to set up Webhooks. This allows Jenkins jobs to automatically build after a commit has been pushed to the Version Control Provider.

and <u>much, much more</u>!

## Support and Plugins

Jenkins has an **unparalleled plugin ecosystem** to support practically every tool.

Whether your goal is continuous integration or continuous delivery/deployment (or something else entirely) Jenkins can help **automate it**.

Some plugins are _built-in_ and readily available when you first start Jenkins, and some require a _separate install_ (which is easy to do through the Jenkins GUI).

## Tutorial

In this tutorial, we will be _running a Jenkins pipeline that is making use of the Docker Pipeline plugin_.

We will go through one way of **easily deploying new versions of an application**, and also how to **rollback to a previous version**, should you need to.

**Before starting the tutorial, you will need to:**

- fork, or make a copy of, [this repository](https://gitlab.com/qacdevops/chaperootodo_client)
- have access to port 80 on your machine

Once you're ready:

1. Install and set up Jenkins, using this script:

```bash
#!/bin/bash
if type apt > /dev/null; then
    pkg_mgr=apt
    if [ $(uname -v) == *Debian* ]; then
      java="default-jre"
    else
      java="openjdk-11-jre"
    fi
elif type yum /dev/null; then
    pkg_mgr=yum
    java="java"
fi
echo "updating and installing dependencies"
sudo ${pkg_mgr} update
sudo ${pkg_mgr} install -y ${java} wget git > /dev/null
echo "configuring jenkins user"
sudo useradd -m -s /bin/bash jenkins
echo "downloading latest jenkins WAR"
sudo su - jenkins -c "curl -L https://updates.jenkins-ci.org/latest/jenkins.war --output jenkins.war"
echo "setting up jenkins service"
sudo tee /etc/systemd/system/jenkins.service << EOF > /dev/null
[Unit]
Description=Jenkins Server

[Service]
User=jenkins
WorkingDirectory=/home/jenkins
ExecStart=/usr/bin/java -jar /home/jenkins/jenkins.war

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable jenkins
sudo systemctl restart jenkins
sudo su - jenkins << EOF
until [ -f .jenkins/secrets/initialAdminPassword ]; do
    sleep 1
    echo "waiting for initial admin password"
done
until [[ -n "\$(cat  .jenkins/secrets/initialAdminPassword)" ]]; do
    sleep 1
    echo "waiting for initial admin password"
done
echo "initial admin password: \$(cat .jenkins/secrets/initialAdminPassword)"
EOF
```

2. Install Docker and Docker-compose on your Jenkins machine:

```bash
curl https://get.docker.com | sudo bash

sudo curl -L "https://github.com/docker/compose/releases/download/1.25.5/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose

sudo chmod +x /usr/local/bin/docker-compose
```

3. Add the Jenkins user to the Docker group:

```bash
sudo usermod -aG docker jenkins
```

4. Restart your Jenkins service:

```bash
sudo systemctl restart jenkins
```

5. Set up DockerHub credentials in Jenkins:
   > - Go to Jenkins -> Credentials -> System -> Global credentials (unrestricted) and click `Add Credentials`.
   > - Add your DockerHub username and Password, as well as an ID of `docker-hub-credentials`:  
   >   ![jenkins-creds](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/integrating-with-other-tools/000.png)
   > - Click `OK`
6. Go to the project and change the **docker-compose.yaml** to the following (making sure to change `[your-dockerhub-username]`):

```bash
version: "3.7"
services:
  chaperoo-frontend:
    image: [your-dockerhub-username]/chaperoo-frontend:${app_version}
    build: .
    ports:
      - target: 80
        published: 80
    depends_on:
      - chaperoo-service
  chaperoo-service:
    image: jordangrindrod/chaperoo-service
    depends_on:
      - chaperoo-db
  chaperoo-db:
    image: jordangrindrod/chaperoo-db
    environment:
      - MYSQL_ROOT_PASSWORD=${DB_PASSWORD}
```

7. Go to the project and change the **Jenkinsfile** to the following (making sure to change `[your-dockerhub-username]`):

```bash
pipeline{
        agent any
        environment {
            app_version = 'v1'
            rollback = 'false'
        }
        stages{
            stage('Build Image'){
                steps{
                    script{
                        if (env.rollback == 'false'){
                            image = docker.build("[your-dockerhub-username]/chaperoo-frontend")
                        }
                    }
                }
            }
            stage('Tag & Push Image'){
                steps{
                    script{
                        if (env.rollback == 'false'){
                            docker.withRegistry('https://registry.hub.docker.com', 'docker-hub-credentials'){
                                image.push("${env.app_version}")
                            }
                        }
                    }
                }
            }
            stage('Deploy App'){
                steps{
                    sh "docker-compose pull && docker-compose up -d"
                }
            }
        }
}
```

> The variables at the top of the Jenkinsfile handle the app version we want to deploy, and whether or not we are deploying a new version of the application or rolling back to a previous version.

> After that, we have defined stages for the Pipeline.  
> These work with Docker and Docker-compose to:
>
> - Build an image
> - Tag the image with the correct version number (dictated by the `app_version` veriable) and push it to DockerHub (using the credentials you set up in step `5`)
> - Deploy the application.

> If we toggle the rollback version to anything other than `false` (such as `true`), the first two stages will act differently (the image **won't** be built, tagged or pushed to DockerHub).

8. Create a Jenkins Pipeline job called `chaperoo-test` and configure it as follows (replacing the `Repository URL` with your project):

![jenkins1](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/integrating-with-other-tools/001.png)

9. Click `Save`, and then Build the Job by clicking `Build Now` (this may take a little while):

![jenkins-build](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/integrating-with-other-tools/002.png)

> Here, Jenkins has built an image and tagged it as `v1`, and then pushed it up to your DockerHub using the credentials you configured in step `5`.  
> That image has then be used to deploy the application!

10. Go to `port 80` on your machine, and you should see the app running:

![app1](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/integrating-with-other-tools/003.png)

11. Go to the project and navigate to **src/components/Dashboard.vue**. Change the bottom of the file to:

```bash
.headerbox{
  background: green;
  margin: 0 13em;
  border-top-left-radius: 1em;
  border-top-right-radius: 1em;
}
```

> This _should_ update the application to have a green background, instead of light blue.

12. In the **Jenkinsfile**, change the `app_version` variable:

```bash
app_version = 'v2'
```

13. Build the job again:

![jenkins-build1](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/integrating-with-other-tools/004.png)

> Here, we have deployed a new version of our application, with a green/blue background!

![app2](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/integrating-with-other-tools/005.png)

> As you can see, this isn't a very good update and isn't doing what we wanted at all.  
> We need to **quickly** rollback to a more stable version, which in this case is `v1`.

14. Go to your Jenkinsfile and change the variables to:

```bash
app_version = 'v1'
rollback = 'true'
```

15. Build the job again, and go to port `80` once it has finished:

![app1](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/integrating-with-other-tools/006.png)

**Phew!** No more ghastly green/blue header box!

## Exercises

For this exercise, you will need to create a **free [Slack Workspace](https://slack.com/get-started#/)** with _2 channels_ in it (you can name these whatever you like).

On Jenkins, create a simple Freestyle job that:

- sends a notification to one channel after a **successful** build
- sends a notification to the other channel after a **failed** buld

Test these are working by running both a successful and failed build.

<details>
<summary>Hint</summary>

Use this documentation - https://plugins.jenkins.io/slack/

</details>
