<!--
{
    "prerequisites": [
        "git/remotes"
    ]
}
-->

# Source Code Management (SCM) 

<!--TOC_START-->
## Contents
- [Overview](#overview)
- [Repositories](#repositories)
	- [Multiple Repositories](#multiple-repositories)
	- [Branches to Build](#branches-to-build)
- [Triggering Builds from SCM Changes](#triggering-builds-from-scm-changes)
	- [Poll SCM](#poll-scm)
		- [CRON](#cron)
	- [Web Hooks](#web-hooks)
- [Tutorial](#tutorial)
		- [Prerequisites](#prerequisites)
	- [Setup Git Repositories](#setup-git-repositories)
	- [Upload the Provided Code](#upload-the-provided-code)
	- [Create the Jenkins Jobs](#create-the-jenkins-jobs)
	- [See the Application Working](#see-the-application-working)
	- [Web hook Configuration](#web-hook-configuration)
	- [Push a New Change](#push-a-new-change)
		- [Frontend](#frontend)
		- [Database](#database)
	- [Clean Up](#clean-up)
- [Exercises](#exercises)

<!--TOC_END-->
## Overview
Source Code Management, also referred to as Version Control, Source Control Management, SCM, or by simply referring to a tool such as Git, plays an important role in automating project builds and deployments with Jenkins.

The most common way of using SCM in one of your jobs is by utilising the suggested GitHub plugin for Jenkins.

## Repositories
Here we can see a very simple configuration for SCM in a project.
This example will download the `master` branch from this repository in the projects workspace:

![Jenkins SCM Configuration](https://qacommunity.blob.core.windows.net/images/jenkins-scm-000.PNG)

### Multiple Repositories
You may have noticed the `Add Repository` button which will allow us to download more than one repository at a time.

You would want to use this feature when more than one repository must be downloaded and built at the same time, for instance if one repository had a build dependency on another.
Otherwise it would be best to just have each repository built in another jenkins job so that each application component that you have can be built separately.

These are all downloaded into the same workspace but with different remotes setup for Git.
The last repository specified will be the one that is checked out to in the project workspace.

The first repository will have a remote set as `origin`, then for every repository added, a number will be appended.

For example, if you had 3 repositories being downloaded, the remotes would be named `origin`, `origin1`, `origin2`.

This default behavior isn't ideal, so it's recommended that you configure the name of the remotes yourself under the `Advanced...` option and in the `Name` field for each repository that you add.

### Branches to Build 
After specifying which repositories that you want to fetch, you can also choose which branches that you would like to build.
There are some quite complex different ways of checking out code that you can do here but usually being simple is better; there isn't a great deal of reasons to use anything other than the default value here (`*/master`) on simple projects.

If you would like to be able to build different branches easily then you could use a string parameter by entering something like `*/${BRANCH}` into the `Branch Specifier` field.

## Triggering Builds from SCM Changes
Jenkins jobs can be automatically triggered by changes in SCM.
When some changes have been push to a repository, the job can be triggered automatically by this.

There are two main ways to trigger builds in this way, depending on your situation:
- Poll SCM:
    This method is preferred if your instance of Jenkins is **not** accessible from the internet.
- Web Hooks (Preferred)
    Web Hooks are the preferred way of triggering build automatically from SCM if your instance of Jenkins can be accessed from the internet.

### Poll SCM
Poll SCM works by checking for changes on a schedule.
For the given schedule, Jenkins will make a request to your Git repository to check if there has been any changes.

This can be configured by selecting `Poll SCM` in the `Build Triggers` section.
A `Schedule` text box will then appear for you to configure the schedule.

#### CRON
The format for configuring the schedule is cron time format.
If you haven't heard of this before you can head over to [crontab guru](https://crontab.guru/#*_*_*_*_*); this site will give you a change to play around with different schedules quite easily.

The shortest time schedule that you can have is "every minute", which can be configured by entering `* * * * *` into the `Schedule` field.

### Web Hooks
As discussed before, this is the preferred method if your instance of Jenkins can be accessed from the internet.
This is because instead of constantly checking for new changes, the job can be triggered but a web hook which is really just a HTTP POST request to the jenkins server.

These Web Hooks can be configured on websites like GitHub, Bitbucket and GitLab to send a HTTP POST request to `/github-webhook/` on your Jenkins server.

This POST request will contain either a JSON or XML payload with information about which repository and branch has been updated.
Jenkins can then use this information automatically build the correct job.

To configure Web Hooks to work you will need to check the `GitHub hook trigger for GITScm polling` option under the `Build Triggers` section on your Jenkins job that you are wanting to automatically trigger.
You will then need to configure your Git service provider (such as GitHub) to send web hooks to `[JENKINS_ADDRESS]/github-webhook/`.

## Tutorial
In this demo we'll be automating the deployment of a simple website.
There are 3 main components to this application:
- Frontend
    A HTML and JavaScript website that makes calls to the Backend service.
    This website is hosted with NGINX as a webserver
- Backend
    A Python Flask server which can connect to a database
- Database
	MySQL Database.

#### Prerequisites
- Jenkins installed on a Ubuntu/Debian machine, ideally a virtual machine so that it can be deleted afterwards.
- Full `sudo` access for the `jenkins` user with no password required.
- Jenkins must not be installed in a Docker container for this demo
- Ports `8080` and `80` accessible to the machine

### Setup Git Repositories
For this example we are going to need couple of Git repositories.
Go ahead and create these repositories on GitHub:
- `jenkins-scm-frontend`
- `jenkins-scm-backend`
- `jenkins-scm-database`

### Upload the Provided Code
Upload the code found in the `frontend`, `backend` and `database` projects available at https://gitlab.com/qacdevops/jenkins-scm to these repositories that you created.
You can do this by initializing the folders as Git repositories, copying in the code and then configuring your GitHub repositories as remotes.

### Create the Jenkins Jobs
You will need a Jenkins job for each GitHub repository; `frontend`, `backend` and `database`.

Lets create the database job first.
- Configure the source code management section to download the master branch from database repository.

	![SCM Database Configuration](https://qacommunity.blob.core.windows.net/images/jenkins-scm-001.PNG)

- Check the `GitHub hook trigger for GITScm polling` option under the `Build Triggers` section.
- Under `Build Environment`, select `Use secret text(s) or file(s)`. Add a `Username and Password (separated)` and a `Secret text` binding. Use the add button to create credentials for these and name the variables as shown below:

	![Credential Bindings](https://qacommunity.blob.core.windows.net/images/jenkins-scm-002.PNG)

	The actual value of the credentials (password contents etc) can be whatever you like.

- Add an `Execute shell` build step with the following configured as the command:

```bash
export MYSQL_USER
export MYSQL_PASSWORD
export MYSQL_ROOT_PASSWORD
export MYSQL_HOST="localhost"
export MYSQL_DATABASE="bookshelve"
./setup.sh
```
- Build the job to make sure that it succeeds

Now that you have a working Job for the database, complete the same steps as above for the, backend and frontend.
Make sure to reuse any credentials that you made previously, don't create new ones.

### See the Application Working
You should now be able to navigate to your machine's address on port `80`to see the application working.

### Web hook Configuration
We have already configured the Jenkins jobs to accept web hooks as triggers so now we just need to setup the web hook on a Git service provider like GitHub etc.
For this example we will be discussing how you can use GitHub to send Web Hooks to your instance of Jenkins, do the following for each of the GitHub projects that you have created:
1. On your GitHub project navigate to the `Settings` tab.
2. Click on `Webhooks`
3. Set the `Payload URL` to be `[JENKINS_ADDRESS]/github-webhook/`; **Don't miss the trailing `/` on the end of the Payload URL!**
4. Set the `Content type` to be `application/json`
5. Select `Add Webhook`

### Push a New Change
We can now have a look at making some changes on the remote repositories to trigger automatic deployments of our new changes.

#### Frontend
Add `<h1>UPDATE</h1>` after line `9` in the `frontend/index.html` file.
Push the new changes to the GitHub repository, then then you should see the frontend Job automatically build.

Now try navigating to the site to see your changes.

#### Database
We can add a new item into the database to see the changes.
In the `database/setup.sql` append the statement shown below, then push the changes to the database repository:
```sql
INSERT INTO Books (
        Name, Author, Image
) VALUES (
        "Harry Potter and the Philosopher's Stone",
        "J.K. Rowling",
        "https://books.google.com/books/content/images/frontcover/39iYWTb6n6cC?fife=w200-h300"
);
```

The changes that you made should then be reflected on the running site.

### Clean Up
To finish up here the virtual machine being used can be deleted.

## Exercises
There are no exercises for this module.
