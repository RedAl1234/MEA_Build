# Plugins

## Overview

Jenkins has **hundreds of plugins** that can be used to increase the functionality of the automation server. Alongside this, developers can write their own plugins, which means the use of Jenkins is almost limitless in software projects!

A large part of Jenkins' core functionality is reliant on plugins, with some of the most popular plugins being installed on set-up should you choose to *"install suggested plugins"*.

## Why Plugins?

Some of the reasons why we might want to use plugins include:

- **Source Code Management (SCM) implementations**: integrating SCMs like Git or Perforce into Jenkins.
- **Build steps**: providing everything from a convenient UI to configure build tools, to sending emails post-build.
- **Authentication realms**: integrating Jenkins with Single Sign-On systems, or external user directories (such as Azure Active Directory).

There are plugins for **collaboration and project management tools** (e.g. Slack, Jira), **DevOps and Automation** (e.g. AWS EC2 machines, Docker containers), **testing and performance** (e.g. JUnit), and even for simple UI & aesthetic changes. 

This is only a snippet of the plugins Jenkins uses - there are so many more for you to explore and use!

## Tutorial

In this tutorial, you will install a plugin and see what affect that has on our Jenkins instance.

**Before starting this tutorial, make sure you have a Jenkins instance up and running.**

1. Go to `Manage Jenkins` and click on `Manage Plugins`:

![jenkins](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/plugins/000.png)

2. Click on the Available Tab and search "maven". Check `Maven Integration` and select `Install without restart`:

![jenkins1](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/plugins/001.png)

3. In `Manage Jenkins` > `Global Tool Configuration`, you will now see an option to configure the path to the Maven file:

![jenkins2](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/plugins/002.png)

4. If you create a `New item`, you can now see the `Maven project` option:

![jenkins3](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/plugins/003.png)

5. Inside this project, there are some options available that make integrating with Maven much easier:

![jenkins4](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/plugins/004.png)

![jenkins5](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/plugins/005.png)

The Maven plugin we installed allows much easier integration with Maven, and makes it simple to configure; this is the power of plugins!

To uninstall a plugin, you simply go back to `Manage Plugins` and go to the `Installed` tab:

![jenkins6](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/plugins/006.png)

## Exercises

Explore the content in this [link](https://plugins.jenkins.io/) - browse the available plugins for Jenkins and create a list of the plugins you would use for a small CRUD-based application written in Java that is hosted on the cloud.