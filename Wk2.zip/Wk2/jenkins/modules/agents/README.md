# Jenkins Agents

<!--TOC_START-->

<!--TOC_END-->
## Overview

In this module, we will look at Jenkins Agents: what they are, what they do, and how you can configure this to your advantage.

Out of the box, you will see that Jenkins has a `master` Build Executor which can run two jobs concurrently and are `Idle`.

![Default Agent Man](https://imgur.com/h0S5uKp.jpg)

### What is an agent

An agent, or Node, is a distinct unit, such as a *Virtual Machine*, that is running the *Jenkins Agent* and capable of receiving *jobs* from Jenkins, whether those be stages of a Pipeline, Freestyle Project, or the entire build process.
Agents, however, are only capable of working on a single job at a time until the job completes with success or failure.

### Why use Agents

Agents are a ubiquitous pattern in computing which help to separate the "Job Issuer" (Jenkins) from the "Job Runner" (Agents).
In doing so, we are granted asymmetry - we can have as many Agents as we want per Jenkins instance. This means that we can dedicate certain agents to certain jobs, for instance, a `build` agent and a `deploy`agent. 

Typically, deployment is a much quicker process than building artefacts, so it would make sense to have multiple build agents - this would mean we could, for example, build separate images for `integration`, `staging` and `production` at the same time, using three different build agents, while leaving the deploy agent ready to deploy the artefacts as soon as they are ready.

## Tutorial

In this tutorial, we are going to set up an agent that we can selectively send jobs to using a label.
By doing so we will have two agents: 
- the default agent that we are going to task as our `Deploy` agent, and
- a new containerised agent that we are going to task as our `Build` agent 

### Prerequisites

For this tutorial, you will need a virtual machine (ubuntu 20.04) with Jenkins installed, an admin user configured, and the default plugins installed (at least `SSH Build Agents` plugin).
You will also need to have `Docker` installed on this VM - follow the directions here: https://docs.docker.com/engine/install/ubuntu/

Jenkins very helpfully provide a Docker Image for their agent: https://hub.docker.com/r/jenkins/ssh-agent

*N.B. It's ALWAYS worth checking for official docker images*

Finally, we are going to build a Hello World Java program in order to illustrate how agents might be useful. You do not need to have a background in Java.

### Step 1: SSH Keys

In order to authenticate between Jenkins and the Agent we will need to provide some keys. We're going to be doing this via `ssh`, so simply generate yourself a key pair with:

```bash
ssh-keygen -f ~/.ssh/jenkins_agent_key
```

There is no need to add a passphrase, and the defaults are perfectly good for our needs.

### Step 2: Give Jenkins the keys

Now we need Jenkins to be aware of the keys we just generated, so go to your Jenkins Dashboard and click the `Manage Jenkins` option in the left-hand menu and then the `Manage Credentials` button

![Manage Jenkins](https://imgur.com/qfFijTB.jpg)

![Manage Credentials](https://imgur.com/mYLUC6b.jpg)

Select the `Add Credentials` option from the dropdown on the `global` item.

![Add Credentials](https://imgur.com/M7J49el.jpg)

Fill in the Form:
```bash
  Kind: SSH Username with private key;
  id: jenkins
  description: The jenkins agent ssh key
  username: jenkins
  Private Key: select Enter directly and press the Add button to insert your private key from ~/.ssh/jenkins_agent_key
  Passphrase: <empty>
```

![Add Credentials Form](https://imgur.com/TXJOxDT.jpg)

To get your private key simply copy the output from:

```bash
  cat ~/.ssh/jenkins_agent_key
```

### Step 4: Create Your Docker Agent

#### Starting your agent

You will need your corresponding ssh public key to the credentials you just provided to Jenkins.
To get your public key simply copy the output from:

```bash
  cat ~/.ssh/jenkins_agent_key.pub
```

```bash
  docker run -d -p 2222:22 jenkins/ssh-agent:latest "<YOUR PUBLIC KEY>"
```

This will download the docker image provided by the Jenkins devs, push your ssh key into it, and forward the ports from 22 on the container to 2222 on your host machine. This last step is very important as ports must be unique and so we cant have a container listening on port 22 when the host is also listening on that port.
The container will also start in a detatched state (`-d`).
To confirm that the container is in fact running you can list the docker processes with `docker ps`.

#### Connecting to your agent

At this point it is worth testing that everything is working as expected, which we can do via ssh:

```bash
  ssh jenkins@localhost -p 2222 -i .ssh/jenkins_agent_key
```

This should connect you to the container, or throw an error such as `permission denied`. This is most likely due to the permissions on the key you are passing: keys being rather important to security, it is forbidden to use a key that anyone else might be able to edit. This is a common issue, especially after using `ssh-keygen`, but it has a simple solution:

```bash
  chmod 0600 .ssh/jenkins_agent_key    
```

This will make sure that only your user has access to the key.
Once we have validated that ssh can connect, we can simply `exit` out of the container.

#### Updating your agent

There is an issue still open for the container that requires a manual fix (Jenkins devs are working on it though so this will be patched at some point in the future):

Connect to your instance and become root via docker exec:

```bash
  docker exec -it <NAME||ID> /bin/bash
```

This will interactively (`-i`) execute (`exec`) the `/bin/bash` command (the bash shell) within the container provided (your agent container), as either the name or id (which can be just the first few characters) as shown by a `docker ps`.
Once that executes you will be bumped to the bash process within the jenkins agent container, where you should paste the following and press enter:

```bash
  VARS1="HOME=|USER=|MAIL=|LC_ALL=|LS_COLORS=|LANG="
  VARS2="HOSTNAME=|PWD=|TERM=|SHLVL=|LANGUAGE=|_="
  VARS="${VARS1}|${VARS2}"
  env | egrep -v "^(${VARS})" >> /etc/environment
```

Once that completes you can `exit` out of the container back to your host.

### Step 5: Register The Agent With Jenkins

Now that we have a running agent on our host, we need to register this with Jenkins so that it can push jobs to it.

![Manage Jenkins](https://imgur.com/qfFijTB.jpg)

Once again, go to the Jenkins Dashboard and select the `Manage Jenkins` option in the left-hand menu before going to the `Manage Nodes and Clouds` section.

![Manage Nodes](https://imgur.com/ZQmcnvN.jpg)

Go to the `New Node` option in the left-hand menu and fill in the Node/Agent Name `agent1` and select the type `Permanent Agent`.
![Add Nodes](https://imgur.com/b6jP84E.jpg)

Fill in the Form:
```bash
  Remote root directory:    /home/jenkins 
  Label:                    agent1
  Usage:                    only build jobs with label expression
  Launch method:            Launch agents by SSH
  Host:                     localhost
  Credentials:              jenkins (e.g. the credentials we registered in Step 2)
  Verification Strategy:    Manually trusted key verification
```

![Agent Config](https://imgur.com/aUqY7oA.jpg)

We will also need to specify the port in the Advanced settings, so click to expand that and set the `Port: 2222` as this is where we forwarded our containers ssh listener.

![Advanced Config](https://imgur.com/m3pCcQ3.jpg)

![Advanced Port](https://imgur.com/Ld32yDf.jpg)

Save the Agent details to register it with Jenkins; however, this will be "offline" as we need to connect to it:

![Agent Registered](https://imgur.com/miYX4Rz.jpg)

Click on the `agent1`, select `Launch agent` and wait a moment for Jenkins to connect to the container and make the agent available. You should receive a confirmation message: `Agent successfully connected and online`

![Launch Agent](https://imgur.com/Mq6Xsrf.jpg)

![Agent Online](https://imgur.com/wd2LgVD.jpg)

Now we can push jobs to our agent!.

### Step 6: Set up a Pipeline Project

We are going to build a Pipeline project. The project will be very simple, using only two stages: 

- `Build`   : during this stage we are going compile and build an artefact
- `Deploy`  : during this stage we will take the artefact and deploy/run it

The example we are going to use is a Hello World Java class:

```java
public class HelloWorld {
  public static void main(String[] args) {
    System.out.println("Hello world!");
  }
}
```

Set up your own GitHub repo along the lines of https://github.com/qasbirchall/java-hello-world
HINT: GitHub has a fork button.

Set up a new Pipeline Project called `java-app` with your repository as the `GitHub project`

![Pipeline Project](https://imgur.com/8oW0TES.jpg)

![GitHub Project](https://imgur.com/eDgAOEz.jpg)

Now we want to configure a pipeline with: 
- a `Build` stage: this will compile our Java class, build a Jar artefact and archive it for permanent use.
- a `Deploy` stage: that will execute the successfully built artefact. In reality this stage would most likely push the Jar out to the various Tomcat servers running in our environments, but for the purposes of this tutorial we will keep things simple.

The Pipeline can be very neatly configured using:

```bash
pipeline { 
    agent any
    options {
        skipStagesAfterUnstable()
    }
    stages {
        stage('Build') { 
            agent { label 'agent1' }
            steps { 
                echo '--------------- BUILD ---------------'
                checkout([$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: [[url: 'https://github.com/qasbirchall/java-hello-world']]])
                sh 'javac HelloWorld.java'
                sh 'jar cvfe HelloWorld.jar HelloWorld *.class' 
                archiveArtifacts artifacts: 'HelloWorld.jar', followSymlinks: false, onlyIfSuccessful: true
                echo '--------------- BUILD ---------------'
            }
        }
        stage('Deploy') {
            agent { label '!agent1' }
            steps {
                echo '--------------- DEPLOY ---------------'
                sh 'java -jar $JENKINS_HOME/jobs/$JOB_NAME/builds/$BUILD_NUMBER/archive/HelloWorld.jar'
                echo '--------------- DEPLOY ---------------'
            }
        }
    }
}
```

![Pipeline Config](https://imgur.com/Rjho5oI.jpg)

Let's take a closer look at what's going on:

```bash
pipeline { 
    agent any
```
This specifies a Pipeline config with a default agent of `any`, meaning any agent can pick up this pipeline (we override this at the stage level).

```bash
options {
    skipStagesAfterUnstable()
}
```
This specifies that we would like to fail fast - there is no point deploying something that failed to build or, more likely, failed the tests.

```bash
stages {
  stage('Build') { 
    agent { label 'agent1' }
    ...
  }
  stage('Deploy') { 
    agent { label '!agent1' }
    ...
  }
}
```
Declare our stages and what agent can run them - overriding the earlier setting for `any`.

```bash
checkout([$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: [[url: 'https://github.com/qasbirchall/java-hello-world']]])
```

This tells Jenkins to checkout our repository from the `main` branch: you should provide your own repository as set up earlier.

```bash
sh 'javac HelloWorld.java'
sh 'jar cvfe HelloWorld.jar HelloWorld *.class' 
```

This runs the two shell commands we need to compile and build our code into a jar file.

```bash
archiveArtifacts artifacts: 'HelloWorld.jar', followSymlinks: false, onlyIfSuccessful: true
```

Once we have our jar file successfully built (`onlyIfSuccessful: true`) we archive it for later use.

```bash
sh 'java -jar $JENKINS_HOME/jobs/$JOB_NAME/builds/$BUILD_NUMBER/archive/HelloWorld.jar'
```

Finally, we want to take the archive and execute it as our `Deploy` stage.
Notice how Jenkins archives per Job per Build - safely keeping each version of our application/artefact in its own directory.
This can be very useful for revision control, roll-backs and auditing, but can lead to some heavy disk usage if the artefacts are generally large and/or undergo a high volume of changes.

### Step 8: CI/CD

We should now be able to trigger our project (manually at this point).
First notice how this Stage (`Build`) is first picked up by the default master agent before being delegated to our specified agent: `agent1`.

![Agent1](https://imgur.com/j9pajFI.jpg)

Upon success, the Pipeline will move to the `Deploy` stage and run the Jar artefact we generated in the `Build` stage. 
Notice how this Stage (`Deploy`) is carried out by our original/default agent.

![Not Agent1](https://imgur.com/l09RlpB.jpg)

Check the console log for the project to see that we have the expected output, it should show something like:

![Expected Output](https://imgur.com/hG9771F.jpg)

## Conclusion

As we have seen, it is relatively simple to register build agents with Jenkins and selectively push jobs to them based on labels. This begs the question of why would you want to do this? As mentioned already, concurrency is enough of a bonus to make this pattern pretty much ubiquitous in computing. 

This tutorial should point the way to other advantages specific to DevOps and CI/CD, such as the ability to provide distinct build agents for each version of Java, for instance, or maybe we would like to have distinct Deploy agents for each of our environments to limit exposure should something go wrong.


## Exercises

### Automation

Automate the process so that we build and deploy a new artefact in response to changes to the repository.

HINT: you will probably need to set up a GitHub web hook.