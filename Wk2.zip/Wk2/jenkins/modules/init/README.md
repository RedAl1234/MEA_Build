# Jenkins init scripts

## Overview

Jenkins init scripts are less known but extremely effective way to configure Jenkins in an Infrastructure As Code (IAC) manner. 

Jenkins init scripts are Groovy scripts that are hook points. You can use it to inject custom logic into Jenkins runtime. Jenkins is written in Java, so init scripts have access to real Jenkins internals.

For example, the following script accesses the real Jenkins Java object kept in JVM process memory: 

```groovy
#!groovy

import jenkins.model.*

def instance = Jenkins.getInstance()
println("This is Jenkins instance object in JVM: " + instance)
```

Quite powerful, isn't it? Be careful then, because you can break your Jenkins easily!

### Init scripts location

The common place to put your init files is `$JENKINS_HOME/init.groovy.d/` directory. Any Groovy file you put in this directory will be interpreted as an init script.

### Init script lifecycle

Init scripts are executed when the Jenkins server is started. Keep in mind that scripts are executed every time you restart your Jenkins, so make sure any script you create is always **idempotent**. We call a script idempotent when it can be executed safely multiple times without inflicting additional side effects. For example, an idempotent script adds the same user to Jenkins only once, not on every Jenkins server restart.

## Tutorial

In this tutorial we will create an init script adding default admin user to Jenkins.

### Create script

The script below demonstrates how to ensure that your Jenkins has admin user created.

```groovy
#!groovy

import jenkins.model.*
import hudson.security.*

def instance = Jenkins.getInstance()

def hudsonRealm = jenkins.getSecurityRealm()
if (hudsonRealm == null) {
    hudsonRealm == new HudsonPrivateSecurityRealm(false)
}
        
def user = hudsonRealm.getUser('admin')
if (user == null) {
    hudsonRealm.createAccount('admin', 'mysecretpassword')
}

instance.setSecurityRealm(hudsonRealm)
instance.save()
```

Save the script above into the following location - `$JENKINS_HOME/init.groovy.d/admin.groovy`.

### Running script

Use the example script above to configure new Jenkins server with default admin account.
In order to run our init script, just start your Jenkins server. Jenkins runtime will detect the script the `init.groovy.d` directory and execute it on your behalf.

## Exercises

Use the example script above to configure a new Jenkins server with a default admin account. As a next step, try to modify your script to add additional users into your Jenkins.
