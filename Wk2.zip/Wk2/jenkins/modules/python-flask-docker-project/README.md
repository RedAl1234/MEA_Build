# Python Flask Docker Project

<!--TOC_START-->
## Contents
- [Overview](#overview)
- [Tutorial](#tutorial)
	- [Prerequisites](#prerequisites)
		- [Virtual Machine](#virtual-machine)
		- [Jenkins User](#jenkins-user)
		- [Pythonadm User](#pythonadm-user)
		- [APT Packages](#apt-packages)
		- [Jenkins](#jenkins)
		- [Database](#database)
	- [Set Up Jenkins](#set-up-jenkins)
	- [Simple Flask Application](#simple-flask-application)
	- [Jenkins Job](#jenkins-job)
		- [Source Control Management](#source-control-management)
		- [Parameters](#parameters)
		- [Build](#build)
	- [Access the Flask Application](#access-the-flask-application)
- [Exercises](#exercises)
	- [Try this on Another Project](#try-this-on-another-project)
	- [Secrets](#secrets)

<!--TOC_END-->
## Overview
This module covers a basic deployment of a Python Flask app with Jenkins, using docker and a Freestyle Project.

## Tutorial

This tutorial assumes that you have knowledge in the following areas:
- Python/Flask
- Linux
- Docker
- Git

### Prerequisites
There are a few prerequisites for this module, so make sure the requirements have been configured on your machine by completing the steps below.

#### Virtual Machine

Spin up a virtual machine in your cloud provider of choice with the following configuration:
- Ubuntu LTS 20.04
- Recommended 2GB of RAM
- Network connections allowed on ports `22`, `5000` and `8080`

Connect to this VM via SSH. The following commands in this tutorial should be run on this VM via this SSH connection.

#### Install Jenkins

Jenkins devs provide great documentation: https://www.jenkins.io/doc/book/installing/

For our particular purposes, simply follow the guide: https://www.jenkins.io/doc/book/installing/linux/#debianubuntu

#### Install Docker

For our purposes, follow the instructions here: https://linuxize.com/post/how-to-install-and-use-docker-on-ubuntu-20-04/

#### Add jenkins to docker group

```bash
sudo usermod -aG docker jenkins
```

This will give the `jenkins` user the privileges needed to build and run docker containers.
You might want to give your own user the same privileges if you want to see what is happening on the command line.

### Set Up Jenkins

On your browser, connect to your Jenkins VM via its public IP address on port `8080`.

You will be prompted to enter the Jenkins Initial Admin Password. This can be retrieved by entering the following command on your VM's command line:

```bash
sudo cat /home/jenkins/.jenkins/secrets/initialAdminPassword
```

Proceed through the standard setup process to create an admin user and install the recommended plugins.

### Simple Flask Application

To facilitate this tutorial a Flask application will be needed.

We are going to use the flask `hello world` example:

```python
from flask import Flask
app = Flask(__name__)

@app.route("/")
    def hello():
        return "Hello World!"

if __name__ == "__main__":
    app.run(host='0.0.0.0')
```

The only thing worth noting here is that we are explicitly telling Flask to listen on all network interfaces using the `host='0.0.0.0'` as this will make the docker networking easier to handle.

Create a git repo and commit the `hello world` example as a file called `app.py`, and add a `requirements.txt` with the following:

```bash
Flask==1.0
```

#### Create a Dockerfile for the python app

Create a file named `Dockerfile` in the root of the python app repository (which you forked) and add the following:

```bash
FROM python:3

WORKDIR /usr/src/app

COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt

COPY . .
EXPOSE 5000

CMD [ "python", "./app.py" ]
```

This specifies a python3 based container with a copy of the codebase ready to be run.
To find out more about Docker see the Docker Module.


### Jenkins Job

Using the Jenkins instance installed on your machine, create a Freestyle Project called `flask-app`.

![freestyle-job](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/000.png)

Click on the `Configure` button on the left-hand side of the Job page.

![configure](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/001.png)

#### Source Control Management

Configure the *Source Control Management* section to be set up with the Git repository you created for the *Simple Flask Application*:
- Select the *Git* option
- Set the *Repository URL* to e.g. `https://github.com/qasbirchall/python-flask-hello-world`

![scm-section](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/002.png)

#### Build

We now need to define the build steps for this job. 

In the *Build* section, click on `Add build step` and select `Execute shell` from the drop-down options.

![build-step](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/004.png)

You will see the following text box:

![execute-shell](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/005.png)

Because we are using Docker, all we need to do to build an image we can use is `docker build -t myapp:latest .`

This will pick up the `Dockerfile` in the root of your repo and use that to create an image, tagged as `myapp:latest` from which jenkins can run, test and deploy.

#### Run 

We now need to define the Run steps for this job.

In the *Build* section, click on `Add build step` and select `Execute shell` from the drop-down options.

This is where we Run the image that we previously Built (e.g. for the purposes of testing).

Here we can specify

```bash
docker stop myapp || true && docker rm myapp || true

docker run -dt --rm -p 5000:5000 --name myapp myapp:latest
```

First we use a hack to stop and remove any previous container called `myapp`. The hack here is to use the conditional OR `||` and `true` so that the exit code of the command doesn't cause a build failure if the container doesn't exist or isn't running.
This final command will take the image tagged as `latest` that was just built and run it via Docker giving the running container a name of `myapp`

Finally, hit the `Save` button at the bottom of the screen.

### Access the Flask Application

Hit the `Build Now` button of your Job's page to run the build script.

![build-now](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/python-flask-freestyle-project/006.png)

The Flask application should now be running on port `5000`, check this in a browser or with the `curl` command.

If you are having trouble accessing the application, there are a number of things you can do to see what is happening:

`docker ps`			- will show running docker processes 
`docker ps -a`		- i.e. "dash all" will show docker processes that have ran recently (and when they quit)

`netstat -tunlp`    - this will provide a list of active internet connections, where they are listening and on which port (you man need: `sudo apt-get install net-tools`)

`ps -au`			- this will show processes by all users and you will specifically expect to see a process by `root` with `python ./app.py`

## Exercises
### Stretch Goals
What we have just put together is a CI/CD server that:
- runs manually
- does no testing
- leaves processes running

What would be ideal is a CI/CD server that:
- runs automatically when the target codebase changes
  *because what's the point in all this if it isn't automated!?*
  
- runs a set of tests against the codebase (unit and/or integration)
  *because we need some assurance that what we are deploying works!*
  
- cleans up running processes
  *because we need to understand that the Jenkins instance is not where we want to deploy these services*
  
#### Hints: Automation
This should be no more difficult than using the correct setting in Jenkins (although you may need to provide a web-hook on your github account).

#### Hints: Testing
This is already a very simple application so don't overthink the tests, all we really need is a verification that the application we just built is doing what it should so that Jenkins can fail if the application breaks.

#### Hints: Cleanliness
This is actually very simple, all you need to do is to stop and remove the container in a final build step (remember we are sort of doing this with our hack...).

### And Finally...
What we should be aiming for is a CI/CD server that automatically builds and tests our services after each change, validating an image that we can subsequently publish and deploy to our envrionments e.g. `integration`, `staging` and `production`
This can be achieved using an artifact repository (in this case `Dockerhub` or `Nexus`) in which to publish the verified images, and setting up another Jenkins Project which will react to image changes in that repository and deploy them to our various environments (e.g. using a simple ssh command)
