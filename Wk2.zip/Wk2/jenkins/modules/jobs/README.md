# Jenkins Jobs

## Overview
A Jenkins project is a set of configurations, or **steps**, that are used by a **Job** to build a piece of software. This job is repeatable, and can contain post-build actions that will take place based on the result of the job.

Jenkins Jobs are extremely versatile; they can contain steps to poll a VCS, run automted tests, deploy to the cloud and much more. It all depends on what you configure the project and its jobs to do.

A common example of a Jenkins job would be to automatically build a project and deploy it on a server that can be accessed over the internet.

## Create a Job
You can create a new job by clicking the `New Item` link on the Jenkins dashboard.

This will present you with options for what type of job to create.
In this example, we have named the job `first-job`, selected `Freestyle Project` and then selected `OK`. 

Try creating a job with the same properties!

![First Job](https://qacommunity.blob.core.windows.net/images/jenkins-jobs-000.PNG)

## Workspaces
A workspace in Jenkins is a folder that is on the host machine.

Jenkins will run every single job in its own workspace. This is to keep jobs seperated from one another, which avoids conflicts with files and configurations that the jobs may be using.

## Help!
There are many configurations to choose from when setting up a Jenkins job. If you need a reminder of what each of these configurations are, use the `?` symbol on the right side of the page; this will provide comprehensive explanation of what the option does.

## Job Configuration
This is where you can set up what your job is going to do. This includes face-value configurations, such as the name and description of your project and its jobs, alongside more complex configurations concerning job dependencies, post-build actions and scripting.

There are many options, but this module will just focus on the *General* Settings.

### General Settings
The settings and options throughout all job configurations will depend on what plugins are installed. Below is an explanation of some of the core settings that are suggested when you go through the Jenkins setup.

|Setting Name|Description|
|------------|-----------|
|Description| This is a simple text field to fill in information about the job. Use this space to enter some instructions about your job here, or information about its current state; for example, if it's a work in progress.|
|Discard Old Builds| If your job uses up quite a bit of disk space, this option can be selected so the old builds that no longer serve any purpose can be deleted.|
|GitHub Project| Jenkins jobs are commonly associated with some kind of source code repository, like GitHub. You can add a link to that repository here so it becomes easier to navigate to from the job's page.|
|Parameters| To make your job more generic and able to accept different configurations, you can pass it parameters.|
|Disable Project| Prevention is better than cure! If there are issues with the job's current configuration and you would like to make sure that it doesn't get executed, then you can check this option.|
|Concurrent Builds| This option can be selected if you wish to run multiple instances of a job at the same time. *Use this option carefully* - there are many cases where your job will not be able to run at the same time as another instance of it, which is why this is disabled by default.|

## Build History & Console Output
The build history is a list of all the individual builds that have ran.

These are especially useful for checking the *Console Output*. To acces this you can either:
- Click the blue or red 'bulb' on the job to go straight to the Console Output
- Click the number and then once you have been sent to the build page, select the *Console Output* link

## Tutorial
Using the example above, create your first job and enter some simple configurations:
- Choose any project from [GitHub](https://github.com)
- Enter some information about the project into the `Project url` field, for the `GitHub project` option
- Set a `String Parameter` for the job:
    - Set the `NAME` field to be `VERSION`
    - Set the `Default Value` field to be `0.1.0`
    - Set the `Description` field to be `Version of the application to build` 
- Select the `Save` button (you will be redirected to the job's page)
- Select `Build with Parameters`. You should then see the parameter that you configured
- Select `Delete Project` and confirm the deletion

## Exercises
There are no exercises for this module.
