# Pipeline

<!--TOC_START-->
## Contents
- [Overview](#overview)
- [Tutorial](#tutorial)
- [Exercises](#exercises)

<!--TOC_END-->
## Overview

The [SSH Pipeline Steps Plugin](https://github.com/jenkinsci/ssh-steps-plugin) provides a handful of methods for using SSH in Pipeline Projects.

## SSH Pipeline Steps

Every method requires a common config object, called `remote`, with the following required fields:

|Field|Type|Description|
|---|---|---|
|name|string, Mandatory|An identifier for the remote machine - usually the same as host.|
|host|string, Mandatory|The hostname (or IP) for the target machine.|
|user|string, Mandatory|The user name to use for ssh.|
|password|string, one of password, identity or identityFile is required|The password to use for ssh. It would be advisable to keep this securely hidden in a vault or credentials store.|
|identity|string, one of password, identity or identityFile is required|The password to use for ssh. It would be advisable to keep this securely hidden in a vault or credentials store.|
|identityFile|string, one of password, identity or identityFile is required|The password to use for ssh. It would be advisable to keep this securely hidden in a vault or credentials store.|
|allowAnyHosts|Boolean|If this is TRUE, `knownHosts` is optional. Defaults to FALSE.|
|knownHosts|string|The location of the known hosts file for key checking.|

For example:

``` 
node {
  def remote = [:]
  remote.name = 'test'
  remote.host = 'test.domain.com'
  remote.user = 'root'
  remote.password = 'password'
  remote.allowAnyHosts = true
}
```

There are many other optional configuration settings available (see [official documentation](https://github.com/jenkinsci/ssh-steps-plugin) for a thorough list), a couple in particular may prove useful:

|Field|Type|Description|
|---|---|---|
|port|int|The port on which the remote machine is listening for ssh connections (often obscured for security reasons.|
|agentForwarding|Boolean|Allow SSH Agent Forwarding (defaults to FALSE).|
|timeoutSec|int|Connection timeout and socket read timeout. Defaults to 0 (OS default).|
|retryCount|int|Retry count to establish connection. Defaults to 0 (no retry).|
|retryWaitSec|int|Interval time between each retries. Defaults to 0 (immediately).|
|keepAliveSec|int|Interval time of keep alive messages sent to the remote host. Defaults to 60 seconds.|

#### sshCommand - Execute command on remote node.
This is equivalent to the ssh `-f` option e.g.:
`ssh user@host -f <command>`

An example that uses `apt-get` to update and upgrade the remote machine:

``` 
node {
  def remote = [:]
  remote.name = 'test'
  remote.host = 'test.domain.com'
  remote.user = 'root'
  remote.password = 'password'
  remote.allowAnyHosts = true
  stage('Remote SSH') {
    sshCommand remote: remote, command: "apt-get update"
    sshCommand remote: remote, command: "apt-get upgrade -y"
  }
}
```

#### sshGet - Get a file/directory from remote node.
This is equivalent to the `scp` e.g.:
`scp user@host:filename .`

An example that uses `sshGet` to retrieve a test report from a remote machine:

``` 
node {
  def remote = [:]
  remote.name = 'test'
  remote.host = 'test.domain.com'
  remote.user = 'root'
  remote.password = 'password'
  remote.allowAnyHosts = true
  stage('Remote SSH') {
    sshGet remote: remote, from: 'test_report.xml', into: 'test_report.xml', override: true
  }
}
```

|Key|Type|Description|
|---|----|-----------|
|remote|Remote, Mandatory, Refer to the Remote config for more details.|Host config to run the command on.|
|from|String, Mandatory|file or directory path from the remote node.|
|into|String, Mandatory|file or directory path on current workspace.|
|filterBy|String, Optional, Defaults to name.|Get files by a file filter. Possible values are params on the java File object.|
|filterRegex|String, Optional.|Get files by a file regex (Groovy syntax). Example: /\.xml$/ - Gets all xml files.|
|failOnError|boolean, default: true.|If this is false, no job failure would occur though there is an error while running the command.|
|dryRun|boolean, default: false|If this is true, no actual connection or operation is performed.|

#### sshPut - Put a file/directory on remote node.
This is equivalent to the `scp` e.g.:
`scp filename user@host:filename`

An example that writes a file (locally) before using `sshPut` to upload it to the target machine - in the root users home dir.
```
node {
  def remote = [:]
  remote.name = 'test'
  remote.host = 'test.domain.com'
  remote.user = 'root'
  remote.password = 'password'
  remote.allowAnyHosts = true
  stage('Remote SSH') {
    writeFile file: 'abc.sh', text: 'ls -lrt'
    sshPut remote: remote, from: 'abc.sh', into: '.'
  }
}
```

|Key|Type|Description|
|---|----|-----------|
|remote|Remote, Mandatory, Refer to the Remote config for more details.|Host config to run the command on.|
|from|String, Mandatory|file or directory path from the workspace.|
|into|String, Mandatory|file or directory path on the remote node.|
|filterBy|String, Optional, Defaults to name.|Put files by a file filter. Possible values are params on the java File object.|
|filterRegex|String, Optional.|Put files by a file regex (Groovy syntax). Example: /\.xml$/ - Puts all xml files.|
|failOnError|boolean, default: true.|If this is false, no job failure would occur though there is an error while running the command.|
|dryRun|boolean, default: false|If this is true, no actual connection or operation is performed.|

#### sshRemove - Remove a file/directory from remote node.
This is equivalent to the ssh `-f` option e.g.:
`ssh user@host -f rm <filename>`

An example that uses `sshRemove` to delete a test report from a remote machine:

```
node {
  def remote = [:]
  remote.name = 'test'
  remote.host = 'test.domain.com'
  remote.user = 'root'
  remote.password = 'password'
  remote.allowAnyHosts = true
  stage('Remote SSH') {
    sshRemove remote: remote, path: "test_report.xml"
  }
}
```

|Key|Type|Description|
|---|----|-----------|
|remote|Remote, Mandatory, Refer to the Remote config for more details.|Host config to run the command on.|
|path|String, Mandatory|file or directory path on the remote node|
|failOnError|boolean, default: true.|If this is false, no job failure would occur though there is an error while running the command.|
|dryRun|boolean, default: false|If this is true, no actual connection or operation is performed.|

#### sshScript - Execute script(file) on remote node.
This is equivalent to the ssh `-f` option e.g.:
`ssh user@host -f <script>`
The script must be executable i.e. `chmod a=x <script>`

An example which writes the script file (locally) before executing it on the target machine:
``` 
node {
  def remote = [:]
  remote.name = 'test'
  remote.host = 'test.domain.com'
  remote.user = 'root'
  remote.password = 'password'
  remote.allowAnyHosts = true
  stage('Remote SSH') {
    writeFile file: 'abc.sh', text: 'ls -lrt'
    sshScript remote: remote, script: "abc.sh"
  }
}
```

Please note that this does not currently support passing arguments to the target script, in order to achieve that do something like the above where we call out from our script to another:
``` 
writeFile file: 'arg_wrapper.sh', text: 'sh ./target_script.sh arg1 arg2'
sshScript remote: remote, script: "arg_wrapper.sh"
```

|Key|Type|Description|
|---|----|-----------|
|remote|Remote, Mandatory, Refer to the Remote config for more details.|Host config to run the command on.|
|script|String, Mandatory|Script file name from the workspace, current this doesn’t support script with arguments. For that option you would need to copy over the file to remote node and run it as a command.|
|failOnError|boolean, default: true.|If this is false, no job failure would occur though there is an error while running the command.|
|dryRun|boolean, default: false|If this is true, no actual connection or operation is performed.|

## Tutorial

This tutorial assumes that you have knowledge in the following areas:
- Jenkins
  - The `SSH Pipeline Steps` Plugin installed
- Python/Flask 
- Linux

### Prerequisites
There are a few prerequisites for this module, so make sure the requirements have been configured on your machine by completing the steps below.
Firstly, the expectation here is that you already have a stable Jenkins server. We are going to set up a distinct instance as a test deploy environment and use `SSH Steps` to control it.

#### Virtual Machine
Spin up a virtual machine in your cloud provider of choice with the following configuration:
- Ubuntu LTS 20.04
- Recommended 2GB of RAM
- Network connections allowed on ports `22` and `5000`

Connect to this VM via SSH. The following commands in this tutorial should be run on this VM via this SSH connection.

#### Pythonadm User
This `pythonadm` (Python Admin) user will be the user that *runs* your Flask application.

It's important to have a separate user to run your applications because this particular user will have very limited privileges, so if the application were to be compromised, the attackers would not gain elevated permissions on the machine.

The user can be created with this command:

```bash
sudo useradd -m -s /bin/bash pythonadm
```

#### APT Packages
Various packages from APT will be required:

| Package | Reason |
|---------|--------|
|`openjdk-11-jre`|Java 11 Runtime, Jenkins runs on Java 11 as of release 2.357.|
|`python3`|Flask applications use Python of course, Python 3 is currently the supported version.|
|`python3-venv`|It is good practice to run Python applications with a virtual environment.|
|`git`|Git will be required to download Flask applications from source code repositories. These will likely be hosted on GitHub or GitLab.|

Install these packages using this command:

```bash
sudo apt update
sudo apt install -y openjdk-8-jre python3 python3-venv git
```

### Simple Flask Application

To facilitate this tutorial a Flask application will be needed.

The example being used for this tutorial can be found here: https://github.com/qasbirchall/python-flask-hello-world

We will be running the application as a service and basing the code in `/opt` so, first we need to set up the codebase:

```bash 
cd /opt
sudo git clone https://github.com/qasbirchall/python-flask-hello-world
sudo chown -R ubuntu python-flask-hello-world
cd python-flask-hello-world

# install pip dependencies
python3 -m venv venv
. venv/bin/activate
pip install -r requirements.txt
```

Next we need to create a Service Init script, so using `sudo nano /etc/systemd/system/flask-app.service` copy and paste the following:

```ini 
[Unit]
Description=Flask Application
[Service]
User=pythonadm
WorkingDirectory=/opt/python-flask-hello-world
ExecStart=/bin/bash \
	-c 'cd /opt/python-flask-hello-world && \
	source ./venv/bin/activate && \
	python ./app.py'
[Install]
WantedBy=multi-user.target
```

Save the file and exit: `CTRL+X` will prompt you to save.

When a change is made to a service unit (which the command above just did), these changes must be reloaded:

`sudo systemctl daemon-reload`

Then we should be able to test our service using :

`sudo systemctl start flask-app.service`

and:

```bash
$ sudo systemctl status flask-app.service
● flask-app.service - Flask Application
     Loaded: loaded (/etc/systemd/system/flask-app.service; disabled; vendor preset: enabled)
     Active: active (running) since Fri 2021-01-08 15:32:20 UTC; 8s ago
   Main PID: 30650 (python)
      Tasks: 1 (limit: 1164)
     Memory: 15.7M
     CGroup: /system.slice/flask-app.service
             └─30650 python ./app.py

Jan 08 15:32:20 ip-172-31-36-225 systemd[1]: Started Flask Application.
Jan 08 15:32:20 ip-172-31-36-225 bash[30650]:  * Serving Flask app "app" (lazy loading)
Jan 08 15:32:20 ip-172-31-36-225 bash[30650]:  * Environment: production
Jan 08 15:32:20 ip-172-31-36-225 bash[30650]:    WARNING: Do not use the development server in a production environment.
Jan 08 15:32:20 ip-172-31-36-225 bash[30650]:    Use a production WSGI server instead.
Jan 08 15:32:20 ip-172-31-36-225 bash[30650]:  * Debug mode: off
Jan 08 15:32:20 ip-172-31-36-225 bash[30650]:  * Running on http://0.0.0.0:5000/ (Press CTRL+C to quit)
```

Finally you should be able to hit the service with `curl`:

```bash
$ curl localhost:5000
Hello World! What a nice surprise...!
```

### Jenkins Pipeline

In order to build/deploy the application we must:
1. update the code on our remote
2. make sure that the requirements are installed and the venv active
3. restart the service

To achieve this we can use the pipeline:
```
def remote = [:]
remote.name = 'Test Environment'
remote.host = '35.176.99.95'
remote.user = 'ubuntu'
remote.identityFile = '/home/jenkins/jenkins-flask-docker.pem'
remote.allowAnyHosts = true
remote.sudo = true
node {
    stage('Stop Service') {
        sshCommand remote: remote, command: "systemctl stop flask-app.service", sudo: true
    }
    stage('Update Remote') {
        sshCommand remote: remote, command: "sudo apt-get update", sudo: true
        sshCommand remote: remote, command: "sudo apt-get upgrade -y", sudo: true
        sshCommand remote: remote, command: "cd /opt/python-flask-hello-world; git pull;", sudo: false
    }stage('Install Requirements') {
        sshCommand remote: remote, command: "cd /opt/python-flask-hello-world; source ./venv/bin/activate && pip install -r requirements.txt && deactivate;", sudo: false
    }
    stage('Restart Service') {
        sshCommand remote: remote, command: "systemctl start flask-app.service", sudo: true
    }
}
```

Finally, hit the `Save` button at the bottom of the screen and run the project.

You should see that the steps go through the sequence:
1. Stop the existing service
2. Update the existing environment and codebase
3. Restart the existing service

### Access the Flask Application

The Flask application should now be running on port `5000`, check this in a browser or with the `curl` command.

If you are having trouble accessing the application, then try running `sudo systemctl status flask-app` on the terminal to see errors if the application has failed to start.

## Exercises

It is worth mentioning that the Pipeline we just built has a few flaws:
1. Failure could lead to the service never restarting.
2. A lot of _existing_ infrastructure is expected. The manual overhead on setting up this existing infrastructure is non-trivial.

So, think about how we might solve these issues and try to implement this in your own pipeline.

Hints:
1. A rollback would be ideal, but we could achieve the same with a Pipeline Step that will always run (see `post` section)
2. Make Jenkins do the work using SSH Steps. We could for instance provide the service init script via `writeFile` and `sshScript` as shown above.