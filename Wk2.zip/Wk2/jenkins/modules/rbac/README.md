# RBAC in Jenkins

<!--TOC_START-->
## Contents
- [Overview](#overview)
- [RBAC in CI/CD](#rbac-in-cicd)
- [Jenkins](#jenkins)
- [Tutorial](#tutorial)
	- [Prerequsities](#prerequsities)
	- [Container](#container)
	- [Jenkins](#jenkins-1)
	- [RBAC Plugin](#rbac-plugin)
	- [Adding Roles](#adding-roles)
	- [New User](#new-user)
	- [New Job](#new-job)
	- [Login as the new user](#login-as-the-new-user)
- [Exercises](#exercises)

<!--TOC_END-->
## Overview

In this module, we are going to look at the importance of access management in CI/CD and how to assign roles to users in Jenkins.

## RBAC in CI/CD

RBAC (**R**ole **B**ased **A**ccess **C**ontrol) is the method of controlling access based on the role(s) assigned to users or groups.
This allows us to follow `PULP` (Principle of least privilege) which makes sure that people only have the permissions they need by assigning them a role with the relevant permissions.
 
CI/CD systems often need high privileges to create artefacts and application deployments, all of which are business-critical.
It is important that access to these systems is managed to reduce the risk of any business-critical systems being compromised.
 

## Jenkins
 
Jenkins has a plugin specifically for RBAC.
This plugin allows you to create roles at 3 different scopes.
 
- Global roles - Roles that apply to the whole Jenkins server
- Project roles - Roles that apply to particular projects
- Agent roles - Roles that only apply to particular agents
 
Jenkins allows you to apply any of these kinds of roles to users or groups of users.
You can also easily modify the permissions of any roles.
 

## Tutorial
 
In this tutorial, we are going to implement RBAC on a Jenkins container for 2 users, the admin and a reader. The second user will only be able to read the information on the server and different builds. They won't be able to make any changes.
 

### Prerequsities
 
This tutorial assumes you have a virtual machine with Docker installed on it.
 

### Container
 
First, we need to create the container using this command.
 
```bash
docker run -d -p 8080:8080 --name jenkins jenkins/jenkins
```
 
Now run a logs command to get the `initialAdminPassword`.
 
```bash
docker exec /var/jenkins_home/secrets/initialAdminPassword
```
 

### Jenkins
 
Now go to your machine's public IP address on port `8080`, enter the initial admin password and install suggested plugins.
 
You will then create an admin user, make sure to pick a password you will remember.
 
You should then be at the Jenkins dashboard.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/001.png)](https://gyazo.com/61f25454b84df40d8d1843dbebe11139)
 

### RBAC Plugin
 
Now we are going to install the RBAC plugin so go to the `Manage Jenkins` and `Manage Plugins`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/003.png)](https://gyazo.com/666713e8e6f829fa186f921aad6b908e)
 
Select `Available` and type `Role-based Authorization Strategy`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/005.png)](https://gyazo.com/03d174444025d583a67c5c94fb4f4b1f)
 
Tick the plugin and select `Install without restart`.
Wait for the plugin to install.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/007.png)](https://gyazo.com/1790eb1c65d2051e2e8102354bc1141f)
 
Now go to `Manage Jenkins` and `Configure Global Security`.
Here you will see the Authorisation options.
Tick the `Role-based Strategy`.
This will activate the plugin.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/009.png)](https://gyazo.com/fd002176763fc15a0123de0367d19df3)
 
Click `Save`.
 

### Adding Roles
 
Now we are going to add the reader role.
Go to `Manage Jenkins`, `Manage and Assign Roles` and `Manage Roles`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/011.png)](https://gyazo.com/51c4184fe927432a61edea5845affaf5)
 
You should add the `admin` role.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/013.png)](https://gyazo.com/96c814e31885b545afbb13aa4ed6e73d)
 
Now let’s add a new global role.
Enter the role name `Reader` and click `Add`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/015.png)](https://gyazo.com/8dd553be5fd10ddf7003ac182f917c2b)
 
Now go through all the permissions and select the read permissions, including the `ExtendedRead`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/017.png)](https://gyazo.com/a1b75c917ab3dcf9435dcfa9815e1168)
 
Now click `Save`.
 

### New User
 
Now let’s add a new user and then we will assign the Reader role to this user.
 
Go to `Manage Jenkins` and `Manage Users`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/019.png)](https://gyazo.com/536d724aa2595dd6bd9e52d9cd4010d7)
 
Select `Create User`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/021.png)](https://gyazo.com/e1024a4736d9173bece02087ba3325c5)
 
Give the new user a username and password you will remember.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/023.png)](https://gyazo.com/d57c400d71592f05e6901ab8f4a853a5)
 
Now, go to `Manage Jenkins`, `Manage and assign Roles` and `Assign Roles`.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/025.png)](https://gyazo.com/8833b6adc2b4b146494d2f261e2caccf)
 
Here you can the current assignment of roles.
 
[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/027.png)](https://gyazo.com/f34851090194b8d232a4be26cef0bd76)

Enter the new user’s username and select `Add` under `Global Roles`.

[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/029.png)](https://gyazo.com/c166cbaa2d4885c82fa59ecf0c68a604)

Now tick `Reader` role for your new user.

[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/031.png)](https://gyazo.com/f5ab7d3ce74e710ad33b0db27652a223)

Click `Save`.

### New Job

Now we are going to make a new job to show how the Reader role works.

Go to `New Item`, give the job a name and select `Freestyle Project`.

[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/033.png)](https://gyazo.com/b4400affb9d35c9ffea2a4fcf4225979)

Now in the configuration, go to `Add build step` and select `Execute Shell`.

In here type `echo "Hello World"`.

[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/035.png)](https://gyazo.com/691eeaf925fef2a7e82bd92e4604fe35)

Click `Save` and `Build Now`.

[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/037.png)](https://gyazo.com/cd554e22633ce1b17b4b23ab11d49f29)

### Login as the new user

Now log out of the admin user and sign back in as your second user.

[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/039.png)](https://gyazo.com/4a63966b2c1c51f703e4a3da353cbdeb)

You should notice some differences in the dashboard.

[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/041.png)](https://gyazo.com/a66b3056fc53e43f0bdbf6fb548c2d33)

You don't have the `Manage Jenkins` option as you only have read permissions.

Now go to the job we just created.

[![Image from Gyazo](https://qa-courseware-images.s3.eu-west-2.amazonaws.com/jenkins/rbac/043.png)](https://gyazo.com/9411d0bc844d43726af79e10b0485a88)

Here you can see the current configurations and the `Console Output` of any build but you can't make any changes.

## Exercises

1. Change the reader role to only read `overall`.
2. Create another job with a different name, make sure to run a build.
3. Create 2 project roles one for each of the jobs, one should give all permissions and one should give only read permissions. Hint: the `pattern` is the name of the job.
4. Login to your new user and see the different options you have with the 2 jobs.
