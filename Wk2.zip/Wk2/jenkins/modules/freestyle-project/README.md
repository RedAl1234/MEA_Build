# Freestyle Project

## Overview

Freestyle projects in Jenkins are a type of job you can create for almost any automated task. They are the default project type and the best place to start for building any sort of general purpose automation in Jenkins.

## Project Types in Jenkins

When creating a new project in Jenkins, you may notice that there are a number of different project **types** to select. Below is a brief description on each type of job you can run with each:

| Project Type          | Description |
| --------------------- | ---------------------------------------------------------------------------------------------------- |
| Freestyle Project     | The default job type and also the most flexible. **This is the job type this module will focus on!** |
| Pipeline              | A job you can use to define your build/pipeline process as code using a *Jenkinsfile*.               |
| Multi-config          | A job used for project that have many different configurations throughout the whole build.           |
| Folder                | A job used to create a space for nested jobs and items. Very good for organising!                    |
| GitHub Organisation   | Jenkins will scan all repos in a given GitHub account or organisation that have specified that they are to be scanned within them. |
| Multi-Branch Pipeline | This is an extension of the pipeline job, and creates pipelines based on branches within a VCS.      |


## Creating a Freestyle Project

Selecting `New Item` from the Jenkins dashboard will present a list of different project types. From here, we can create a new Freestyle Project called `freestyle-project`:

![Freestyle Project](https://qacommunity.blob.core.windows.net/images/jenkins-freestyle-project-000.PNG)

## Configuration

Once you have created a new job, you will then be redirected to a configuration page for that job.

### Source Code Management

This section is used for configuring a source code repository to download.
The job will download the repository you provide into the job's workspace.

### Build Triggers

The most simple way to run a Jenkins job is by pressing the ``build`` button for the job.
However, jobs can be triggered in many ways - we will usually try to avoid doing this manually.

| Option             | Description                                                                                                                                                                                                                                                                  |
| ------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Build Periodically | You can create a schedule here for the job; for example, having it build every hour or at 6:15 PM every Thursday.                                                                                                                                                            |
| GitHub Hook        | This is where GitHub can send a HTTP POST request; for example, a web hook to your Jenkins server to trigger a build of the job. This must be configured in GitHub and your Jenkins instance must be accessible from the internet for this to work.                          |
| Poll SCM           | This feature can be used if your Jenkins instance is not accessible on the internet. Jenkins will check, using a schedule that you define, whether a change has been made on the configured SCM repository. As soon as a change has been detected, the job will be executed. |

### Build Environment

The build environment allows us to configure various options for a job's environment.

| Option                               | Description                                                                                                                                                                                                                                                   |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Delete Workspace Before Build Starts | The folder where the job runs on the host machine's file system will be deleted before building again. You will likely want this option checked!                                                                                                               |
| Secret Texts & Files                 | You may securely use secret texts and files that you have configured in the Credentials section here in the job. These secrets will also be hidden in the Jenkins logs as well.                                                                               |
| Build                                | This is likely where you will spend most of your time on a Jenkins job. The most common build step here is `Execute shell`; other options are available, depending on what plugins you have installed. Exactly what your job accomplishes is configured here. |

### Build

The part of the job that is *'executed'*.
Functional steps of the job are configured here.

| Option | Description                                                                                                                                                                                                                                                                           |
| ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Build  | Select your build step. This is likely where you will spend most of your time on a Jenkins job. The most common build step here is `Execute shell`; other options are available, depending on what plugins you have installed. Exactly what your job accomplishes is configured here. |

### Post-build Actions

Events to trigger once a build has been completed.

| Option                 | Description                                                                                                                                                                                                                                                                                                                                       |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Add Post-build Actions | Select your post-build action. You may want to configure your job to react depending on how the build went. For instance, you could be notified by email if the job failed. You could also publish a report if the job completed successfully. Like with most of the options, the sky is the limit; it all depends on what plugins are installed. |

## Tutorial

These tasks will take you through configuring a Freestyle Project, which will download a script and run it.

### Prerequisites

- GitHub Account
- Jenkins Installed

### Create a New GitHub Repository

GitHub is, of course, where our code will be! Therefore, we will need to allow Jenkins to download the code frmo that repository and access it in the Job.

Set up a repository so we can configure a Jenkins job to access and use it in later steps:

1. Create a _public_ GitHub repository for this exercise, you can call it `jenkins-freestyle-project`.
2. Add a script to the repository called `run.sh`, with the contents:

```bash
echo 'Hello from run.sh!'
```

### Create a Jenkins Job

The Jenkins job is going to be able to:

- download the repository that we created
- run the `run.sh` script

1. Create a new Freestyle Project on Jenkins. You can call this job whatever you like!

2. Configure the Job to download the repository:
   - Under _Source Code Management_, select _Git_
   - Enter `https://github.com/[YOUR_USERNAME]/jenkins-freestyle-project`, replacing `[YOUR_USERNAME]` with your GitHub username.
   - If your Git Repository has a main branch, then you will need to change the branch specifier from `*/master` to `*/main`.
3. In the _Build_ section, create a build step to _Execute shell_ and enter the following:
   ```bash
   sh run.sh
   ```

### Run the Job

Now that everything is set up, _Save_ the changes that were made and the _Build_ the job.

Check the console output of the build to see that the job has executed. The end of the output will show that the script on the repository has run correctly:

```text
+ sh run.sh
+ Hello from run.sh!
+ Finished: SUCCESS
```

### Clean Up

Feel free to now delete the created resources:

- Jenkins job
- GitHub Repository

## Exercises

There are no exercises for this module.
