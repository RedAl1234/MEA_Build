# Credentials

## Overview

Keeping our private data private is a challenge faced by most, if not all, companies in IT.
In CI/CD there are many different pieces of private information that may be required as part of your pipeline, but that cannot be stored as plain text.
This is where the `Credentials` plugin is very useful.

## Creating Credentials

To ensure that our data is not stored as plain text we can create credentials for Jenkins to use.
These credentials will have private data stored inside them and **will not display that data** in plain text.

Credentials can only be created by an Admin user, or by a user who has been given specific permission to create credentials.

Credentials are created in the following way:

From the `Jenkins Dashboard`, we head to `Manage Jenkins`.
Then, click on `Manage Credentials` under the `Security` heading.

![Manage Credentials](https://qacommunity.blob.core.windows.net/images/jenkins-secma-1.png)

### Scope

We can choose the `scope` of our credentials.

The main scope we shall be using is `Global`.
These credentials are stored on the Jenkins instance and are accessible globally within Jenkins; this means that they can be used by any current or future pipelines we create.

There is another option for the scope, which we can choose when we create a credential, this is called `System` and if we choose this then the credential will only be available to the Jenkins system processes, and not available within any pipelines.

### Types

There are many different types of credentials available to us.
Depending on the format of our data, or what we need to use it for, we can choose a credential type to suit.

Some of the common credential types are listed below:

#### Username with Password

This allows you to store both the `username` and `password` in the same credential.
This is great for organising your credentials, it can reduce clutter if you have many usernames and passwords stored on Jenkins.

#### GitHub App

A `GitHub App` is a tool that adds extra functionality to your GitHub web application.
For example, you can install an app to your GitHub account/organisation that can check the information you have provided as part of a `pull request`, and if there isn't much, it will prompt you for more.

This type of credential is used for communicating directly with Apps you have installed on GitHub.

You are required to enter the `App ID` which points at the specific app you want to communicate with, this information is provided by GitHub.
You are also required to enter the `Key` which is how you authenticate with the App.

#### SSH Username with private key

This is for allowing Jenkins to connect to other machines via the SSH protocol.

SSH requires the `username` of the user to which we want Jenkins to connect and a `private key` for authentication.

The private key, as the name suggests, should be kept securely.
The username can either be stored as plain text or not, this is up to us.

#### Secret file

We can upload a file and store it as a credential.

The type of files we may want to upload are configuration files.
These often contain sensitive information, such as how to authenticate with a cloud provider.
This kind of information should not be stored in plain text!

#### Secret Text

Secret Text is the most versatile type of credential.
All you need to provide is a `string` which you would like to store as a credential, this string can be a *username*, *password*, *access token*, etc.

#### Certificate

The certificate credential is used to store a [PKCS #12](https://en.wikipedia.org/wiki/PKCS_12) file.
This allows us to store many encrypted objects within a file, a password can also be stored for accessing the contents of a file.

### Other required information

There are two fields that are available for every credential we create, these are `ID` and `Description`.

- ID: The ID is the unique key that Jenkins uses to identify each credential.
The ID should be upper/lowercase characters and hyphens can be used to separate words.
E.g. `github-authentication-token`
- Description: The description is an optional field that we can use to provide some extra detail about what is stored within the credential.

This is what a completed credential may look like:

![Completed Jenkins Credential](https://qacommunity.blob.core.windows.net/images/jenkins-secma-2.png)

## Using Credentials

The handling of credentials is handled by yet another plugin.
The specific process of handling credentials is slightly different depending on whether you are working with a `Freestyle project` or `Pipeline`, but the general process is the same.

First, we need to create a `variable` for the `Build Environment`, then we assign a value to that variable using Jenkins credentials.

<details><summary>Freestyle Project</summary>

After you have created your freestyle project, head down to the `Build Environment` section.

In this section, you will see an option for `Use secret text(s) or file(s)`.
Here, we set the variables we are going to use.

![Build Environment Variable](https://qacommunity.blob.core.windows.net/images/jenkins-secma-3.png)

Then we can use these environment variables in our execute shell.

![Jenkins Build Output with Credentials](https://qacommunity.blob.core.windows.net/images/jenkins-secma-4.png)

> Note: The value of the credential is still not shown in the console output.

</details>

<details><summary>Pipeline</summary>

After you have created the Pipeline project, in the Jenkinsfile you need to define variables for the pipeline environment.

We do this by adding a section to the Jenkinsfile, called `environment`, which contains all these variables and the `ID` of the credentials they are getting their values from.

![Pipeline Example](https://qacommunity.blob.core.windows.net/images/jenkins-secma-5.png)

The environment variable created has then been used in the subsequent stage.

![Pipeline Output with Credentials](https://qacommunity.blob.core.windows.net/images/jenkins-secma-6.png)

</details>

## Limitations

Jenkins Credentials are encrypted and stored on the Jenkins instance, and credentials are never outputted as plain text.

Although credentials are encrypted, credential values stored on Jenkins can still be compromised if someone gains access to the instance that is running Jenkins.

In reality, there are many credential stores, that are not associated with Jenkins, which store credentials far more securely than Jenkins does.
Most of these third-party credential providers have plugins to allow them to work almost seamlessly with Jenkins.

## Tutorial
 
In this tutorial, we will be creating a freestyle project and making use of Jenkins credentials within that project.

### Prerequisites

To complete this tutorial, you must make sure you have access to a Jenkins server **AND** you must be an admin user.

### Create the Credential

From your `Jenkins Dashboard` navigate to `Manage Jenkins`.

![Manage Jenkins](https://qacommunity.blob.core.windows.net/images/jenkins-secma-7.png)

Select `Manage Credentials`.

![Manage Credentials](https://qacommunity.blob.core.windows.net/images/jenkins-secma-1.png)

We are going to set a `Global credential`, so select the `global` button.

![Global Credential](https://qacommunity.blob.core.windows.net/images/jenkins-secma-8.png)

Now we can add our credentials. Select the `Add Credentials` from the left-hand side.

We are going to add the following credential:
- Type: Secret Text
- Scope: Global
- Secret: TestString
- ID: TEST
- Description: A Test String

![Credential](https://qacommunity.blob.core.windows.net/images/jenkins-secma-9.png)

You should now be able to see your credential stored on Jenkins.

### Use the Credential

Head back to the Jenkins Dashboard and this time, click `New Item` from the left-hand menu.
We will be creating a `freestyle project` with the name `credentials`.

![Freestyle Project](https://qacommunity.blob.core.windows.net/images/jenkins-secma-10.png)

You can set up this project however you want but, importantly, we must configure the `Build Environment` to have a variable.

Select `Use secret text(s) or file(s)` then click `add` and finally `Secret text`.

![Environment Variable](https://qacommunity.blob.core.windows.net/images/jenkins-secma-11.png)

Then create an environment variable with the name `TEST_VAR` and make sure you select the value to be from the credential we just created (it should show the description).

![var](https://qacommunity.blob.core.windows.net/images/jenkins-secma-12.png)

The last bit of setup is to configure the job to output all environment variables we can use.

Head to the `Build step` and include an `Execute shell`.
In that, enter the command `env`.

![Build step](https://qacommunity.blob.core.windows.net/images/jenkins-secma-13.png)

Finally, we can test that the variable is available to us.
The command `env` shows all exported environment variables that we can use during our build step.
Scroll down until you find the variable you just created.

![Variables](https://qacommunity.blob.core.windows.net/images/jenkins-secma-14.png)

### Clean Up

Head back to the `Project Dashboard` and select `Delete Project`.

Head back to the `Manage Jenkins` > `Manage Credentials`, select your `TEST` credential and then select `Delete` from the left-hand menu.

## Exercises
 
Create a new freestyle project and set it up to use a **private** GitHub repository.

To do this Jenkins will need to authenticate with GitHub.
Authentication with GitHub must now be done with either `SSH keys` or `Personal Access Tokens`, as of August 2021.

If we want Jenkins to authenticate with an SSH key, we will want to store the credential as an `SSH Username with private key`.

If we want Jenkins to authenticate with a Personal Access Token, we will want to store the credential as `Username with password`.

> Note: When you have finished this exercise, please remove the unused SSH Key or Personal Access Token from GitHub.
